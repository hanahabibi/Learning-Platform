package com.example.server.controller;

import com.example.server.Model.LearningMaterial;
import com.example.server.Model.User;
import com.example.server.service.LearningMaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Stream;

@RestController
@RequestMapping("/learningmaterial")
public class LearningMaterialController {
    private final LearningMaterialService learningmaterialService;

    @Autowired
    public LearningMaterialController(LearningMaterialService learningmaterialService) {
        this.learningmaterialService = learningmaterialService;
    }

    @PostMapping(path = "/add")
    public void addMaterial(@RequestBody LearningMaterial learningMaterial) {
        learningmaterialService.addMaterial(learningMaterial);
    }

    @DeleteMapping(path = "/delete/id/{learningmaterialkey}")
    public void deleteMaterial(@PathVariable int learningmaterialkey) {
        learningmaterialService.deleteMaterial(learningmaterialkey);
    }

    @GetMapping(path = "/download/{learningmaterialkey}")
    public Byte[] downloadMaterial(@PathVariable int learningmaterialkey) {
        return learningmaterialService.downloadMaterial(learningmaterialkey);
    }


    @GetMapping(path = "/get/id/{learningmaterialkey}")
    public LearningMaterial getMaterialByMaterialKey(@PathVariable int learningmaterialkey) {
        return learningmaterialService.getMaterialByMaterialKey(learningmaterialkey);
    }

    @GetMapping(path = "/get/courseKey/{coursekey}")
    public List<LearningMaterial> getMaterialByCourseKey(@PathVariable int coursekey) {
        return learningmaterialService.getMaterialByCourseKey(coursekey);
    }

}

