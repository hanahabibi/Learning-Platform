package com.example.server.controller;

import com.example.server.Model.Lecturer;
import com.example.server.service.LecturerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/lecturer")
public class LecturerController {
    private final LecturerService lecturerService;

    @Autowired
    public LecturerController(LecturerService lecturerService) {
        this.lecturerService = lecturerService;
    }

    @PostMapping(path = "/add")
    public void addNewLecturer(@RequestBody Lecturer lecturer) {
        lecturerService.addNewLecturer(lecturer);
    }

    @GetMapping(path = "/get/id/{lecturerkey}")
    public Lecturer getLecturerById(@PathVariable int lecturerkey) {
        return lecturerService.getLecturerById(lecturerkey);
    }

    @GetMapping(path = "/get/key/{userkey}")
    public Lecturer getLecturerByUserKey(@PathVariable int userkey) {
        return lecturerService.getLecturerByUserKey(userkey);
    }
}
