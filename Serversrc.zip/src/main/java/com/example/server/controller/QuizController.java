package com.example.server.controller;

import com.example.server.Model.Quiz;
import com.example.server.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quiz")
public class QuizController {

    private final QuizService quizService;

    @Autowired
    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }

    @PostMapping(path = "/add")
    public void addNewQuiz(@RequestBody Quiz quiz) {
        quizService.addNewQuiz(quiz);
    }

    @GetMapping(path = "/get/key/{quizkey}")
    public Quiz getQuizById(@PathVariable int quizkey) {
        return quizService.getQuizByID(quizkey);
    }

    @GetMapping(path = "/get/course/{coursekey}")
    public List<Quiz> getQuizbyCourseKey(@PathVariable int coursekey) {
        return quizService.getQuizbyCourseKey(coursekey);
    }

}
