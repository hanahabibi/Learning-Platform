package com.example.server.controller;

import com.example.server.Model.Student;
import com.example.server.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    private final StudentService studentService;

    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping(path = "/add")
    public void addNewStudent(@RequestBody Student student) {
        studentService.addNewStudent(student);

    }

    @GetMapping(path = "get/id/{matnumber}")
    public Student getStudentByID(@PathVariable int matnumber) {
        return studentService.getStudentByID(matnumber);
    }

    @GetMapping(path = "get/key/{userkey}")
    public Student getStudentByUserKey(@PathVariable int userkey) {
        return studentService.getStudentByUserKey(userkey);
    }

    @GetMapping(path = "/get/all")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

}
