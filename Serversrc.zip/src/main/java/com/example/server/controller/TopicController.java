package com.example.server.controller;

import com.example.server.Model.Topic;
import com.example.server.service.TopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/topic")
public class TopicController {

    private final TopicService topicService;

    @Autowired
    public TopicController(TopicService topicService) {
        this.topicService = topicService;
    }

    @PostMapping(path = "/add")
    public void addNewTopic(@RequestBody Topic topic) {
        topicService.addNewTopic(topic);
    }

    @DeleteMapping(path = "/delete/id/{topickey}")
    public void deleteTopic(@PathVariable int topickey) {
        topicService.deleteTopic(topickey);
    }

    @GetMapping(path = "/get/id/{topickey}")
    public Topic getTopicByTopickey(@PathVariable int topickey) {
        return topicService.getTopicByTopickey(topickey);
    }

    @GetMapping(path = "/get/title/{title}")
    public Topic getTopicByTitle(@PathVariable String title) {
        return topicService.getTopicByTitle(title);
    }

    @GetMapping(path = "/get/all")
    public List<Topic> getAllTopics() {
        return topicService.getAllTopics();
    }

}
