package com.example.server.controller;

import com.example.server.Model.Reminder;
import com.example.server.service.ReminderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import retrofit2.Call;
import retrofit2.http.Path;

import java.util.List;

@RestController
@RequestMapping("/reminder")
public class ReminderController {

    private final ReminderService reminderService;

    @Autowired
    public ReminderController(ReminderService reminderService) {
        this.reminderService = reminderService;
    }

    @PostMapping(path = "/add")
    public void addReminder(@RequestBody Reminder reminder) {
        reminderService.addReminder(reminder);
    }

    @GetMapping(path = "/get/id/{reminderid}")
    public Reminder getReminderByID(@PathVariable int reminderid) {
        return reminderService.getReminderByID(reminderid);
    }

    @GetMapping(path = "/get/event/{eventid}")
    public List<Reminder> getALLEventsForCourse(@PathVariable int eventid) {
        return reminderService.getAllReminderForEvent(eventid);
    }

    @GetMapping(path = "/get/date/{date}")
    public List<Reminder> getAllReminderForDay(@PathVariable String date) {
        return reminderService.getAllReminderForDay(date);
    }
}
