package com.example.server.controller;


import com.example.server.Model.Card;
import com.example.server.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/card")
public class CardController {

    private final CardService cardService;

    @Autowired
    public CardController(CardService cardService) {
        this.cardService = cardService;
    }

    @PostMapping(path = "/add")
    public void addCard(@RequestBody Card card) {
        cardService.addCard(card);
    }


    @GetMapping(path = "/get/id/{cardkey}")
    public Card getCardByCardKey(@PathVariable int cardkey) {
        return cardService.getCardByCardKey(cardkey);
    }

    @GetMapping(path = "/get/coursekey/{coursekey}")
    public List<Card> getCardByCourseKey(@PathVariable int coursekey) {
        return cardService.getCardByCourseKey(coursekey);
    }
}
