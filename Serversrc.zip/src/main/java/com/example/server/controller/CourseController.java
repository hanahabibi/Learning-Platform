package com.example.server.controller;

import com.example.server.Model.Course;
import com.example.server.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {

    private final CourseService courseService;

    @Autowired
    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PostMapping(path = "/add")
    public void addNewCourse(@RequestBody Course course) {
        courseService.addNewCourse(course);
    }

    @GetMapping(path = "/get/id/{coursekey}")
    public Course getCourseByID(@PathVariable int coursekey) {
        return courseService.getCourseByID(coursekey);
    }

    @GetMapping(path = "/get/semester/{semester}")
    public List<Course> getCoursesForSemester(@PathVariable String semester) {
        return courseService.getCoursesForSemester(semester);
    }

    @GetMapping(path = "/get/name/{name}")
    public List<Course> getCourseByName(@PathVariable String name) {
        return courseService.getCourseByName(name);
    }

    @GetMapping(path = "/get/all")
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

}