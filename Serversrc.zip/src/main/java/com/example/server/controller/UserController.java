package com.example.server.controller;

import com.example.server.Model.User;
import com.example.server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(path = "/add")
    public void addNewUser(@RequestBody User user) {
        userService.addNewUser(user);
    }

    @GetMapping(path = "/get/id/{userkey}")
    public User getUserById(@PathVariable int userkey) {
        return userService.getUserById(userkey);
    }

    @GetMapping(path = "/get/email/{email}")
    public User getUserByEmail(@PathVariable String email) {
        return userService.getUserByEmail(email);
    }

    @GetMapping(path = "/get/all")
    public List<User> getAllUser() {
        return userService.getAllUser();
    }


}
