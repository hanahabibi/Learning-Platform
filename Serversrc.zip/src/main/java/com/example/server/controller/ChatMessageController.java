package com.example.server.controller;

import com.example.server.Model.ChatMessage;
import com.example.server.service.ChatMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chatmessage")
public class ChatMessageController {

    private final ChatMessageService chatMessageService;

    @Autowired
    public ChatMessageController(ChatMessageService chatMessageService) {
        this.chatMessageService = chatMessageService;
    }

    @PostMapping(path = "/add")
    public void addNewChatMessage(@RequestBody ChatMessage chatMessage) {
        chatMessageService.addNewChatMessage(chatMessage);
    }

    @GetMapping(path = "/get/id/{chatId}")
    public List<ChatMessage> getChatMessagesByChatId(@PathVariable String chatId) {
        return chatMessageService.getChatMessagesByChatId(chatId);
    }

    @GetMapping(path = "/get/messageId/{messageId}")
    public ChatMessage getChatMessageByMessageId(@PathVariable int messageId) {
        return chatMessageService.getChatMessageByMessageId(messageId);
    }

    @GetMapping(path = "/get/senderId/{senderId}")
    public List<ChatMessage> getChatMessageBySenderId(@PathVariable int senderId) {
        return chatMessageService.getChatMessageBySenderId(senderId);
    }

    @GetMapping(path = "/get/receiverId/{receiverId}")
    public List<ChatMessage>getChatMessageByReceiverId(@PathVariable int receiverId) {
        return chatMessageService.getChatMessageByReceiverId(receiverId);
    }

    @GetMapping(path = "/get/all")
    public List<ChatMessage> getAllChatMessages() {
        return chatMessageService.getAllChatMessages();
    }

    @PostMapping(path = "/delete")
    public void deleteChatMessage(@RequestBody ChatMessage message) {
        chatMessageService.deleteChatMessage(message);
    }

}
