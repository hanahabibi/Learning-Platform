package com.example.server.controller;

import com.example.server.Model.LearningMaterial;
import com.example.server.Model.Task;
import com.example.server.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/task")
public class TaskController {
    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping(path = "/add")
    public void addTask(@RequestBody Task task) {
        taskService.addTask(task);
    }


    @GetMapping(path = "/get/id/{taskkey}")
    public Task getTaskByTaskKey(@PathVariable int taskkey) {
        return taskService.getTaskByTaskKey(taskkey);
    }

    @GetMapping(path = "/get/courseKey/{coursekey}")
    public List<Task> getTaskByCourseKey(@PathVariable int coursekey) {
        return taskService.getTaskByCourseKey(coursekey);
    }


}
