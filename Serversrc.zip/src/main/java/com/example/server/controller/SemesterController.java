package com.example.server.controller;

import com.example.server.Model.Semester;
import com.example.server.service.SemesterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/semester")
public class SemesterController {

    private final SemesterService semesterService;

    @Autowired
    public SemesterController(SemesterService semesterService) {
        this.semesterService = semesterService;
    }

    @PostMapping(path = "/add")
    public void addSemester(@RequestBody Semester semester) {
        semesterService.addSemester(semester);

    }

    @GetMapping(path = "/get/id/{semesterid}")
    public Semester getSemesterById(@PathVariable int semesterid) {
        return semesterService.getSemesterById(semesterid);
    }

    @GetMapping(path = "/get/name/{name}")
    public Semester getSemesterByName(@PathVariable String name) {
        return semesterService.getSemesterByName(name);
    }

    @GetMapping(path = "/get/all")
    public List<Semester> getAllSemester() {
        return semesterService.getAllSemester();
    }

}
