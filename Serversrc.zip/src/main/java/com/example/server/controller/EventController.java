package com.example.server.controller;

import com.example.server.Model.Event;
import com.example.server.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/event")
public class EventController {

    private final EventService eventService;

    @Autowired
    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @PostMapping(path = "/add")
    public void addNewEvent(@RequestBody Event event) {
        eventService.addNewEvent(event);
    }

    @GetMapping(path = "/get/id/{eventID}")
    public Event getEventByID(@PathVariable int eventID) {
        return eventService.getEventByID(eventID);
    }

    @GetMapping(path = "/get/course/{coursekey}")
    public List<Event> getALLEventsForCourse(@PathVariable int coursekey) {
        return eventService.getALLEventsForCourse(coursekey);
    }

}
