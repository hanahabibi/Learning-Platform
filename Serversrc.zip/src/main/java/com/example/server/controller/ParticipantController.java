package com.example.server.controller;

import com.example.server.Model.Course;
import com.example.server.Model.Participant;
import com.example.server.service.CourseService;
import com.example.server.service.ParticipantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/participant")
public class ParticipantController {

    private final ParticipantService participantService;

    @Autowired
    public ParticipantController(ParticipantService participantService) {
        this.participantService = participantService;
    }

    @PostMapping(path = "/add")
    public void addNewParticipant(@RequestBody Participant participant) {
        participantService.addNewParticipant(participant);
    }

    @GetMapping(path = "/get/userKey/{userKey}")
    public List<Participant> getParticipantByUserKey(@PathVariable int userKey) {
        return participantService.getParticipantByUserKey(userKey);

    }

    @PostMapping(path = "/pass/{participantkey}")
    public void passParticipant(@PathVariable int participantkey) {
        participantService.passParticipant(participantkey);
    }


    @GetMapping(path = "/get/courseKey/{courseKey}")
    public List<Participant> getParticipantByCourseKey(@PathVariable int courseKey) {
        return participantService.getParticipantByCourseKey(courseKey);

    }
}
