package com.example.server.controller;

import com.example.server.service.MailService;
import com.example.server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import retrofit2.http.Path;

@RestController
@RequestMapping("/mail")
public class MailController {

    private final MailService mailService;

    @Autowired
    public MailController(MailService mailService) {
        this.mailService = mailService;
    }

    @PostMapping(path = "/send/{to}/{subj}/{text}")
    public boolean sendMailTo(@PathVariable String to, @PathVariable String subj, @PathVariable String text) {
        try {
            if (to.contains(";")) {
                String[] tmp = to.split(";");
                mailService.sendSimpleMessage(subj, text, tmp);
            } else {
                mailService.sendSimpleMessage(subj, text, to);

            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @PostMapping(path = "/generateCode/{email}")
    public String generateCode(@PathVariable String email) {
        try {
            String tmp = mailService.generateCode();
            sendMailTo("Auth Code", "Ihr Authentifacations Code lautet:\n" + tmp + "\nBitte gib diesen Code zum bestätigen deiner Identität ein", email);
            return tmp;
        } catch (Exception e) {
            return new String();
        }
    }

}
