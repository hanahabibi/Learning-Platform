package com.example.server.controller;

import com.example.server.Model.Chat;
import com.example.server.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {

    private final ChatService chatService;

    @Autowired
    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @PostMapping(path = "/add")
    public void addNewChat(@RequestBody Chat chat) {
        chatService.addNewChat(chat);
    }

    @GetMapping(path = "/get/chatkey/{chatkey}")
    public Chat getChatByChatKey(@PathVariable String chatkey) {
        return chatService.getChatByChatKey(chatkey);
    }

    @GetMapping(path = "/get/userkey/{userkey}")
    public List<Chat> getChatsByUserKey(@PathVariable int userkey) {
        return chatService.getChatsByUserKey(userkey);
    }

    @GetMapping(path = "/get/all")
    public List<Chat> getAllChats() {
        return chatService.getAllChats();
    }
}

