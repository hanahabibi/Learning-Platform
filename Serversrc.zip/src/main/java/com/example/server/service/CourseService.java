package com.example.server.service;

import com.example.server.Model.Course;
import com.example.server.Model.User;
import com.example.server.crud.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    @Autowired
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public void addNewCourse(Course course) {
        System.out.println(course.toString());
        courseRepository.save(course);
    }

    public Course getCourseByID(int coursekey) {
        Course tmp = courseRepository.findById(coursekey).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new Course();
    }

    public List<Course> getCoursesForSemester(String semester) {
        List<Course> tmp = new ArrayList<>();
        for (Course a : courseRepository.findAll()) {
            if (a.getSemester().equals(semester)) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<Course> getCourseByName(String name) {
        List<Course> tmp = new ArrayList<>();
        for (Course a : courseRepository.findAll()) {
            if (a.getName().equals(name)) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
}
