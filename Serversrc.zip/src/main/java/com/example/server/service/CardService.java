package com.example.server.service;

import com.example.server.Model.Card;
import com.example.server.crud.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CardService {
    private final CardRepository cardRepository;

    @Autowired
    public CardService(CardRepository cardRepository) {
        this.cardRepository = cardRepository;
    }

    public void addCard(Card card) {
        cardRepository.save(card);
    }

    public List<Card> getCardByCourseKey(int coursekey) {
        List<Card> tmp = new ArrayList<>();
        for (Card a : cardRepository.findAll()) {
            if (a.getCoursekey() == coursekey) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public Card getCardByCardKey(int cardkey) {
        Card tmp = cardRepository.findById(cardkey).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new Card();
    }


}
