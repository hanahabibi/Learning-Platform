package com.example.server.service;

import com.example.server.Model.Participant;
import com.example.server.crud.ParticipantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ParticipantService {

    private final ParticipantRepository participantRepository;

    @Autowired
    public ParticipantService(ParticipantRepository participantRepository) {
        this.participantRepository = participantRepository;
    }

    public void addNewParticipant(Participant participant) {
        participantRepository.save(participant);
    }

    public void passParticipant(int participantkey) {
        Optional<Participant> tmp = participantRepository.findById(participantkey);

        if (!tmp.isEmpty()) {
            tmp.get().setPassed(1);
            participantRepository.save(tmp.get());
        }

    }

    public List<Participant> getParticipantByUserKey(int userkey) {
        List<Participant> tmp = new ArrayList<>();
        for (Participant a : participantRepository.findAll()
        ) {
            if (a.getUserkey() == userkey) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<Participant> getParticipantByCourseKey(int coursekey) {
        List<Participant> tmp = new ArrayList<>();
        for (Participant a : participantRepository.findAll()
        ) {
            if (a.getCoursekey() == coursekey) {
                tmp.add(a);
            }
        }
        return tmp;
    }


}
