package com.example.server.service;

import com.example.server.Model.Lecturer;
import com.example.server.crud.LecturerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LecturerService {

    private final LecturerRepository lecturerRepository;

    @Autowired
    public LecturerService(LecturerRepository lecturerRepository) {

        this.lecturerRepository = lecturerRepository;
    }

    public void addNewLecturer(Lecturer lecturer) {
        lecturerRepository.save(lecturer);
    }

    public Lecturer getLecturerById(int lecturerkey) {
        return lecturerRepository.findById(lecturerkey).orElse(null);
    }

    public Lecturer getLecturerByUserKey(int userkey) {
        Lecturer tmp = new Lecturer();
        for (Lecturer a : lecturerRepository.findAll()
        ) {
            if (a.getUserkey() == userkey) {
                tmp = a;
                break;
            }
        }
        return tmp;
    }

}
