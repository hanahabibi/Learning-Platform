package com.example.server.service;

import com.example.server.Model.Topic;
import com.example.server.crud.TopicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TopicService {

    private final TopicRepository topicRepository;

    @Autowired
    public TopicService(TopicRepository topicRepository) {
        this.topicRepository = topicRepository;
    }

    public void addNewTopic(Topic topic) {
        topicRepository.save(topic);
    }

    public Topic getTopicByTopickey(int topickey) {
        Topic tmp = topicRepository.findById(topickey).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new Topic();
    }

    public Topic getTopicByTitle(String title) {
        Topic tmp = new Topic();
        for (Topic a : topicRepository.findAll()) {
            if (a.getTitle().equals(title)) {
                tmp = a;
            }
        }
        return tmp;
    }

    public List<Topic> getTopicsByLecturerkey(int lecturerkey) {
        List<Topic> tmp = new ArrayList<>();
        for (Topic a : topicRepository.findAll()) {
            if (a.getLecturerkey() == lecturerkey) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public void deleteTopic(int topickey) {
        topicRepository.deleteById(topickey);
    }

    public List<Topic> getAllTopics() {
        return topicRepository.findAll();
    }
}
