package com.example.server.service;

import com.example.server.Model.Event;
import com.example.server.crud.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EventService {

    private final EventRepository eventRepository;

    @Autowired
    public EventService(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    public void addNewEvent(Event event) {
        eventRepository.save(event);
    }

    public Event getEventByID(int eventID) {
        Event tmp = eventRepository.findById(eventID).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new Event();
    }

    public List<Event> getALLEventsForCourse(int coursekey) {
        List<Event> tmp = new ArrayList<>();
        for (Event a : eventRepository.findAll()) {
            if (a.coursekey == (coursekey)) {
                tmp.add(a);
            }
        }
        return tmp;
    }

}
