package com.example.server.service;

import com.example.server.Model.ChatMessage;
import com.example.server.crud.ChatMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChatMessageService {

    private final ChatMessageRepository chatMessageRepository;

    @Autowired
    public ChatMessageService(ChatMessageRepository chatMessageRepository) {
        this.chatMessageRepository = chatMessageRepository;
    }

    public void addNewChatMessage(ChatMessage chatMessage) {
        System.out.println(chatMessage.toString());
        chatMessageRepository.save(chatMessage);
    }

    public ChatMessage getChatMessageByMessageId(int messageId) {
        for (ChatMessage a : chatMessageRepository.findAll()) {
            if (a.getMessageid() == messageId) {
                return a;
            }
        }
        return new ChatMessage();
    }

    public List<ChatMessage> getChatMessageBySenderId(int senderId) {
        List<ChatMessage> tmp = new ArrayList<>();
        for (ChatMessage a : chatMessageRepository.findAll()) {
            if (a.getSenderid() == senderId) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<ChatMessage> getChatMessageByReceiverId(int receiverId) {
        List<ChatMessage> tmp = new ArrayList<>();
        for (ChatMessage a : chatMessageRepository.findAll()) {
            if (a.getReceiverid() == receiverId) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<ChatMessage> getChatMessagesByChatId(String chatId) {
        List<ChatMessage> tmp = new ArrayList<>();
        for (ChatMessage a : chatMessageRepository.findAll()) {
            if (a.getChatid() == (chatId)) {
                tmp.add(a);
            }
        }

        return tmp;
    }

    public List<ChatMessage> getAllChatMessages() {
        return chatMessageRepository.findAll();
    }

    public void deleteChatMessage(ChatMessage message) {
        List<ChatMessage> tmp = new ArrayList<>();
        tmp = chatMessageRepository.findAll();

        for (ChatMessage a : tmp) {
            if (a.getChatid().equals(message.getChatid())) {
                if (a.getContent().equals(message.getContent())) {
                    if (a.getTimestamp().equals(message.getTimestamp())) {
                        chatMessageRepository.delete(a);
                    }
                }
            }
        }
    }
}

