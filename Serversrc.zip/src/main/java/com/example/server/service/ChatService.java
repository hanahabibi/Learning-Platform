package com.example.server.service;

import com.example.server.Model.Chat;

import com.example.server.crud.ChatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChatService {
    private final ChatRepository chatRepository;

    @Autowired
    public ChatService(ChatRepository chatRepository) {
        this.chatRepository = chatRepository;
    }

    public void addNewChat(Chat chat) {
        System.out.println(chat.toString());
        chatRepository.save(chat);
    }

    public Chat getChatByChatKey(String chatkey) {
        for (Chat a : chatRepository.findAll()) {
            if (a.getChatkey().equals(chatkey)) {
                return a;
            }
        }
        return new Chat();
    }

    public List<Chat> getChatsByUserKey(int userkey) {
        List<Chat> tmp = new ArrayList<>();
        for (Chat a : chatRepository.findAll()) {
            if (a.getKeyuserone() == (userkey)) {
                tmp.add(a);
            }
            if (a.getKeyusertwo() == userkey) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<Chat> getAllChats() {
        return chatRepository.findAll();
    }
}
