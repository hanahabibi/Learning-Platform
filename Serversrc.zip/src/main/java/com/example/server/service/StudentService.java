package com.example.server.service;

import com.example.server.Model.Student;
import com.example.server.crud.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {


    private final StudentRepository studentRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public void addNewStudent(Student student) {
        studentRepository.save(student);
    }

    public Student getStudentByID(int matnumber) {
        Student tmp = new Student();
        return studentRepository.findById(matnumber).orElse(tmp);

    }

    public Student getStudentByUserKey(int userkey) {
        List<Student> tmp = studentRepository.findAll();
        for (Student a : tmp
        ) {
            if (a.getUserkey() == userkey) {
                return a;
            }

        }
        return null;
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
}
