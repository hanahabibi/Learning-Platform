package com.example.server.service;

import com.example.server.Model.Course;
import com.example.server.Model.LearningMaterial;
import com.example.server.crud.LearningMaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

@Service
public class LearningMaterialService {
    private final LearningMaterialRepository learningMaterialRepository;

    @Autowired
    public LearningMaterialService(LearningMaterialRepository learningMaterialRepository1) {
        this.learningMaterialRepository = learningMaterialRepository1;
    }

    public void addMaterial(LearningMaterial learningMaterial) {
        learningMaterialRepository.save(learningMaterial);
    }


    public void deleteMaterial(int learningmaterialkey) {
        learningMaterialRepository.deleteById(learningmaterialkey);
    }

    public Byte[] downloadMaterial(int key) {
        return learningMaterialRepository.findById(key).get().getMaterial();
    }

    public List<LearningMaterial> getMaterialByCourseKey(int coursekey) {
        List<LearningMaterial> tmp = new ArrayList<>();
        for (LearningMaterial a : learningMaterialRepository.findAll()
        ) {
            if (a.getCoursekey() == coursekey) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public LearningMaterial getMaterialByMaterialKey(int learningmaterialkey) {
        LearningMaterial tmp = learningMaterialRepository.findById(learningmaterialkey).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new LearningMaterial();
    }


}
