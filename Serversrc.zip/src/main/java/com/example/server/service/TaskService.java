package com.example.server.service;

import com.example.server.Model.LearningMaterial;
import com.example.server.Model.Task;
import com.example.server.crud.LearningMaterialRepository;
import com.example.server.crud.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TaskService {
    private final TaskRepository taskRepository;

    @Autowired
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public void addTask(Task task) {
        taskRepository.save(task);
    }

    public List<Task> getTaskByCourseKey(int coursekey) {
        List<Task> tmp = new ArrayList<>();
        for (Task a : taskRepository.findAll()
        ) {
            if (a.getCoursekey() == coursekey) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public Task getTaskByTaskKey(int taskkey) {
        Task tmp = taskRepository.findById(taskkey).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new Task();
    }

}
