package com.example.server.service;

import com.example.server.Model.User;
import com.example.server.crud.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {


    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void addNewUser(User user) {
        userRepository.save(user);
    }

    public User getUserById(int userkey) {

        return userRepository.findById(userkey).orElse(null);


    }

    public User getUserByEmail(String mail) {
        User tmp = new User();
        for (User a : userRepository.findAll()) {
            if (a.getEmail().equals(mail)) {
                tmp = a;
                break;
            }
        }
        return tmp;
    }


    public List<User> getAllUser() {
        return userRepository.findAll();
    }

}
