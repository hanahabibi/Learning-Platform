package com.example.server.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailService {

    private JavaMailSender javaMailSender;
    private AuthService authService;

    @Autowired
    public MailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
        authService = new AuthService();
    }

    public void sendSimpleMessage(String subj, String text, String... to) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("projectxSep@gmx.de");
        message.setTo(to);
        message.setSubject(subj);
        message.setText(text);
        javaMailSender.send(message);
    }

    public String generateCode() {
        return authService.generateCode();
    }

}
