package com.example.server.service;

import com.example.server.Model.Course;
import com.example.server.Model.Semester;
import com.example.server.Model.Student;
import com.example.server.crud.SemesterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SemesterService {

    public final SemesterRepository semesterRepository;

    @Autowired
    public SemesterService(SemesterRepository semesterRepository) {
        this.semesterRepository = semesterRepository;
    }

    public void addSemester(Semester semester) {
        semesterRepository.save(semester);
    }

    public Semester getSemesterById(int semesterid) {
        Semester tmp = new Semester();
        return semesterRepository.findById(semesterid).orElse(tmp);

    }

    public Semester getSemesterByName(String name) {
        Semester tmp = new Semester();
        List<Semester> semesters = new ArrayList<Semester>();
        semesters.addAll(semesterRepository.findAll());
        for (Semester a : semesters) {
            if (a.getName().equals(name)) {
                return a;
            }
        }
        return tmp;
    }


    public List<Semester> getAllSemester() {
        return semesterRepository.findAll();
    }
}


