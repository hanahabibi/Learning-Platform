package com.example.server.service;

import java.util.Random;

public class AuthService {
    final String capitalLeter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    final String smallLeter = "abcdefghijklmnopqrstuvxyz";
    final String symboles = "!&?#@+%";

    public AuthService() {

    }


    public String generateCode() {
        String result = "";

        Random tmp = new Random();
        for (int i = 0; i < 8; i++) {
            int value = tmp.nextInt(2);

            switch (value) {
                case 0:
                    result = result + capitalLeter.charAt(tmp.nextInt(capitalLeter.length()));
                    break;
                case 1:
                    result = result + smallLeter.charAt(tmp.nextInt(smallLeter.length()));
                    break;
                default:
                    result = result + symboles.charAt(tmp.nextInt(symboles.length()));
                    break;
            }
        }

        return result;
    }


}
