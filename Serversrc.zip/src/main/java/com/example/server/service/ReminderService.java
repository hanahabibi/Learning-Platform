package com.example.server.service;

import com.example.server.Model.Event;
import com.example.server.Model.Reminder;
import com.example.server.crud.EventRepository;
import com.example.server.crud.ReminderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReminderService {

    private final ReminderRepository reminderRepository;

    @Autowired
    public ReminderService(ReminderRepository reminderRepository) {
        this.reminderRepository = reminderRepository;
    }

    public void addReminder(Reminder reminder) {
        reminderRepository.save(reminder);
    }

    public Reminder getReminderByID(int reminderid) {
        Reminder tmp = reminderRepository.findById(reminderid).orElse(null);
        if (tmp != null) {
            return tmp;
        }
        return new Reminder();
    }

    public List<Reminder> getAllReminderForEvent(int eventid) {
        List<Reminder> tmp = new ArrayList<>();
        for (Reminder a : reminderRepository.findAll()) {
            if (a.getEventid() == (eventid)) {
                tmp.add(a);
            }
        }
        return tmp;
    }

    public List<Reminder> getAllReminderForDay(String date) {
        List<Reminder> tmp = new ArrayList<>();
        String[] b = date.split("-");
        for (Reminder a : reminderRepository.findAll()) {
            if (a.getDay() == Integer.parseInt(b[2]) && a.getMonth() == Integer.parseInt(b[1]) && a.getYear() == Integer.parseInt(b[0])) {
                tmp.add(a);
            }
        }
        return tmp;
    }

}