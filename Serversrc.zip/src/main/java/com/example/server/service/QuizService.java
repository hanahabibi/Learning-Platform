package com.example.server.service;

import com.example.server.Model.Quiz;
import com.example.server.Model.Student;
import com.example.server.crud.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QuizService {

    private final QuizRepository quizRepository;

    @Autowired
    public QuizService(QuizRepository quizRepository) {
        this.quizRepository = quizRepository;
    }

    public void addNewQuiz(Quiz quiz) {
        quizRepository.save(quiz);
    }

    public Quiz getQuizByID(int quizid) {
        Quiz temp = quizRepository.findById(quizid).orElse(null);
        if (temp != null) {
            return temp;
        }
        return new Quiz();
    }

    public List<Quiz> getQuizbyCourseKey(int coursekey) {
        List<Quiz> tmp = quizRepository.findAll();
        List<Quiz> result = new ArrayList<>();
        for (Quiz a : tmp
        ) {
            if (a.getCoursekey() == coursekey) {
                result.add(a);
            }

        }
        return result;
    }
}
