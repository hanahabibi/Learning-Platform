package com.example.server.Model;

import javax.persistence.*;


@Entity
@Table(name = "topic")
public class Topic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int topickey;
    String title;
    String description;
    int lecturerkey;
    Byte[] literature;

    public Topic() {

    }

    public Topic(String title, String description, int lecturerkey, Byte[] literature) {
        this.title = title;
        this.description = description;
        this.lecturerkey = lecturerkey;
        this.literature = literature;
    }

    public int getTopickey() {
        return topickey;
    }

    public void setTopickey(int topickey) {
        this.topickey = topickey;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getLecturerkey() {
        return lecturerkey;
    }

    public void setLecturerkey(int lecturerkey) {
        this.lecturerkey = lecturerkey;
    }

    public Byte[] getLiterature() {
        return literature;
    }

    public void setLiterature(Byte[] literature) {
        this.literature = literature;
    }
}

