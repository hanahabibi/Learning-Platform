package com.example.server.Model;

import javax.persistence.*;

@Entity
@Table(name = "task")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int taskkey;
    private String task;
    private String taskstate;
    private int coursekey;
    private int resposible;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getResposible() {
        return resposible;
    }

    public void setResposible(int resposible) {
        this.resposible = resposible;
    }

    public Task() {
    }

    public int getTaskkey() {
        return taskkey;
    }

    public void setTaskkey(int taskkey) {
        this.taskkey = taskkey;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getTaskstate() {
        return taskstate;
    }

    public void setTaskstate(String taskstate) {
        this.taskstate = taskstate;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }


    @Override
    public String toString() {
        return "Task{" +
                "name='" + task + '\'' +
                ", state=" + taskstate +
                ", coursekey='" + coursekey + '\'' +
                '}';
    }
}
