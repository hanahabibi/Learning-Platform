package com.example.server.Model;

import javax.persistence.*;


@Entity
@Table(name = "lecturer")
public class Lecturer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int lecturerkey;
    private int userkey;
    private String institute;
    private String research;

    public Lecturer() {
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userKey) {
        this.userkey = userKey;
    }

    public int getLecturerkey() {
        return lecturerkey;
    }

    public void setLecturerkey(int lecturerkey) {
        this.lecturerkey = lecturerkey;
    }

    public String getInstitute() {
        return institute;
    }

    public void setInstitute(String institute) {
        this.institute = institute;
    }

    public String getResearch() {
        return research;
    }

    ;

    public void setResearch(String research) {
        this.research = research;
    }

    @Override
    public String toString() {
        return "|" + userkey + "|" + lecturerkey + "|" + institute + '|' + research + '|';
    }
}
