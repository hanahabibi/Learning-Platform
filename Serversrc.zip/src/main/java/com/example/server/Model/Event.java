package com.example.server.Model;

import javax.persistence.*;
import java.sql.Date;
import java.util.ArrayList;

@Entity
@Table(name = "event")
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public int eventID;
    public int year;
    public int month;
    public int day;
    public String name;
    public int coursekey;
    public int hour;
    public int minute;
    public String timestr;

    public Event() {
    }

    public int getEventID() {
        return eventID;
    }

    public void setEventID(int eventID) {
        this.eventID = eventID;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public String getTimestr() {
        return timestr;
    }

    public void setTimestr(String timestr) {
        this.timestr = timestr;
    }
    @Override
    public String toString() {

        if (getMinute() < 10 && getHour() < 10) {
            return name + " | " + 0 + Integer.toString(hour) + ":" + 0 + Integer.toString(minute) + " | " + dateToString();
        }
        if (getMinute() < 10) {
            return name + " | " + Integer.toString(hour) + ":" + 0 + Integer.toString(minute) + " | " + dateToString();
        }
        if (getHour() < 10) {
            return name + " | " + 0 + Integer.toString(hour) + ":" + Integer.toString(minute) + " | " + dateToString();
        }

        return name + " | " + Integer.toString(hour) + ":" + Integer.toString(minute) + " | " + dateToString();
    }

    public String dateToString() {
        return day + "-" + month + "-" + year;
    }

    public String timeString() {
        if (getHour() < 10 && getMinute() < 10) {
            return 0 + getHour() + ":" + 0 + getMinute();
        }
        if (getMinute() < 10) {
            return getHour() + ":" + 0 + getMinute();
        }
        if (getHour() < 10) {
            return 0 + getHour() + ":" + getMinute();
        }
        return getHour() + ":" + getMinute();
    }

}


