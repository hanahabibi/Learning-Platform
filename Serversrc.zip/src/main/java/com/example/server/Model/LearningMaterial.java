package com.example.server.Model;

import javax.persistence.*;
import java.sql.Blob;

@Entity
@Table(name = "learningmaterial")
public class LearningMaterial {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int learningmaterialkey;
    private String name;
    private int coursekey;
    @Lob
    private Byte[] material;

    public LearningMaterial() {
    }

    public int getLearningmaterialkey() {
        return learningmaterialkey;
    }

    public void setLearningmaterialkey(int learningmaterialkey) {
        this.learningmaterialkey = learningmaterialkey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public Byte[] getMaterial() {
        return material;
    }

    public void setMaterial(Byte[] material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return "LearningMaterial{" +
                "name='" + name + '\'' +
                ", learningmaterialkey=" + learningmaterialkey +
                ", coursekey='" + coursekey + '\'' +
                '}';
    }
}
