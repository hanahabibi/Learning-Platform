package com.example.server.Model;

import javax.persistence.*;

@Entity
@Table(name = "course")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int coursekey;
    private String name;
    private String semester;
    private String typ;
    private int userkey;

    public Course() {
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getTyp() {
        return typ;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userkey) {
        this.userkey = userkey;
    }

    @Override
    public String toString() {
        return "Course{" +
                "coursekey=" + coursekey +
                ", name='" + name + '\'' +
                ", semester='" + semester + '\'' +
                ", typ='" + typ + '\'' +
                '}';
    }
}
