package com.example.server.Model;

import javax.persistence.*;

@Entity
@Table(name = "student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int matnumber;
    public String subject;
    public String friends;
    public String fstate;
    public int userkey;

    public Student() {
    }

    public int getMatnumber() {
        return matnumber;
    }

    public void setMatnumber(int matnumber) {
        this.matnumber = matnumber;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFriends() {
        return friends;
    }

    public void setFriends(String friends) {
        this.friends = friends;
    }

    public String getFstate() {
        return fstate;
    }

    public void setFstate(String fstate) {
        this.fstate = fstate;
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userkey) {
        this.userkey = userkey;
    }

    @Override
    public String toString() {
        return "|" + matnumber + "|" + subject + "|" + userkey + "|";
    }

}
