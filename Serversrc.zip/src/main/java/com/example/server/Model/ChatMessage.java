package com.example.server.Model;

import javax.persistence.*;

@Entity
@Table(name = "chatmessage")
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int messageid;
    private String chatid;
    private int senderid;
    private int receiverid;
    private String content;
    private String timestamp;

    public int getMessageid() {
        return messageid;
    }

    public void setMessageid(int messageid) {
        this.messageid = messageid;
    }

    public int getReceiverid() {
        return receiverid;
    }

    public void setReceiverid(int receiverId) {
        this.receiverid = receiverId;
    }

    public ChatMessage(String chatid, int senderid, int receiverid, String content, String timestamp) {
        this.chatid = chatid;
        this.senderid = senderid;
        this.receiverid = receiverid;
        this.content = content;
        this.timestamp = timestamp;
    }

    public ChatMessage() {
    }

    public int getId() {
        return messageid;
    }

    public void setId(int id) {
        this.messageid = id;
    }

    public String getChatid() {
        return chatid;
    }

    public void setChatid(String chatId) {
        this.chatid = chatId;
    }

    public int getSenderid() {
        return senderid;
    }

    public void setSenderid(int senderId) {
        this.senderid = senderId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }


    @Override
    public String toString() {
        return content + "\n" + timestamp;
    }


}
