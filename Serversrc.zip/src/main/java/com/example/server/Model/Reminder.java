package com.example.server.Model;

import javax.persistence.*;
import java.sql.Date;


@Entity
@Table(name = "reminder")
public class Reminder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int reminderid;
    int eventid;
    public int year;
    public int month;
    public int day;
    String title;
    int hour;
    int minute;
    String date;
    boolean emailorpopup;
    String userkeys;


    public Reminder() {

    }

    public int getReminderid() {
        return reminderid;
    }

    public void setReminderid(int reminderid) {
        this.reminderid = reminderid;
    }

    public int getEventid() {
        return eventid;
    }

    public void setEventid(int eventid) {
        this.eventid = eventid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isEmailorpopup() {
        return emailorpopup;
    }

    public void setEmailorpopup(boolean emailorpopup) {
        this.emailorpopup = emailorpopup;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public String getUserkeys() {
        return userkeys;
    }

    public void setUserkeys(String userkeys) {
        this.userkeys = userkeys;
    }

    public void addToUserkeys(int userkey) {
        String user = String.valueOf(userkey);
        String tmp = getUserkeys() + "|" + user;
        setUserkeys(tmp);
    }

    public boolean containsUser(int userkey) {
        boolean erg = false;

        String user = String.valueOf(userkey);
        String[] keys = getUserkeys().split("|");
        for (int i = 0; i <= keys.length; i++) {
            if (user.equals(keys[i])) erg = true;

        }
        return erg;
    }

    @Override
    public String toString() {
        if (getHour() < 10 && getMinute() < 10) {
            return getTitle() + " | " + getDate() + " | " + 0 + getHour() + ":" + 0 + getMinute();
        }
        if (getMinute() < 10) {
            return getTitle() + " | " + getDate() + " | " + getHour() + ":" + 0 + getMinute();
        }
        if (getHour() < 10) {
            return getTitle() + " | " + getDate() + " | " + 0 + getHour() + ":" + getMinute();
        }
        return getTitle() + " | " + getDate() + " | " + getHour() + ":" + getMinute();
    }

    public String timeString() {
        if (getHour() < 10 && getMinute() < 10) {
            return 0 + getHour() + ":" + 0 + getMinute();
        }
        if (getMinute() < 10) {
            return getHour() + ":" + 0 + getMinute();
        }
        if (getHour() < 10) {
            return 0 + getHour() + ":" + getMinute();
        }
        return getHour() + ":" + getMinute();
    }

    public String getTypeString() {
        if (isEmailorpopup()) {
            return "Pop-Up";
        } else return "E-Mail";
    }
}
