package com.example.server.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Quiz {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int quizid;
    int coursekey;
    Byte[] quiz;
    String whoworkedonthatquiz;
    String type;

    public int getQuizid() {
        return quizid;
    }

    public void setQuizid(int quizid) {
        this.quizid = quizid;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCourskey(int coursekey) {
        this.coursekey = coursekey;
    }

    public Byte[] getQuiz() {
        return quiz;
    }

    public void setQuiz(Byte[] quiz) {
        this.quiz = quiz;
    }

    public String getWhoworkedonthatquiz() {
        return whoworkedonthatquiz;
    }

    public void setWhoworkedonthatquiz(String whoworkedonthatquiz) {
        this.whoworkedonthatquiz = whoworkedonthatquiz;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
