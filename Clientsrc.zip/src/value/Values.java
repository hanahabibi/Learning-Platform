package value;

public class Values {
    //public static final String Base_URL ="http://191.96.103.98:8080";
    public static final String Base_URL = "http://localhost:8080";
    public static final String Dir_Path = "./Chat";
}
