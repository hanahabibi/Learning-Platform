package exception;

public class LoginNotFoundException extends Throwable {
    @Override
    public String getMessage() {
        return "Fehlerhafter Login Name";
    }
}
