package exception;

public class NoUserExisting extends Throwable {
    @Override
    public String getMessage() {
        return "Kein Nutzer mit Email/Matrikelnummer gefunden!";
    }
}
