package exception;

public class WrongPasswordException extends Exception {
    @Override
    public String getMessage() {
        return "Falsches Passwort!";
    }
}
