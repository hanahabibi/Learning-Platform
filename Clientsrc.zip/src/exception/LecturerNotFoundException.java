package exception;

public class LecturerNotFoundException extends Throwable {
    @Override
    public String getMessage() {
        return "Lehrender existiert nicht!";
    }
}
