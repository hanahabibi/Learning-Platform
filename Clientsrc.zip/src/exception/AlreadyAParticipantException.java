package exception;

import javafx.animation.PauseTransition;
import javafx.util.Duration;

public class AlreadyAParticipantException extends Throwable {

}
