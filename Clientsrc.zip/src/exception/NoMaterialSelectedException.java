package exception;

public class NoMaterialSelectedException extends Throwable {

    @Override
    public String toString() {
        return "Es ist kein Lehrmaterial ausgewählt!";
    }
}
