package exception;

public class MaterialNotFoundException extends Throwable {
    @Override
    public String getMessage() {
        return "Material nicht gefunden";
    }
}
