package exception;

public class StudentNotFoundException extends Exception {

    @Override
    public String getMessage() {
        return "Student Existiert nicht oder wurde in der Datenbank nicht gefunden!";
    }
}
