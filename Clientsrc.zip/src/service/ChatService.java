package service;

import Interfaces.ChatInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Chat;
import model.ChatMessage;
import model.Participant;
import model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ChatService implements Callback<Chat> {

    private Chat currentChat;
    private List<Chat> chatList;
    private List<Chat> usersChats;
    private List<User> chatPartners = FXCollections.observableArrayList();
    private ObservableList<Participant> groupMembers = FXCollections.observableArrayList();
    String path = Values.Dir_Path;
    Gson gson;
    Retrofit retrofit;
    ChatInterface chatInterface;
    UserService userService = new UserService();
    public final String BASE_URL = "http://localhost:8080";

    public ChatService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        chatInterface = retrofit.create(ChatInterface.class);
    }

    public void getChatByChatKey(String chatkey) throws IOException {
        chatInterface = retrofit.create(ChatInterface.class);
        Call<Chat> call = chatInterface.getChatByChatKey(chatkey);
        currentChat = call.execute().body();

    }

    public List<Chat> getChatsByUserKey(int userKey) throws IOException {
        this.getAllChats();
        List<Chat> allChats = this.getChatList();
        usersChats = new ArrayList<>();
        for (int i = 0; i < allChats.size(); i++) {
            if (allChats.get(i).getType().equals("private")) {
                if (allChats.get(i).getKeyuserone() == userKey || allChats.get(i).getKeyusertwo() == userKey) {
                    usersChats.add(allChats.get(i));
                }
            }
        }
        return usersChats;
    }

    public void getAllChats() throws IOException {
        chatInterface = retrofit.create(ChatInterface.class);
        Call<List<Chat>> call = chatInterface.getAllChats();
        chatList = call.execute().body();

    }

    public void addNewChat(Chat chat) throws IOException {
        chatInterface = retrofit.create(ChatInterface.class);
        Call<Void> call = chatInterface.addNewChat(chat);
        call.execute();
        currentChat = chat;

    }

    public void createChatDirectory() {

        new File(path).mkdirs();

    }

    //schreibt Nachricht in lokale Datei
    //Format: Userkey + ": " + {Inhalt der Nachricht} + (@*Timestamp*@)
    public void createMessage(ChatMessage chatMessage, int userkey) throws IOException {

        BufferedWriter output = null;

        File file = new File(Values.Dir_Path + File.separator + userkey + "-" + chatMessage.getChatid() + ".txt");

        try {
            //schreibt in lokale Datei
            file.getParentFile().mkdirs();
            file.createNewFile();
            output = new BufferedWriter(new FileWriter(file, true));
            output.write(chatMessage.getSenderid() + ": {" + chatMessage.getContent() + "}(@*" + chatMessage.getTimestamp() + "*@)\n");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (output != null) {
                output.close();
            }
        }
    }

    public void createChatFile(String chatkey, int userkey) throws IOException {

        File file = new File(path + File.separator + userkey + "-" + chatkey + ".txt");
        file.getParentFile().mkdirs();
        file.createNewFile();

    }

    //prüft, ob Chat Datei existiert
    public boolean directoryExists(String path) throws FileNotFoundException, UnsupportedEncodingException {

        File file = new File(path);
        return (file.exists());
    }

    public String createPrivateChatkey(List<User> chatMembers) {
        String userKeyString;
        List<Integer> sortedUserkeys = new ArrayList<>();
        sortedUserkeys.add(chatMembers.get(0).getUserkey());

        for (int i = 1; i < chatMembers.size(); i++) {
            if (chatMembers.get(i).getUserkey() > sortedUserkeys.get(i - 1)) {
                sortedUserkeys.add(chatMembers.get(i).getUserkey());
            } else {
                sortedUserkeys.add(i - 1, chatMembers.get(i).getUserkey());
            }

        }
        userKeyString = String.valueOf(sortedUserkeys.get(0));
        for (int i = 1; i < sortedUserkeys.size(); i++) {
            userKeyString = userKeyString + "-" + String.valueOf(sortedUserkeys.get(i));
        }
        return userKeyString;
    }

    public String createGroupChatkey(List<Integer> idComponents) {

        String keyString = String.valueOf(idComponents.get(0));
        for (int i = 1; i < idComponents.size(); i++) {
            keyString = keyString + "-" + String.valueOf(idComponents.get(i));
        }
        return keyString;
    }

    @Override
    public String toString() {
        return "ChatService{" +
                "groupMembers=" + chatPartners +
                '}';
    }

    public List<User> getUsersFromChatKey(String chatkey) throws IOException {
        String[] userkeys;
        userkeys = chatkey.split("-");
        int[] intkeys = new int[userkeys.length];
        for (int i = 0; i < userkeys.length; i++) {
            intkeys[i] = Integer.parseInt(userkeys[i]);
            userService.getUser(intkeys[i]);
            chatPartners.add(userService.getCurrentUser());
        }
        return chatPartners;
    }

    public Chat getCurrentChat() {
        return currentChat;
    }

    public List<Chat> getChatList() {
        return chatList;
    }


    @Override
    public void onResponse(Call<Chat> call, Response<Chat> response) {

    }

    @Override
    public void onFailure(Call<Chat> call, Throwable t) {
        t.printStackTrace();
    }

}




