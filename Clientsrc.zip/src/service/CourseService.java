package service;

import Interfaces.CourseInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Course;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class CourseService implements Callback<Course> {

    private Course currentCourse;
    private List<Course> courseList;
    private Gson gson;
    private Retrofit retrofit;
    CourseInterface courseInterface;

    public final String BASE_URL = Values.Base_URL;

    public CourseService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        courseInterface = retrofit.create(CourseInterface.class);
    }


    public void getCourseByID(int key) throws IOException {
        Call<Course> call = courseInterface.getCourseByID(key);
        currentCourse = call.execute().body();
    }

    public void getCourseByName(String name) throws IOException {
        Call<List<Course>> call = courseInterface.getCourseByName(name);
        courseList = call.execute().body();
    }

    public void getCoursesForSemester(String semester) throws IOException {
        Call<List<Course>> call = courseInterface.getCoursesForSemester(semester);
        courseList = call.execute().body();
    }


    public void addCourse(Course course) throws IOException {
        Call<Void> call = courseInterface.addNewCourse(course);
        call.execute().body();
        List<Course> tmp = new ArrayList<Course>();
        this.getCourseByName(course.getName());
        tmp = this.getCourseList();
        for (Course a : tmp) {
            if (a.equals(course)) {
                this.currentCourse = a;
            }
        }
    }


    public void getAll() throws IOException {
        Call<List<Course>> call = courseInterface.getAllCourses();
        courseList = call.execute().body();
    }

    public Course getCurrentCourse() {
        return currentCourse;
    }

    public void setCurrentCourse(Course currentCourse) {
        this.currentCourse = currentCourse;
    }

    public List<Course> getCourseList() {
        return courseList;
    }

    public void setCourseList(List<Course> courseList) {
        this.courseList = courseList;
    }

    @Override
    public void onResponse(Call<Course> call, Response<Course> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Course> call, Throwable t) {
        t.printStackTrace();
    }
}

