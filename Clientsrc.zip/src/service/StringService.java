package service;

import java.util.ArrayList;

public class StringService {

    //Fragenstatistik: Frage k antwort x wurde (int)(antwortField[k][x]) mal beantwortet
    int[][] antwortField;

    // User mit userkey userAtempts[x][0] hat das Quiz userAtempts[x][1] mal gemacht und  bestanden / nicht bestanden
    // userAtempts[x][2]
    int[][] userAtempts;
    int[][] answersFromPassed;
    int[][] answersFromFailed;
    int[] users;
    String[] fragen;
    String[] user;
    String userTeil;
    String fragenTeil;

    //value Beispiel: (1,0,0,0)-(2,0,0,0)-(2,0,0,0)/userkey@versuche+1-userkey@versuche+0
    public StringService(String value) {
        if (!value.equals("")) {
            loadValue(value);
            loadAntwortField();
            loadUserAtempts();
        }
    }

    //value Beispiel: (1,0,0,0)-(2,0,0,0)-(2,0,0,0)/(1,0,0,0)-(2,0,0,0)-(2,0,0,0)/47-54
    public void loadEval(String value) {
        String passed = value.split("/")[0];
        String failed = value.split("/")[1];
        String userstmp = value.split("/")[2];


        answersFromPassed = new int[passed.split("-").length][4];
        answersFromFailed = new int[failed.split("-").length][4];
        users = new int[userstmp.split("-").length];

        String[] tmpv;
        for (int i = 0; i < passed.split("-").length; i++) {
            tmpv = passed.split("-")[i].split("\\(");
            tmpv = tmpv[1].split("\\)");
            tmpv = tmpv[0].split(",");
            for (int k = 0; k < answersFromPassed[i].length; k++) {
                answersFromPassed[i][k] = Integer.parseInt(tmpv[k]);
            }
        }

        for (int i = 0; i < failed.split("-").length; i++) {
            tmpv = failed.split("-")[i].split("\\(");
            tmpv = tmpv[1].split("\\)");
            tmpv = tmpv[0].split(",");
            for (int k = 0; k < answersFromFailed[i].length; k++) {
                answersFromFailed[i][k] = Integer.parseInt(tmpv[k]);
            }
        }

        for (int i = 0; i < userstmp.split("-").length; i++) {
            users[i] = Integer.parseInt(userstmp.split("-")[i]);
        }

    }


    //fragen : (1,0,0,0)
    public void loadAntwortField() {
        String[] tmpv;
        //lade Fragenstatistik in Int Array
        for (int i = 0; i < fragen.length; i++) {
            tmpv = fragen[i].split("\\(");
            tmpv = tmpv[1].split("\\)");
            tmpv = tmpv[0].split(",");
            for (int k = 0; k < antwortField[i].length; k++) {
                antwortField[i][k] = Integer.parseInt(tmpv[k]);
            }
        }
    }

    //user: userkey@versuche+1
    public void loadUserAtempts() {
        String[] tmp;
        for (int i = 0; i < user.length; i++) {
            userAtempts[i][0] = Integer.parseInt(user[i].split("@")[0]);
            userAtempts[i][1] = Integer.parseInt(user[i].split("@")[1].split("\\+")[0]);
            userAtempts[i][2] = Integer.parseInt(user[i].split("@")[1].split("\\+")[1]);
        }

    }


    // userkey : userkey von sqltable
    //grade: 1 für bestanden(mehr als 50% richtig beantwortet) , 0 für nicht bestanden(weniger als 50% richtig beantwortet)
    // !!!!loadUserAtempts ist hier nicht nötig, da das Array direkt verändert wird!!!
    public void addUserAtemptAndUserGrade(int userkey, int grade) {
        for (int i = 0; i < userAtempts.length; i++) {
            if (userAtempts[i][0] == userkey) {
                userAtempts[i][1] = userAtempts[i][1] + 1;
                if (userAtempts[i][2] == 0) {
                    userAtempts[i][2] = grade;
                }
            }
        }
    }


    //lade den String zur Bewertung
    public void loadValue(String value) {
        //fragenTeil : (1,0,0,0)-(2,0,0,0)-(2,0,0,0)
        fragenTeil = value.split("/")[0];
        //userTeil: userkey@versuche+1-userkey@versuche+0
        userTeil = value.split("/")[1];
        //fragen : (1,0,0,0)
        if (fragenTeil.contains("-")) {
            fragen = fragenTeil.split("-");
        } else {
            fragen = new String[]{fragenTeil};
        }
        //user : userkey@versuche+1
        user = userTeil.split("-");
        antwortField = new int[fragen.length][4];
        userAtempts = new int[user.length][3];

    }


    // Füge der Frage k die Werte in Value hinzu
    // value : (int,int,int,int) k: fragenummer
    // nach allen addFragenResult operationen muss ein loadAntwortField erfolgen.
    // nur so bleibt das antwortField up to date.
    public void addFragenResult(String value, int k) {
        String[] tmpv = value.split("\\(");
        tmpv = tmpv[1].split("\\)");
        tmpv = tmpv[0].split(",");
        String[] tmpf = fragen[k].split("\\(");
        tmpf = tmpf[1].split("\\)");
        tmpf = tmpf[0].split(",");

        for (int i = 0; i < tmpv.length; i++) {
            tmpf[i] = String.valueOf(Integer.parseInt(tmpf[i]) + Integer.parseInt(tmpv[i]));
        }
        String result = "(";
        for (String a : tmpf) {
            result = result + a + ",";
        }
        result = result.substring(0, result.length() - 1) + ")";
        fragen[k] = result;
        loadAntwortField();

    }


    //value Beispiel: (1,0,0,0)-(2,0,0,0)-(2,0,0,0)/userkey@versuche+1-userkey@versuche+0
    public String buildString() {
        String result = "";
        for (int[] a : antwortField) {
            result = result + "(" + a[0] + "," + a[1] + "," + a[2] + "," + a[3] + ")";
            if (!a.equals(antwortField[antwortField.length - 1])) {
                result = result + "-";
            }
        }

        result = result + "/";

        for (int[] a : userAtempts) {
            result = result + a[0] + "@" + a[1] + "+" + a[2];
            if (!a.equals(userAtempts[userAtempts.length - 1])) {
                result = result + "-";
            }
        }

        return result;
    }

    public void extendUserAtempts(int userkey, int bestanden) {
        int[][] tmp = new int[userAtempts.length + 1][3];
        for (int i = 0; i < userAtempts.length; i++) {
            tmp[i] = userAtempts[i];
        }
        tmp[tmp.length - 1][0] = userkey;
        tmp[tmp.length - 1][1] = 1;
        tmp[tmp.length - 1][2] = bestanden;

        userAtempts = tmp;
    }


    public String buildStringEval() {
        String result = "";
        for (int[] a : answersFromPassed) {
            result = result + "(" + a[0] + "," + a[1] + "," + a[2] + "," + a[3] + ")";
            if (!a.equals(answersFromPassed[answersFromPassed.length - 1])) {
                result = result + "-";
            }
        }

        result = result + "/";

        for (int[] a : answersFromFailed) {
            result = result + "(" + a[0] + "," + a[1] + "," + a[2] + "," + a[3] + ")";
            if (!a.equals(answersFromFailed[answersFromFailed.length - 1])) {
                result = result + "-";
            }
        }
        result = result + "/";
        for (int a : users) {
            result = result + a;
            if (a != (users[users.length - 1])) {
                result = result + "-";
            }
        }

        return result;
    }

    public void addUserToEvalList(int userkey) {

        int[] tmp = new int[users.length + 1];

        for (int k = 0; k < users.length; k++) {
            tmp[k] = users[k];
        }
        tmp[tmp.length - 1] = userkey;
        users = tmp;
    }


    public ArrayList<Integer> passedList() {
        ArrayList<Integer> tmp = new ArrayList<>();
        for (int[] a : userAtempts) {
            if (a[2] == 1) {
                tmp.add(a[0]);
            }
        }

        return tmp;
    }

    public boolean hasDoneQuiz(int userkey) {
        for (int[] a : userAtempts) {
            if (a[0] == userkey) {
                return true;
            }
        }
        return false;
    }

    public int[] getUsers() {
        return users;
    }

    public void setUsers(int[] users) {
        this.users = users;
    }

    public int[][] getUserAtempts() {
        return userAtempts;
    }

    public void setUserAtempts(int[][] userAtempts) {
        this.userAtempts = userAtempts;
    }

    public String[] getUser() {
        return user;
    }

    public void setUser(String[] user) {
        this.user = user;
    }

    public String[] getFragen() {
        return fragen;
    }

    public void setFragen(String[] fragen) {
        this.fragen = fragen;
    }

    public String getUserTeil() {
        return userTeil;
    }

    public void setUserTeil(String userTeil) {
        this.userTeil = userTeil;
    }

    public String getFragenTeil() {
        return fragenTeil;
    }

    public void setFragenTeil(String fragenTeil) {
        this.fragenTeil = fragenTeil;
    }

    public int[][] getAntwortField() {
        return antwortField;
    }

    public void setAntwortField(int[][] antwortField) {
        this.antwortField = antwortField;
    }

    public int[][] getAnswersFromPassed() {
        return answersFromPassed;
    }

    public void setAnswersFromPassed(int[][] answersFromPassed) {
        this.answersFromPassed = answersFromPassed;
    }

    public int[][] getAnswersFromFailed() {
        return answersFromFailed;
    }

    public void setAnswersFromFailed(int[][] answersFromFailed) {
        this.answersFromFailed = answersFromFailed;
    }
}
