package service;

import Interfaces.LecturerInterface;
import Interfaces.MailInterface;
import com.google.gson.GsonBuilder;
import model.Course;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import value.Values;

import java.io.IOException;

public class MailService implements Callback<Void> {
    Gson gson;
    Retrofit retrofit;
    MailInterface mailInterface;
    public final String BASE_URL = Values.Base_URL;
    Response<Boolean> result;
    String code;

    public MailService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        mailInterface = retrofit.create(MailInterface.class);
    }

    public void sendMailTo(String to, String subj, String text) throws IOException {
        Call<Boolean> call = mailInterface.sendMailTo(to, subj, text);

        result = call.execute();

    }

    public void generateCode(String email) throws IOException {
        Call<String> call = mailInterface.generateCode(email);
        code = call.execute().body();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public void onResponse(Call<Void> call, Response<Void> response) {

    }


    @Override
    public void onFailure(Call<Void> call, Throwable t) {

    }
}
