package service;

import Interfaces.UserInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.List;


//Hier werden alle Antworten des Servvers bzgl des User abgespeichert, auf die wir im Client zugreifen können
public class UserService implements Callback<User> {
    private User currentUser;
    private List<User> userList;
    public final String BASE_URL = Values.Base_URL;
    Gson gson;
    Retrofit retrofit;
    UserInterface userInterface;

    public UserService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        userInterface = retrofit.create(UserInterface.class);
    }

    public void getUser(int key) throws IOException {
        userInterface = retrofit.create(UserInterface.class);

        Call<User> call = userInterface.getUserById(key);
        currentUser = call.execute().body();
        System.out.println("test");
    }

    public void getUserByEmail(String mail) throws IOException {
        userInterface = retrofit.create(UserInterface.class);

        Call<User> call = userInterface.getUserByEmail(mail);

        currentUser = call.execute().body();

    }

    public void getAllUser() throws IOException {
        userInterface = retrofit.create(UserInterface.class);

        Call<List<User>> call = userInterface.getAllUser();
        userList = call.execute().body();

    }


    public void setUser(User user) throws IOException {
        userInterface = retrofit.create(UserInterface.class);

        Call<Void> call = userInterface.setUser(user);
        call.execute();
        currentUser = user;

    }


    public User getCurrentUser() {
        return currentUser;
    }

    public List<User> getUserList() {
        return userList;
    }


    @Override
    public void onResponse(Call<User> call, Response<User> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<User> call, Throwable t) {
        t.printStackTrace();
    }


}


