package service;

import Interfaces.CourseInterface;
import Interfaces.LearningMaterialInterface;
import Interfaces.ParticipantInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Course;
import model.LearningMaterial;
import model.User;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class LearningMaterialService implements Callback<LearningMaterial> {


    private LearningMaterial material;
    ResponseBody responseBody;

    private List<LearningMaterial> listOfMaterial;
    Gson gson;
    Retrofit retrofit;
    LearningMaterialInterface learningMaterialInterface;

    public final String BASE_URL = Values.Base_URL;

    public LearningMaterialService() {
        listOfMaterial = new ArrayList<>();
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        learningMaterialInterface = retrofit.create(LearningMaterialInterface.class);
    }

    public void addMaterial(LearningMaterial material) throws IOException {


        learningMaterialInterface = retrofit.create(LearningMaterialInterface.class);

        Call<Void> call = learningMaterialInterface.addMaterial(material);
        call.execute();
    }

    public void deleteMaterial(int learningmaterialkey) throws IOException {
        learningMaterialInterface = retrofit.create(LearningMaterialInterface.class);

        Call<Void> call = learningMaterialInterface.deleteMaterial(learningmaterialkey);
        call.execute();
    }

    public void getMaterialbyCourseKey(int coursekey) throws IOException {

        learningMaterialInterface = retrofit.create(LearningMaterialInterface.class);
        Call<List<LearningMaterial>> call = learningMaterialInterface.getMaterialByCourseKey(coursekey);
        listOfMaterial = call.execute().body();
    }

    public void getMaterialbyKey(int materialkey) throws IOException {

        learningMaterialInterface = retrofit.create(LearningMaterialInterface.class);
        Call<LearningMaterial> call = learningMaterialInterface.getMaterialByMaterialKey(materialkey);
        material = call.execute().body();


    }

    public Byte[] downloadMaterial(int key) throws IOException {

        learningMaterialInterface = retrofit.create(LearningMaterialInterface.class);
        Call<Byte[]> call = learningMaterialInterface.downloadMaterial(key);

        return call.execute().body();

    }

    public List<LearningMaterial> getListOfMaterial() {
        return listOfMaterial;
    }


    @Override
    public void onResponse(Call<LearningMaterial> call, Response<LearningMaterial> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<LearningMaterial> call, Throwable t) {
        t.printStackTrace();
    }
}
