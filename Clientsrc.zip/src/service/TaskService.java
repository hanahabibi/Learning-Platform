package service;

import Interfaces.LearningMaterialInterface;
import Interfaces.ParticipantInterface;
import Interfaces.StudentInterface;
import Interfaces.TaskInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.*;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TaskService implements Callback<Task> {
    private Task task;
    ResponseBody responseBody;

    private List<Task> listOfTasks;
    Gson gson;
    Retrofit retrofit;
    TaskInterface taskInterface;

    public final String BASE_URL = "http://localhost:8080";

    public TaskService() {
        listOfTasks = new ArrayList<>();
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        taskInterface = retrofit.create(TaskInterface.class);
    }

    public void addTask(Task task) throws IOException {


        taskInterface = retrofit.create(TaskInterface.class);

        Call<Void> call = taskInterface.addTask(task);
        call.execute();
    }


    public void getTaskbyCourseKey(int coursekey) throws IOException {

        taskInterface = retrofit.create(TaskInterface.class);
        Call<List<Task>> call = taskInterface.getTaskByCourseKey(coursekey);
        listOfTasks = call.execute().body();
    }

    public void getTaskByTaskKey(int taskkey) throws IOException {

        taskInterface = retrofit.create(TaskInterface.class);
        Call<Task> call = taskInterface.getTaskByTaskKey(taskkey);
        task = call.execute().body();


    }

    public Task getCurrentTask() {
        return task;
    }


    public List<Task> getListOfTasks() {
        return listOfTasks;
    }


    @Override
    public void onResponse(Call<Task> call, Response<Task> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Task> call, Throwable t) {
        t.printStackTrace();
    }
}
