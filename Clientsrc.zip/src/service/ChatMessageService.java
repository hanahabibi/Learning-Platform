package service;

import Interfaces.ChatInterface;
import Interfaces.ChatMessageInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.ChatMessage;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChatMessageService implements Callback<ChatMessage> {

    private List<ChatMessage> chatMessageList;

    String path = Values.Dir_Path;
    Gson gson;
    Retrofit retrofit;
    ChatMessageInterface chatMessageInterface;
    public final String BASE_URL = "http://localhost:8080";

    public ChatMessageService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        chatMessageInterface = retrofit.create(ChatMessageInterface.class);
    }

    public void addChatMessage(ChatMessage chatMessage) throws IOException {

        Call<Void> call = chatMessageInterface.addNewMessage(chatMessage);
        call.execute();
    }

    public void getChatMessageByChatID(int chatID) throws IOException {
        Call<List<ChatMessage>> call = chatMessageInterface.getMessageByChatID(chatID);
        chatMessageList = call.execute().body();

    }

    public void getChatMessageByMessageID(int messageID) throws IOException {
        Call<ChatMessage> call = chatMessageInterface.getMessageByMessageId(messageID);
        chatMessageList = new ArrayList<>();
        chatMessageList.add(call.execute().body());
    }

    public void getChatMessageBySenderID(int senderID) throws IOException {
        Call<List<ChatMessage>> call = chatMessageInterface.getMessageBySenderId(senderID);
        chatMessageList = call.execute().body();

    }

    public void getChatMessageByReceiverID(int receiverID) throws IOException {
        Call<List<ChatMessage>> call = chatMessageInterface.getMessageByReceiverId(receiverID);
        chatMessageList = call.execute().body();

    }

    public void getALlChatMessage() throws IOException {
        Call<List<ChatMessage>> call = chatMessageInterface.getAllMessages();
        chatMessageList = call.execute().body();
    }

    public void deleteChatMessage(ChatMessage message) throws IOException {
        Call<Void> call = chatMessageInterface.deleteChatMessage(message);
        call.execute();
    }

    public List<ChatMessage> getChatMessageList() {
        return chatMessageList;
    }

    public void setChatMessageList(List<ChatMessage> chatMessageList) {
        this.chatMessageList = chatMessageList;
    }

    @Override
    public void onResponse(Call<ChatMessage> call, Response<ChatMessage> response) {

    }

    @Override
    public void onFailure(Call<ChatMessage> call, Throwable throwable) {

    }
}
