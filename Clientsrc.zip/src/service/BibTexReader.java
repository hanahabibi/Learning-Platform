package service;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class BibTexReader {

    //Listen in denen die Attribute gespeichert werden -> 21
    static ObservableList<String> type = FXCollections.observableArrayList();
    static ObservableList<String> title = FXCollections.observableArrayList();
    static ObservableList<String> author = FXCollections.observableArrayList();
    static ObservableList<String> publisher = FXCollections.observableArrayList();
    static ObservableList<String> year = FXCollections.observableArrayList();
    static ObservableList<String> pages = FXCollections.observableArrayList();
    static ObservableList<String> volume = FXCollections.observableArrayList();
    static ObservableList<String> number = FXCollections.observableArrayList();
    static ObservableList<String> isbn = FXCollections.observableArrayList();
    static ObservableList<String> journal = FXCollections.observableArrayList();
    static ObservableList<String> doi = FXCollections.observableArrayList();
    static ObservableList<String> keywords = FXCollections.observableArrayList();
    static ObservableList<String> booktitle = FXCollections.observableArrayList();
    static ObservableList<String> address = FXCollections.observableArrayList();
    static ObservableList<String> series = FXCollections.observableArrayList();
    static ObservableList<String> url = FXCollections.observableArrayList();
    static ObservableList<String> urldate = FXCollections.observableArrayList();
    static ObservableList<String> file = FXCollections.observableArrayList();
    static ObservableList<String> price = FXCollections.observableArrayList();
    static ObservableList<String> editor = FXCollections.observableArrayList();
    static ObservableList<String> institution = FXCollections.observableArrayList();
    static ObservableList<String> abstrakt = FXCollections.observableArrayList();

    //Liste in der alle Attributlisten gespeichert sind
    static ObservableList<ObservableList<String>> infos = FXCollections.observableArrayList();

    //liest die Datei aus und gibt einen an "@" gesplitteten String zurück
    public static String[] fileAsString(File file) throws IOException {

        InputStream is = new FileInputStream(file);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));

        String line = br.readLine();
        StringBuilder sb = new StringBuilder();

        while (line != null) {

            if (line.contains("@")) {
                type.add(line.substring(line.indexOf("@") + 1, line.indexOf("{")));
            }
            sb.append(line).append("\n");
            line = br.readLine();

        }
        String fileAsString = sb.toString();

        return fileAsString.split("@"); //book{...}, article{...} etc.
    }


    //liest die Attribute aus dem String aus und speichert sie in der jeweiligen Liste
    public static ObservableList<ObservableList<String>> readAttributes(String[] literature/*, ObservableList<String> types*/) {
        if (infos.isEmpty()) {
            type.add(" type ");
            title.add(" title ");
            author.add(" author ");
            publisher.add(" publisher ");
            year.add(" year ");
            pages.add(" pages ");
            volume.add(" volume ");
            number.add(" number ");
            isbn.add(" isbn ");
            journal.add(" journal ");
            doi.add(" doi ");
            keywords.add(" keywords ");
            booktitle.add(" booktitle ");
            address.add(" address ");
            series.add(" series ");
            url.add(" url ");
            urldate.add(" urldate ");
            file.add(" file ");
            price.add(" price ");
            editor.add(" editor ");
            institution.add(" institution ");
            abstrakt.add(" abstract ");

            infos.addAll(
                    type, title, author, publisher, year, pages, volume,
                    number, isbn, journal, doi, keywords, booktitle,
                    address, series, url, urldate, file, price,
                    editor, institution, abstrakt);

            cleanTypes(type);

            //literature[] enthält book{...}, article{...} etc.
            //geht jedes Element aus Literature durch
            for (int k = 1; k < literature.length; k++) {

                //attributes[] enthält author = ..., title = ... etc.
                String[] attributes = literature[k].split("\n");
                for (int i = 1; i < attributes.length - 1; i++) {
                    //tmp trennt die Attribute in Bezeichnung und Inhalt
                    String[] tmp = attributes[i].split("=");
                    for (int j = 0; j < tmp.length - 1; j = j + 2) {
                        List<String> attributeName = new ArrayList<>();
                        List<String> actualAttribute = new ArrayList<>();
                        attributeName.add(tmp[j]);
                        actualAttribute.add(tmp[j + 1]);

                        for (int h = 0; h < actualAttribute.size(); h++) {
                            //geht die Listen durch -> wenn Liste das gegebene Attribut enthält wird es hinzugefügt
                            for (ObservableList<String> a : infos) {
                                if (!a.get(0).contains("type")) {
                                    if (a.get(0).equals(attributeName.get(h))) {

                                        if (a.get(0).equals(" publisher ")) {
                                            a.add(actualAttribute.get(h).substring(actualAttribute.get(h).lastIndexOf("{") + 1, actualAttribute.get(h).lastIndexOf("}")));
                                        } else {
                                            if (actualAttribute.get(h).charAt(actualAttribute.get(h).length() - 1) != '}' && actualAttribute.get(h).charAt(actualAttribute.get(h).length() - 1) != ',') {
                                                a.add(actualAttribute.get(h).substring(actualAttribute.get(h).indexOf("{")));
                                            } else {
                                                a.add(actualAttribute.get(h).substring(actualAttribute.get(h).indexOf("{"), actualAttribute.get(h).lastIndexOf("}")));
                                            }
                                        }
                                    }
                                }
                                if (actualAttribute.get(h).equals(" issn ")) {
                                    if (!actualAttribute.get(h).contains("},")) {
                                        isbn.add(actualAttribute.get(h).substring(actualAttribute.get(h).indexOf("{") + 1, actualAttribute.get(h).indexOf("}")));
                                    } else {
                                        isbn.add(actualAttribute.get(h).substring(actualAttribute.get(h).indexOf("{") + 1, actualAttribute.get(h).indexOf("},")));
                                    }
                                }
                            }
                        }
                    }
                }
                fillSpaces(infos);
            }
            setLength(infos.get(17));

            infos.get(0).add(0, " type ");
            infos.get(0).remove(infos.get(0).size() - 1);
        }

        return infos;
    }

    //füllt alle leeren Einträge mit ---
    public static void fillSpaces(ObservableList<ObservableList<String>> list) {
        int maxSize = 0;
        for (ObservableList<String> a : list) {
            if (!a.equals(infos.get(0))) {
                if (a.equals(infos.get(17)) && a.size() > maxSize) {
                    maxSize = maxSize + 1;
                } else {
                    if (a.size() > maxSize) {
                        maxSize = a.size();
                    }
                }
            }
        }
        for (ObservableList<String> a : list) {
            if (!a.equals(infos.get(0)) && !a.equals(infos.get(17))) {
                while (a.size() < maxSize) {
                    a.add("---");
                }
            }
        }
    }

    //filtert das Attribut "Typ" aus der Datei
    public static void cleanTypes(ObservableList<String> types) {

        ObservableList<String> cleanedTypes = FXCollections.observableArrayList();
        for (String str : types) {
            if (str.equals("book")) {
                cleanedTypes.add("Buch");
            } else if (str.equals("article")) {
                cleanedTypes.add("Artikel");
            } else if (str.equals("proceedings")) {
                cleanedTypes.add("Proceedings");
            } else if (str.equals("inproceedings")) {
                cleanedTypes.add("Inproceedings");
            } else if (str.equals("incollection")) {
                cleanedTypes.add("Inkollektion");
            } else if (str.equals("misc")) {
                cleanedTypes.add("Verschiedene");
            } else if (str.equals("phdthesis")) {
                cleanedTypes.add("Doktorarbeit");
            } else if (str.equals("---")) {
                cleanedTypes.remove(str);
            } else {
                cleanedTypes.add(str);
            }
        }
        infos.set(0, cleanedTypes);
    }

    public static void setLength(ObservableList<String> list) {
        while (list.size() < infos.get(0).size()) {
            list.add("---");
        }
        while (list.size() > infos.get(0).size()) {
            list.remove(list.size() - 1);
        }
    }

    //liest Sonderzeichen aus und entfernt überflüssige Klammern
    public static String formatEntries(String entry) {
        String result = entry;
        int index = 0;
        while (result.contains("\\\"O") || result.contains("\\\"O")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("\\\"");
            int endIndex = index + 4;
            tmp.delete(index, endIndex);
            tmp.insert(index, "ö");
            result = tmp.toString();
        }
        while (result.contains("\\\"A") || result.contains("\\\"a")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("\\\"");
            int endIndex = index + 4;
            tmp.delete(index, endIndex);
            tmp.insert(index, "ä");
            result = tmp.toString();
        }
        while (result.contains("\\\"U") || result.contains("\\\"u")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("\\\"");
            int endIndex = index + 4;
            tmp.delete(index, endIndex);
            tmp.insert(index, "ü");
            result = tmp.toString();
        }
        while (result.contains("{\\pounds}")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("{");
            int endIndex = result.indexOf("}");
            tmp.delete(index, endIndex);
            tmp.insert(index, "£");
            result = tmp.toString();
        }
        while (result.contains("{")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("{");
            tmp.deleteCharAt(index);
            result = tmp.toString();
        }
        while (result.contains("}")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("}");
            tmp.deleteCharAt(index);
            result = tmp.toString();
        }
        while (result.contains("[")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("[");
            tmp.deleteCharAt(index);
            result = tmp.toString();
        }
        while (result.contains("]")) {
            StringBuilder tmp = new StringBuilder(result);
            index = result.indexOf("]");
            tmp.deleteCharAt(index);
            result = tmp.toString();
        }
        return result;
    }

}
