package service;

import Interfaces.ParticipantInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Participant;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ParticipantService implements Callback<Participant> {


    List<Participant> currentParticipantList;
    Gson gson;
    Retrofit retrofit;
    ParticipantInterface participantInterface;
    public final String BASE_URL = Values.Base_URL;

    public ParticipantService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        participantInterface = retrofit.create(ParticipantInterface.class);
        currentParticipantList = new ArrayList<>();
    }

    public void addNewParticipant(Participant participant) throws IOException {
        participantInterface = retrofit.create(ParticipantInterface.class);

        Call<Void> call = participantInterface.addNewParticipant(participant);
        call.execute();
    }

    public void passParticipant(int participantkey) throws IOException {

        participantInterface = retrofit.create(ParticipantInterface.class);

        Call<Void> call = participantInterface.passParticipant(participantkey);
        call.execute();
    }

    public void getParticipantsOfCourse(int courseKey) throws IOException {
        participantInterface = retrofit.create(ParticipantInterface.class);

        Call<List<Participant>> call = participantInterface.getParticipantByCouresKey(courseKey);
        currentParticipantList = call.execute().body();
    }

    public void getParticipant(int userKey) throws IOException {
        participantInterface = retrofit.create(ParticipantInterface.class);

        Call<List<Participant>> call = participantInterface.getParticipantByUserKey(userKey);
        currentParticipantList = call.execute().body();
    }

    @Override
    public void onResponse(Call<Participant> call, Response<Participant> response) {

    }

    @Override
    public void onFailure(Call<Participant> call, Throwable t) {
        t.printStackTrace();
    }

    public List<Participant> getCurrentParticipantList() {
        return currentParticipantList;
    }


}

