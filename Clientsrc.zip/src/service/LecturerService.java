package service;

import Interfaces.LecturerInterface;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import exception.LecturerNotFoundException;
import model.Lecturer;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.List;

public class LecturerService implements Callback<Lecturer> {
    private Lecturer currentLecturer;
    private List<Lecturer> LecturerList;
    Gson gson;
    Retrofit retrofit;
    LecturerInterface lecturerInterface;
    public final String BASE_URL = Values.Base_URL;

    public LecturerService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        lecturerInterface = retrofit.create(LecturerInterface.class);
    }

    public void getLecturerByID(int key) throws IOException, LecturerNotFoundException {
        lecturerInterface = retrofit.create(LecturerInterface.class);

        Call<Lecturer> call = lecturerInterface.getLecturerByID(key);
        currentLecturer = call.execute().body();
    }

    public void getLecturerByUserKey(int key) throws IOException, LecturerNotFoundException {
        lecturerInterface = retrofit.create(LecturerInterface.class);

        Call<Lecturer> call = lecturerInterface.getLecturerByUserKey(key);
        currentLecturer = call.execute().body();

    }

    public void getAllLecturer() throws IOException {
        lecturerInterface = retrofit.create(LecturerInterface.class);

        Call<List<Lecturer>> call = lecturerInterface.getAllLecturer();
        LecturerList = call.execute().body();

    }

    public void setLecturer(Lecturer Lecturer) throws IOException {
        lecturerInterface = retrofit.create(LecturerInterface.class);

        Call<Void> call = lecturerInterface.setLecturer(Lecturer);
        call.execute();
        currentLecturer = Lecturer;

    }

    public Lecturer getCurrentLecturer() {
        return currentLecturer;
    }

    public List<Lecturer> getLecturerList() {
        return LecturerList;
    }


    @Override
    public void onResponse(Call<Lecturer> call, Response<Lecturer> response) {
        if (response.isSuccessful()) {
            Lecturer changesList = response.body();
            currentLecturer = changesList;
            System.out.println(changesList.toString());
        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Lecturer> call, Throwable t) {
        t.printStackTrace();
    }
}

