package service;

import Interfaces.SemesterInterface;
import Interfaces.StudentInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import exception.StudentNotFoundException;
import model.Semester;
import model.Student;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.List;

public class SemesterService implements Callback<Semester> {

    private Semester currentSemester;
    private List<Semester> semesterList;
    Gson gson;
    Retrofit retrofit;
    SemesterInterface semesterInterface;
    public final String BASE_URL = Values.Base_URL;

    public SemesterService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        semesterInterface = retrofit.create(SemesterInterface.class);
    }

    public void getSemesterById(int semesterid) throws IOException {
        semesterInterface = retrofit.create(SemesterInterface.class);

        Call<Semester> call = semesterInterface.getSemesterById(semesterid);
        currentSemester = call.execute().body();
    }

    public void getAllSemester() throws IOException {
        semesterInterface = retrofit.create(SemesterInterface.class);

        Call<List<Semester>> call = semesterInterface.getAllSemester();
        semesterList = call.execute().body();

    }

    public void getSemesterByName(String name) throws IOException {
        semesterInterface = retrofit.create(SemesterInterface.class);

        Call<Semester> call = semesterInterface.getSemesterByName(name);
        currentSemester = call.execute().body();
    }


    public void addSemester(Semester semester) throws IOException {
        semesterInterface = retrofit.create(SemesterInterface.class);

        Call<Void> call = semesterInterface.addSemester(semester);
        call.execute();
        currentSemester = semester;

    }

    public Semester getCurrentSemester() {
        return currentSemester;
    }


    public List<Semester> getSemesterList() {
        return semesterList;
    }

    public void setCurrentSemester(Semester currentSemester) {
        this.currentSemester = currentSemester;
    }

    public void setSemesterList(List<Semester> semesterList) {
        this.semesterList = semesterList;
    }

    @Override
    public void onResponse(Call<Semester> call, Response<Semester> response) {

    }

    @Override
    public void onFailure(Call<Semester> call, Throwable t) {

    }
}
