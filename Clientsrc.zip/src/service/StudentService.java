package service;


import Interfaces.StudentInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import exception.StudentNotFoundException;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import model.Student;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


import java.io.IOException;
import java.util.*;


public class StudentService implements Callback<Student> {

    private Student currentStudent;
    private List<Student> studentList;
    Gson gson;
    Retrofit retrofit;
    StudentInterface studentInterface;
    public final String BASE_URL = "http://localhost:8080";

    public StudentService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        studentInterface = retrofit.create(StudentInterface.class);
    }

    public void getStudentByID(int key) throws IOException, StudentNotFoundException {
        studentInterface = retrofit.create(StudentInterface.class);

        Call<Student> call = studentInterface.getStudentByID(key);
        currentStudent = call.execute().body();
    }

    public void getStudentByUserKey(int key) throws IOException, StudentNotFoundException {
        studentInterface = retrofit.create(StudentInterface.class);

        Call<Student> call = studentInterface.getStudentByUserKey(key);
        currentStudent = call.execute().body();
    }

    public void getAllStudent() throws IOException {
        studentInterface = retrofit.create(StudentInterface.class);

        Call<List<Student>> call = studentInterface.getAllStudent();
        studentList = call.execute().body();

    }

    public void setStudent(Student student) throws IOException {
        studentInterface = retrofit.create(StudentInterface.class);

        Call<Void> call = studentInterface.setstudent(student);
        call.execute();
        currentStudent = student;

    }


    public ObservableList<Student> getListOfFriends(Student student) throws StudentNotFoundException, IOException {

        ObservableList<Student> result = FXCollections.observableArrayList();
        if (student.getFriends() != null) {
            if (!student.getFriends().equals("")) {
                String[] studentl = student.getFriends().split(" ");
                int[] studentlint = new int[studentl.length];
                if (studentl.length > 0) {
                    for (int i = 0; i < studentl.length; i++) {
                        studentlint[i] = Integer.parseInt(studentl[i]);
                        getStudentByUserKey(studentlint[i]);
                        result.add(getCurrentStudent());
                    }
                }
            }
        }
        return result;
    }


    public ObservableList<Student> getFriendsByFState(Student student, int fstate) throws StudentNotFoundException, IOException {

        ObservableList<Student> result = FXCollections.observableArrayList();
        ObservableList<Student> allFriends = getListOfFriends(student);
        if (getFStates(student).length != 0) {
            int[] fStates = getFStates(student);
            for (int i = 0; i < allFriends.size(); i++) {
                if (fStates[i] == fstate) {
                    result.add(allFriends.get(i));
                }
            }
        }
        return result;
    }

    public int[] getFStates(Student student) {
        if (student.getFstate() != null) {
            if (!student.getFstate().equals("")) {
                String[] splitted = student.getFstate().split(" ");
                int[] result = new int[splitted.length];

                for (int i = 0; i < splitted.length; i++) {
                    result[i] = Integer.parseInt(splitted[i]);
                }
                return result;
            }
        }
        return new int[0];
    }

    public int[] getFriends(Student student) {
        if (!student.getFriends().equals("")) {
            String[] splitted = student.getFriends().split(" ");
            int[] result = new int[splitted.length];

            for (int i = 0; i < splitted.length; i++) {
                result[i] = Integer.parseInt(splitted[i]);
            }
            return result;
        }
        return new int[0];
    }

    public Student getCurrentStudent() {
        return currentStudent;
    }


    public List<Student> getStudentList() {
        return studentList;
    }


    @Override
    public void onResponse(Call<Student> call, Response<Student> response) {
        System.out.println(response.message());

    }


    @Override
    public void onFailure(Call<Student> call, Throwable t) {
        t.printStackTrace();
    }
}
