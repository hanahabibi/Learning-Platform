package service;

import Interfaces.LearningMaterialInterface;
import Interfaces.TopicInterface;
import Interfaces.UserInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Course;
import model.Topic;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.List;

public class TopicService implements Callback<Topic> {

    private Topic currentTopic;
    private List<Topic> topicList;
    private Gson gson;
    private Retrofit retrofit;
    TopicInterface topicInterface;

    public final String BASE_URL = "http://localhost:8080";

    public TopicService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        topicInterface = retrofit.create(TopicInterface.class);
    }

    public void getTopicByTopickey(int topickey) throws IOException {
        Call<Topic> call = topicInterface.getTopicByTopickey(topickey);
        currentTopic = call.execute().body();
    }

    public void getTopicByTitle(String title) throws IOException {
        Call<Topic> call = topicInterface.getTopicByTitle(title);
        currentTopic = call.execute().body();
    }

    public ObservableList<Topic> getTopicsByLecturerkey(int lecturerkey) throws IOException {
        Call<List<Topic>> call = topicInterface.getAllTopics();
        ObservableList<Topic> topicsByLecturer = FXCollections.observableArrayList();
        topicList = call.execute().body();
        List<Topic> tmp = getTopicList();
        for (Topic a : tmp) {
            if (a.getLecturerkey() == lecturerkey) {
                topicsByLecturer.add(a);
            }
        }
        return topicsByLecturer;
    }

    public void addTopic(Topic topic) throws IOException {
        topicInterface = retrofit.create(TopicInterface.class);

        Call<Void> call = topicInterface.addNewTopic(topic);
        call.execute();
        currentTopic = topic;
    }

    public void deleteTopic(int topickey) throws IOException {
        topicInterface = retrofit.create(TopicInterface.class);

        Call<Void> call = topicInterface.deleteTopic(topickey);
        call.execute();
    }

    public void getAll() throws IOException {
        Call<List<Topic>> call = topicInterface.getAllTopics();
        topicList = call.execute().body();
    }

    public Topic getCurrentTopic() {
        return currentTopic;
    }

    public void setCurrentTopic(Topic currentTopic) {
        this.currentTopic = currentTopic;
    }

    public List<Topic> getTopicList() {
        return topicList;
    }

    public void setTopicList(List<Topic> topicList) {
        this.topicList = topicList;
    }

    @Override
    public void onResponse(Call<Topic> call, Response<Topic> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Topic> call, Throwable t) {
        t.printStackTrace();
    }
}


