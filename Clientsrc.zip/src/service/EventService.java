package service;

import Interfaces.EventInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Event;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import value.Values;

import java.io.IOException;
import java.util.List;


public class EventService implements Callback<Event> {

    private Event currentEvent;
    private List<Event> eventList;
    private Gson gson;
    private Retrofit retrofit;
    EventInterface eventInterface;

    public final String BASE_URL = Values.Base_URL;

    public EventService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        eventInterface = retrofit.create(EventInterface.class);
    }


    public void getEventByID(int eventID) throws IOException {
        Call<Event> call = eventInterface.getEventByID(eventID);
        currentEvent = call.execute().body();
    }


    public void addEvent(Event event) throws IOException {
        Call<Void> call = eventInterface.addNewEvent(event);
        call.execute().body();
    }


    public void getALLEventsForCourse(int coursekey) throws IOException {
        Call<List<Event>> call = eventInterface.getALLEventsForCourse(coursekey);
        eventList = call.execute().body();
    }



    public Event getCurrentEvent() {
        return currentEvent;
    }

    public void setCurrentCourse(Event currentEvent) {
        this.currentEvent = currentEvent;
    }

    public List<Event> getEventList() {
        return eventList;
    }

    public void setEventList(List<Event> eventList) {
        this.eventList = eventList;
    }


    @Override
    public void onResponse(Call<Event> call, Response<Event> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Event> call, Throwable t) {
        t.printStackTrace();
    }
}
