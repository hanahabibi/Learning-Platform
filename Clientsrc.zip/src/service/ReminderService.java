package service;

import Interfaces.EventInterface;
import Interfaces.ReminderInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Event;
import model.Reminder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Path;
import value.Values;


import java.io.IOException;
import java.util.List;

public class ReminderService implements Callback<Reminder> {
    private Reminder currentReminder;
    private List<Reminder> reminderList;
    private Gson gson;
    private Retrofit retrofit;
    ReminderInterface reminderInterface;


    public final String BASE_URL = Values.Base_URL;

    public ReminderService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        reminderInterface = retrofit.create(ReminderInterface.class);
    }

    public void getReminderByID(int reminderid) throws IOException {
        Call<Reminder> call = reminderInterface.getReminderByID(reminderid);
        currentReminder = call.execute().body();
    }

    public void addReminder(Reminder reminder) throws IOException {
        Call<Void> call = reminderInterface.addReminder(reminder);
        call.execute().body();
    }

    public void getAllReminderForEvent(int eventid) throws IOException {
        Call<List<Reminder>> call = reminderInterface.getAllReminderForEvent(eventid);
        reminderList = call.execute().body();
    }

    public void getAllReminderForDay(String date) throws IOException {
        Call<List<Reminder>> call = reminderInterface.getAllReminderForDay(date);
        reminderList = call.execute().body();
    }


    public Reminder getCurrentReminder() {
        return currentReminder;
    }

    public void setCurrentReminder(Reminder currentReminder) {
        this.currentReminder = currentReminder;
    }

    public List<Reminder> getReminderList() {
        return reminderList;
    }

    public void setReminderList(List<Reminder> reminderList) {
        this.reminderList = reminderList;
    }

    @Override
    public void onResponse(Call<Reminder> call, Response<Reminder> response) {

    }

    @Override
    public void onFailure(Call<Reminder> call, Throwable t) {

    }
}
