package service;

import Interfaces.QuizInterface;
import Interfaces.UserInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Course;
import model.Quiz;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QuizService implements Callback<Quiz> {

    private Quiz currentQuiz;
    private List<Quiz> quizList;
    Gson gson;
    Retrofit retrofit;
    QuizInterface quizInterface;

    public final String BASE_URL = "http://localhost:8080";

    public QuizService() {
        gson = new GsonBuilder().setLenient().create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        quizInterface = retrofit.create(QuizInterface.class);
    }


    public void getQuizById(int key) throws IOException {
        Call<Quiz> call = quizInterface.getQuizById(key);
        currentQuiz = call.execute().body();
    }

    public void getQuizByCourseKey(int key) throws IOException {
        Call<List<Quiz>> call = quizInterface.getQuizByCourseKey(key);
        quizList = call.execute().body();
    }

    public void addQuiz(Quiz quiz) throws IOException {
        Call<Void> call = quizInterface.addNewQuiz(quiz);
        call.execute().body();
        currentQuiz = quiz;
    }

    public Quiz getCurrentQuiz() {
        return currentQuiz;
    }

    public void setCurrentQuiz(Quiz currentQuiz) {
        this.currentQuiz = currentQuiz;
    }

    public List<Quiz> getQuizList() {
        return quizList;
    }

    public void setQuizList(List<Quiz> quizList) {
        this.quizList = quizList;
    }


    @Override
    public void onResponse(Call<Quiz> call, Response<Quiz> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Quiz> call, Throwable throwable) {
        throwable.printStackTrace();
    }
}
