package service;

import Interfaces.CardInterface;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Card;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CardService implements Callback<Card> {

    private Card card;
    ResponseBody responseBody;

    private List<Card> listOfCards;
    Gson gson;
    Retrofit retrofit;
    CardInterface cardInterface;

    public final String BASE_URL = "http://localhost:8080";

    public CardService() {
        listOfCards = new ArrayList<>();
        gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        cardInterface = retrofit.create(CardInterface.class);
    }

    public void addCard(Card card) throws IOException {
        cardInterface = retrofit.create(CardInterface.class);

        Call<Void> call = cardInterface.addCard(card);
        call.execute();
    }


    public void getCardbyCourseKey(int coursekey) throws IOException {
        cardInterface = retrofit.create(CardInterface.class);
        Call<List<Card>> call = cardInterface.getCardByCourseKey(coursekey);
        listOfCards = call.execute().body();
    }

    public void getCardByCardKey(int cardkey) throws IOException {

        cardInterface = retrofit.create(CardInterface.class);
        Call<Card> call = cardInterface.getCardByCardKey(cardkey);
        card = call.execute().body();


    }

    public Card getCurrentCard() {
        return card;
    }


    public List<Card> getListOfCards() {
        return listOfCards;
    }


    @Override
    public void onResponse(Call<Card> call, Response<Card> response) {
        if (response.isSuccessful()) {

        } else {
            System.out.println(response.message());
        }
    }

    @Override
    public void onFailure(Call<Card> call, Throwable t) {
        t.printStackTrace();
    }
}
