package handler;

import controller.GroupChatController;
import controller.PrivateChatController;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import model.ChatMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.stomp.*;
import service.ChatMessageService;
import service.ChatService;
import service.UserService;

import java.io.IOException;
import java.lang.reflect.Type;


public class MyStompSessionHandler extends StompSessionHandlerAdapter implements StompFrameHandler {
    PrivateChatController privateChatController;
    GroupChatController groupChatController;
   // Logger logger = LoggerFactory.getLogger(MyStompSessionHandler.class);
    String chatkey;
    ChatService chatService;
    UserService userService;
    ChatMessageService chatMessageService;
    int userkey;
    FXMLLoader loader;

    public MyStompSessionHandler(int userkey) {
        this.userkey = userkey;
        chatService = new ChatService();
        userService = new UserService();
        chatMessageService = new ChatMessageService();
    }

    public MyStompSessionHandler(String chatkey) {
        this.chatkey = chatkey;
        chatService = new ChatService();
        userService = new UserService();
        chatMessageService = new ChatMessageService();
    }

    @Override
    public void afterConnected(
            StompSession session, StompHeaders connectedHeaders) {
        String tmp;
        if (chatkey != null) {
            tmp = chatkey;
        } else {
            tmp = String.valueOf(userkey);
        }
        session.subscribe("/topic/message/" + tmp, this);
    }

    @Override
    public Type getPayloadType(StompHeaders headers) {
        return ChatMessage.class;
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
        ChatMessage tmp = (ChatMessage) payload;

        // logger.info(tmp.getContent());
        try {
            chatService.getChatByChatKey(tmp.getChatid());
        } catch (IOException e) {
            e.printStackTrace();
        }
        String type = chatService.getCurrentChat().getType();

        try {
            if (type.equals("private")) {
                if (tmp.getSenderid() == privateChatController.getMainWindowController().getLoggedInUser().getUserkey()) {

                    Platform.runLater(() -> {
                        try {
                            privateChatController.addRightMessage(tmp.getContent(), tmp.getTimestamp());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                } else {
                    int temp = privateChatController.chatExist(tmp.getSenderid());
                    if (temp != -1) {
                        if (privateChatController.getChatsOverview().getSelectionModel().getSelectedIndex() == temp) {
                            Platform.runLater(() -> {
                                try {
                                    privateChatController.addLeftMessage(tmp.getContent(), tmp.getTimestamp());
                                    chatMessageService.deleteChatMessage(tmp);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            });
                        }
                    }
                }


            } else {


            }

            chatService.createMessage(tmp, privateChatController.getMainWindowController().getLoggedInUser().getUserkey());


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public PrivateChatController getPrivateChatController() {
        return privateChatController;
    }

    public void setPrivateChatController(PrivateChatController privateChatController) {
        this.privateChatController = privateChatController;
    }

    public GroupChatController getGroupChatController() {
        return groupChatController;
    }

    public void setGroupChatController(GroupChatController groupChatController) {
        this.groupChatController = groupChatController;
    }

}
