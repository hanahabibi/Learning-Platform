package Interfaces;

import model.Card;
import model.Task;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface CardInterface {

    @POST("card/add")
    Call<Void> addCard(@Body Card card);

    @GET("card/get/coursekey/{coursekey}")
    Call<List<Card>> getCardByCourseKey(@Path("coursekey") int coursekey);

    @GET("card/get/id/{cardkey}")
    Call<Card> getCardByCardKey(@Path("cardkey") int cardkey);
}
