package Interfaces;

import model.ChatMessage;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface ChatMessageInterface {

    @POST("chatmessage/add")
    public Call<Void> addNewMessage(@Body ChatMessage message);

    @GET("chatmessage/get/id/{chatID}")
    public Call<List<ChatMessage>> getMessageByChatID(@Path("chatID") int chatID);

    @GET("chatmessage/get/messageId/{messageId}")
    public Call<ChatMessage> getMessageByMessageId(@Path("senderId") int senderId);

    @GET("chatmessage/get/senderId/{senderId}")
    public Call<List<ChatMessage>> getMessageBySenderId(@Path("senderId") int senderId);

    @GET("chatmessage/get/receiverId/{receiverId}")
    public Call<List<ChatMessage>> getMessageByReceiverId(@Path("receiverId") int recipientId);

    @GET("chatmessage/get/all")
    public Call<List<ChatMessage>> getAllMessages();

    @POST("chatmessage/delete")
    public Call<Void> deleteChatMessage(@Body ChatMessage message);


}
