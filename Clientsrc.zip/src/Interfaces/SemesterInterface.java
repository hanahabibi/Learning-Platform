package Interfaces;

import model.Semester;
import model.Student;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface SemesterInterface {

    @GET("/semester/get/id/{semesterid}")
    Call<Semester> getSemesterById(@Path("semesterid") int semesterid);

    @GET("/semester/get/all")
    Call<List<Semester>> getAllSemester();

    @GET("/semester/get/name/{name}")
    Call<Semester> getSemesterByName(@Path("name") String name);

    @POST("/semester/add")
    Call<Void> addSemester(@Body Semester semester);
}
