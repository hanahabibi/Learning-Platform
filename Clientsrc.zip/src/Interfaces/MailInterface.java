package Interfaces;


import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface MailInterface {

    @POST("/mail/send/{to}/{subj}/{text}")
    Call<Boolean> sendMailTo(@Path("to") String to, @Path("subj") String subj, @Path("text") String text);

    @POST("/mail/generateCode/{email}")
    Call<String> generateCode(@Path("email") String email);

}
