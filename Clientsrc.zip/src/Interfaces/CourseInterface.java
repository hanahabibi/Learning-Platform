package Interfaces;

import model.Course;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface CourseInterface {

    @POST("/course/add")
    Call<Void> addNewCourse(@Body Course course);

    @GET("course/get/id/{courseKey}")
    Call<Course> getCourseByID(@Path("courseKey") int courseKey);

    @GET("course/get/semester/{semester}")
    Call<List<Course>> getCoursesForSemester(@Path("semester") String semester);

    @GET("course/get/name/{name}")
    Call<List<Course>> getCourseByName(@Path("name") String name);

    @GET("course/get/all")
    Call<List<Course>> getAllCourses();
}
