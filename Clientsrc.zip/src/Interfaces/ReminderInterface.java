package Interfaces;

import model.Reminder;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface ReminderInterface {

    @POST("/reminder/add")
    Call<Void> addReminder(@Body Reminder reminder);

    @GET("/reminder/get/id/{reminderid}")
    Call<Reminder> getReminderByID(@Path("reminderid") int reminderid);

    @GET("/reminder/get/event/{eventid}")
    Call<List<Reminder>> getAllReminderForEvent(@Path("eventid") int eventid);

    @GET("/reminder/get/date/{date}")
    Call<List<Reminder>> getAllReminderForDay(@Path("date") String date);
}
