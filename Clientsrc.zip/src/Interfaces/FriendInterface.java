package Interfaces;

import model.Friend;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface FriendInterface {

    @POST("friend/add")
    Call<Void> addNewFriend(@Body Friend Friend);

    @GET("friend/get/userkey/{userkey}")
    Call<List<Friend>> getFriendsByUserKey(@Path("userkey") int userkey);

    @GET("friend/get/otheruserkey/{otheruserkey}")
    Call<List<Friend>> getFriendsByOtherUserKey(@Path("otheruserkey") int otheruserkey);
}
