package Interfaces;

import model.LearningMaterial;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;


public interface LearningMaterialInterface {
    //add learningmaterial
    @POST("learningmaterial/add")
    Call<Void> addMaterial(@Body LearningMaterial learningMaterial);

    //get list of learningmaterial by coursekey
    @GET("learningmaterial/get/courseKey/{coursekey}")
    Call<List<LearningMaterial>> getMaterialByCourseKey(@Path("coursekey") int coursekey);

    //get learnigmaterial by lmkey
    @GET("learningmaterial/get/id/{learningmaterialkey}")
    Call<LearningMaterial> getMaterialByMaterialKey(@Path("learningmaterialkey") int learningmaterialkey);

    @DELETE("learningmaterial/delete/id/{learningmaterialkey}")
    Call<Void> deleteMaterial(@Path("learningmaterialkey") int learningmaterialkey);


    @GET("learningmaterial/download/{learningmaterialkey}")
    Call<Byte[]> downloadMaterial(@Path("learningmaterialkey") int learningmaterialkey);
}
