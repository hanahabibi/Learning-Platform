package Interfaces;

import model.Event;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface EventInterface {
    @POST("/event/add")
    Call<Void> addNewEvent(@Body Event event);

    @GET("/event/get/id/{eventID}")
    Call<Event> getEventByID(@Path("eventID") int eventID);

    @GET("/event/get/course/{coursekey}")
    Call<List<Event>> getALLEventsForCourse(@Path("coursekey") int coursekey);
}
