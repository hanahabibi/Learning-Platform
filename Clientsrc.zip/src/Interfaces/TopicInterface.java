package Interfaces;

import model.Topic;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;

public interface TopicInterface {
    @POST("/topic/add")
    Call<Void> addNewTopic(@Body Topic topic);

    @GET("topic/get/id/{topickey}")
    Call<Topic> getTopicByTopickey(@Path("topickey") int topickey);

    @GET("topic/get/title/{title}")
    Call<Topic> getTopicByTitle(@Path("title") String title);

    @DELETE("topic/delete/id/{topickey}")
    Call<Void> deleteTopic(@Path("topickey") int topickey);

    @GET("topic/get/all")
    Call<List<Topic>> getAllTopics();
}
