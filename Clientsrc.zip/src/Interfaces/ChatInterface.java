package Interfaces;

import model.Chat;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface ChatInterface {

    @GET("chat/get/all")
    public Call<List<Chat>> getAllChats();

    @GET("chat/get/chatkey/{key}")
    public Call<Chat> getChatByChatKey(@Path("key") String chatKey);

    @GET("chats/get/userkey/{userkey}")
    public Call<List<Chat>> getChatsByUserKey(@Path("userKey") int userKey);

    @GET("chat/get/secondUserId")
    public Call<Chat> getChatBySecondUserId(@Path("secondUserId") int secondUserId);

    @GET("chat/get/secondUserName")
    public Call<Chat> getChatBySecondUserName(@Path("secondUserName") String secondUserName);

    @GET("chat/get/initiatorId")
    public Call<Chat> getChatByInitiatorId(@Path("initiatorId") int initiatorId);

    @GET("chat/get/initiatorName")
    public Call<Chat> getChatByInitiatorName(@Path("initiatorName") String initiatorName);

    @GET("chats/get/initiatorId")
    public Call<List<Chat>> getChatsByInitiatorId(@Path("initiatorId") int initiatorId);

    @GET("chats/get/initiatorName")
    public Call<List<Chat>> getChatsByInitiatorName(@Path("initiatorName") String initiatorName);

    @POST("chat/add")
    public Call<Void> addNewChat(@Body Chat chat);

    @GET("chats/get/secondUserID")
    Call<List<Chat>> getChatsBySecondUserId(@Path("secondUserID") int secondUserId);

    @GET("chats/get/secondUserName")
    Call<List<Chat>> getChatsBySecondUserName(@Path("secondUserName") String secondUserName);
}
