package Interfaces;

import model.Participant;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface ParticipantInterface {

    @POST("participant/add")
    Call<Void> addNewParticipant(@Body Participant participant);

    @POST("participant/pass/{participantkey}")
    Call<Void> passParticipant(@Path("participantkey") int participantkey);

    @GET("participant/get/userKey/{userKey}")
    Call<List<Participant>> getParticipantByUserKey(@Path("userKey") int userKey);

    @GET("participant/get/courseKey/{courseKey}")
    Call<List<Participant>> getParticipantByCouresKey(@Path("courseKey") int courseKey);

}
