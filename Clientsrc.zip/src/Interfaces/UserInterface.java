package Interfaces;

import model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface UserInterface {
    @GET("user/get/id/{userkey}")
    Call<User> getUserById(@Path("userkey") int userkey);

    @GET("user/get/email/{email}")
    Call<User> getUserByEmail(@Path("email") String email);

    @GET("user/get/all")
    Call<List<User>> getAllUser();

    @POST("user/add")
    Call<Void> setUser(@Body User user);

}
