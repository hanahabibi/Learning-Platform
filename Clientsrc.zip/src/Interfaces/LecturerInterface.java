package Interfaces;

import model.Lecturer;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;

public interface LecturerInterface {


    @GET("lecturer/get/all")
    Call<List<Lecturer>> getAllLecturer();

    @GET("lecturer/get/id/{lecturerkey}")
    Call<Lecturer> getLecturerByID(@Path("lecturerkey") int lecturerkey);

    @GET("lecturer/get/key/{userkey}")
    Call<Lecturer> getLecturerByUserKey(@Path("userkey") int userkey);

    @POST("lecturer/add")
    Call<Void> setLecturer(@Body Lecturer lecturer);
}
