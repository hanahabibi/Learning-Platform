package Interfaces;

import model.Student;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.util.List;


public interface StudentInterface {
    @GET("student/get/id/{matnumber}")
    Call<Student> getStudentByID(@Path("matnumber") int matnumber);

    @GET("student/get/key/{userkey}")
    Call<Student> getStudentByUserKey(@Path("userkey") int userkey);

    @GET("student/get/all")
    Call<List<Student>> getAllStudent();

    @POST("student/add")
    Call<Void> setstudent(@Body Student student);

}
