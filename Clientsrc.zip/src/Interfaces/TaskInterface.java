package Interfaces;

import model.LearningMaterial;
import model.Student;
import model.Task;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;

public interface TaskInterface {

    @POST("task/add")
    Call<Void> addTask(@Body Task task);

    @GET("task/get/courseKey/{coursekey}")
    Call<List<Task>> getTaskByCourseKey(@Path("coursekey") int coursekey);

    @GET("task/get/id/{taskkey}")
    Call<Task> getTaskByTaskKey(@Path("taskkey") int taskkey);


}
