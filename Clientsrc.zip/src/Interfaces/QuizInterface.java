package Interfaces;

import model.Questions;
import model.Quiz;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

import java.io.File;
import java.util.List;

public interface QuizInterface {

    @GET("quiz/get/key/{quizkey}")
    Call<Quiz> getQuizById(@Path("quizkey") int quizkey);

    @GET("quiz/get/course/{coursekey}")
    Call<List<Quiz>> getQuizByCourseKey(@Path("coursekey") int coursekey);

    @POST("/quiz/add")
    Call<Void> addNewQuiz(@Body Quiz questions);
}
