package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.chart.PieChart;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import model.Course;
import model.Quiz;
import service.QuizService;
import service.StringService;

import java.io.IOException;

public class EvaluationsStatisticsController {
    MainWindowController mainWindowController;
    Course course;
    StringService stringService;
    QuizService quizService;
    @FXML
    ListView passedAnswerListView, failedAnswerListView, allAnswerListView;


    public EvaluationsStatisticsController(Course course) throws IOException {
        this.course = course;
        stringService = new StringService("");
        quizService = new QuizService();
        quizService.getQuizByCourseKey(course.getCoursekey());
        for (Quiz a : quizService.getQuizList()) {
            if (a.getType().equals("eval")) {
                stringService.loadEval(a.getWhoworkedonthatquiz());
            }
        }
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    @FXML
    public void initialize() throws IOException {
        for (int i = 0; i < stringService.getAnswersFromPassed().length; i++) {
            PieChartController pieChartController = new PieChartController(stringService.getAnswersFromPassed()[i][0], stringService.getAnswersFromPassed()[i][1], stringService.getAnswersFromPassed()[i][2], stringService.getAnswersFromPassed()[i][3], "Frage " + (i + 1));
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/EvalPieChart.fxml"));
            loader.setController(pieChartController);
            AnchorPane tmp = loader.load();
            passedAnswerListView.getItems().add(tmp);

            pieChartController = new PieChartController(stringService.getAnswersFromFailed()[i][0], stringService.getAnswersFromFailed()[i][1], stringService.getAnswersFromFailed()[i][2], stringService.getAnswersFromFailed()[i][3], "Frage " + (i + 1));
            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/EvalPieChart.fxml"));
            loader.setController(pieChartController);
            tmp = loader.load();
            failedAnswerListView.getItems().add(tmp);

            pieChartController = new PieChartController(stringService.getAnswersFromPassed()[i][0] + stringService.getAnswersFromFailed()[i][0], stringService.getAnswersFromPassed()[i][1] + stringService.getAnswersFromFailed()[i][1], stringService.getAnswersFromPassed()[i][2] + stringService.getAnswersFromFailed()[i][2], stringService.getAnswersFromPassed()[i][3] + stringService.getAnswersFromFailed()[i][3], "Frage " + (i + 1));
            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/EvalPieChart.fxml"));
            loader.setController(pieChartController);
            tmp = loader.load();
            allAnswerListView.getItems().add(tmp);

        }
    }


    public class PieChartController {
        @FXML
        PieChart pieChart;
        double a, b, c, d;
        String name;

        public PieChartController(int a, int b, int c, int d, String name) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.name = name;
        }

        @FXML
        public void initialize() throws IOException {
            pieChart.setTitle(name);
            ObservableList<PieChart.Data> tmplist = FXCollections.observableArrayList(new PieChart.Data("A", a), new PieChart.Data("B", b), new PieChart.Data("C", c), new PieChart.Data("D", d));
            pieChart.setData(tmplist);
        }

    }

}
