package controller;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import model.Course;
import model.Event;
import model.Reminder;
import service.CourseService;
import service.EventService;
import service.MailService;

import java.io.IOException;

public class ReminderController {

    @FXML
    Label nameCourseLabel;
    @FXML
    Label dataEventLabel;
    @FXML
    Label dateReminderLabel;
    @FXML
    Label timeReminderLabel;
    @FXML
    Label typReminderLabel;
    @FXML
    Button deleteButton;

    public MainWindowController mainWindowController;
    public EventService eventService;
    public CourseService courseService;
    public MailService mailService;
    public Reminder reminder;
    public Event event;
    public Course course;
    public int index;

    public ReminderController(MainWindowController mainWindowController, Reminder reminder) {
        this.mainWindowController = mainWindowController;
        this.eventService = new EventService();
        this.courseService = new CourseService();
        this.mailService = new MailService();
        this.reminder = reminder;
    }

    public void initialize() throws IOException {
        deleteButton.setVisible(false);
        System.out.println(reminder.getEventid());
        eventService.getEventByID(reminder.getEventid());
        event = eventService.getCurrentEvent();
        courseService.getCourseByID(event.getCoursekey());
        course = courseService.getCurrentCourse();

        nameCourseLabel.setText(course.getName());
        dataEventLabel.setText(event.toString());
        dateReminderLabel.setText(reminder.getDate());
        timeReminderLabel.setText(reminder.timeString());
        typReminderLabel.setText(reminder.getTypeString());

        try {
            deleteButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    deleteReminder();
                    mainWindowController.tabMenu.getSelectionModel().select(1);
                    mainWindowController.tabMenu.getTabs().remove(index);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void deleteReminder() {

    }

    public void sendMail() throws IOException {
        String mail = course.getName() + ":\n ERINNERUNG : " + event.toString() + ". Genauere Informationen finden Sie in der Project X PLatform.";
        mailService.sendMailTo(mainWindowController.getLoggedInUser().getEmail(), event.name, mail);

    }

    public void showPopup() {

    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
