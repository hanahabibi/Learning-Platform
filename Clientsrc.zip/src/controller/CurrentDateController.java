package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import model.*;
import service.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class CurrentDateController {


    public MainWindowController mainWindowController;
    public Calendar currentDate;
    public ReminderService reminderService;
    public EventService eventService;
    public CourseService courseService;
    public UserService userService;
    public ParticipantService participantService;
    public SemesterService semesterService;
    public QuizService quizService;
    public MailService mailService;
    public StringService stringService;
    public ObservableList<Reminder> reminders = FXCollections.observableArrayList();
    @FXML
    DialogPane dialogPane;
    @FXML
    Label reminderNameLabel;
    @FXML
    Label eventDataLabel;
    public ObservableList<String> passedSemester = FXCollections.observableArrayList();


    public CurrentDateController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
        this.reminderService = new ReminderService();
        this.eventService = new EventService();
        this.courseService = new CourseService();
        this.participantService = new ParticipantService();
        this.semesterService = new SemesterService();
        this.userService = new UserService();
        this.quizService = new QuizService();
        this.mailService = new MailService();
        this.currentDate = Calendar.getInstance();
    }

    public void initialize() throws IOException, InterruptedException {
        //alle Reminder für den heutigen Tag . Monat wird Plus 1 gezählt weil Calendar von 0-11
        fetchReminders(currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH) + 1, currentDate.get(Calendar.DAY_OF_MONTH));
        hasSemesterPassed(pastSemester(currentDate));
    }


    //Liefert neue Liste von allen Remindern die an dem gegebenen Tag anstehen für den eingeloggten User
    public void fetchReminders(int year, int month, int day) throws IOException {
        ObservableList<Course> userCourses = FXCollections.observableArrayList();
        userCourses.clear();
        ObservableList<Event> userEvents = FXCollections.observableArrayList();
        userEvents.clear();
        ObservableList<Reminder> userReminder = FXCollections.observableArrayList();
        userReminder.clear();

        //Alle Kurse in die der Benutzer eingeschrieben ist werden geholt
        participantService.getParticipant(mainWindowController.loggedInUser.getUserkey());
        if (participantService.getCurrentParticipantList() != null) {
            for (Participant participant : participantService.getCurrentParticipantList()) {
                if (participant.getUserkey() == mainWindowController.loggedInUser.getUserkey()) {
                    courseService.getCourseByID(participant.getCoursekey());
                    userCourses.add(courseService.getCurrentCourse());
                }
            }
        }
        List<Integer> CKeys = new LinkedList<Integer>();
        for (Course course : userCourses) {
            CKeys.add(course.getCoursekey());
        }

        //Alle Events aus den eingeschriebenen Kursen
        for (int courseKey : CKeys) {
            eventService.getALLEventsForCourse(courseKey);
            userEvents.addAll(eventService.getEventList());
        }

        String tmp = year + "-" + month + "-" + day;
        reminderService.getAllReminderForDay(tmp);

        for (Reminder reminder : reminderService.getReminderList()) {
            int currentReminderEventId = reminder.getEventid();
            for (Event event : userEvents) {
                if (currentReminderEventId == event.getEventID()) {
                    userReminder.add(reminder);
                }
            }
        }
        reminders.setAll(userReminder);
    }

    public void setUpDialog(Reminder reminder) throws IOException {
        reminderNameLabel.setText(reminder.getTitle());
        eventService.getEventByID(reminder.getEventid());
        model.Event tmp = eventService.getCurrentEvent();
        eventDataLabel.setText(tmp.toString());

    }

    public void hasSeenReminder(Reminder reminder, int userkey) throws IOException {

        reminderService.getReminderByID(reminder.getReminderid());
        Reminder tmp = reminderService.getCurrentReminder();
        tmp.addToUserkeys(userkey);
        reminderService.setCurrentReminder(tmp);
        reminderService.addReminder(tmp);
    }

    public ObservableList<String> pastSemester(Calendar currentDate) {

        ObservableList<String> passedSemesters = FXCollections.observableArrayList();
        Calendar WS = Calendar.getInstance();
        Calendar SS = Calendar.getInstance();

        //Hier wurde Jahr geändert auf CALENDAR GET YEAR zurück setzten
        for (int i = 2018; i < 2040; i++) {
            String year = Integer.toString(i).substring(2);
            String yearBef = Integer.toString(i - 1).substring(2);
            WS.set(i, 3, 31, 23, 59, 59);
            if (currentDate.after(WS)) {
                passedSemesters.add("WS " + yearBef + "/" + year);
            } else break;
            SS.set(i, 9, 30, 23, 59, 59);
            if (currentDate.after(SS)) {
                passedSemesters.add("SS " + year);
            } else break;
        }
        return passedSemesters;
    }

    public void hasSemesterPassed(ObservableList<String> passedSemester) throws IOException, InterruptedException {
        semesterService.getAllSemester();
        boolean exists = false;
        List<Semester> a = semesterService.getSemesterList();
        List<Semester> semesterList = semesterService.getSemesterList();

        for (String ps : passedSemester) {
            exists = false;

            if (a != null) {
                for (Semester semester : a) {
                    if (ps.equals(semester.getName())) exists = true;
                }
            }

            if (!exists) {
                semesterService.addSemester(new Semester(ps));
                courseService.getCoursesForSemester(ps);
                if (courseService.getCourseList() != null) {
                    for (Course course : courseService.getCourseList()) {
                        resultEmails(course);
                    }
                }
            }
        }

    }


    public void resultEmails(Course course) throws IOException, InterruptedException {
        quizService.getQuizByCourseKey(course.getCoursekey());
        List<Quiz> quizzes = new ArrayList<Quiz>();
        for (Quiz quiz : quizService.getQuizList()) {
            if (quiz.getType().equals("quiz")) {
                quizzes.add(quiz);
            }
        }

        String passedEmails = "";
        String failedEmails = "";
        participantService.getParticipantsOfCourse(course.getCoursekey());
        List<Participant> a = participantService.getCurrentParticipantList();
        for (Participant participant : a) {
            userService.getUser(participant.getUserkey());
            User user = userService.getCurrentUser();

            if (user.getIsstudent() == 1) {
                if (gradeForUser(user.getUserkey(), quizzes)) {
                    if (passedEmails.equals("")) {
                        passedEmails = user.getEmail();
                    } else {
                        passedEmails = passedEmails + ";" + user.getEmail();
                    }
                    participantService.passParticipant(participant.getParticipantkey());
                } else {
                    if (failedEmails.equals("")) {
                        failedEmails = user.getEmail();
                    } else {
                        failedEmails = failedEmails + ";" + user.getEmail();
                    }
                }
            }
        }

        mailService.sendMailTo(passedEmails, "Endergebnis der Veranstaltung: " + course.getName(), "Sie haben die Veranstaltung: " + course.getName() + " bestanden");
        mailService.sendMailTo(failedEmails, "Endergebnis der Veranstaltung: " + course.getName(), "Sie haben die Veranstaltung: " + course.getName() + " nicht bestanden");

    }

    public boolean gradeForUser(int userkey, List<Quiz> quizzes) {
        boolean erg = false;
        int passed = 0;
        for (Quiz quiz : quizzes) {
            String wwotq = quiz.getWhoworkedonthatquiz();
            if (wwotq == null || wwotq.equals("")) break;
            stringService = new StringService(wwotq);
            final int length = stringService.getUserAtempts().length;
            for (int i = 1; i < length; i++) {
                int[][] tmp = stringService.getUserAtempts();
                int tmpKey = tmp[i][0];
                if (userkey == tmpKey && tmp[i][2] == 1) {
                    passed++;
                }
            }

            if (passed >= Math.ceil((float) length / 2)) erg = true;
        }
        return erg;
    }

    public void setCurrentDate(Calendar currentDate) throws IOException, InterruptedException {
        this.currentDate = currentDate;
        fetchReminders(currentDate.get(Calendar.YEAR),
                currentDate.get(Calendar.MONTH),
                currentDate.get(Calendar.DAY_OF_MONTH));
        hasSemesterPassed(pastSemester(currentDate));
    }

    public Calendar getCurrentDate() {
        return currentDate;
    }


}
