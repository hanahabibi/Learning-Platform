package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;
import model.Literature;

public class LiteratureViewController {

    @FXML
    Label titleLabel;
    @FXML
    Label authorLabel;
    @FXML
    Label publisherLabel;
    @FXML
    Label yearLabel;
    @FXML
    Label pagesLabel;
    @FXML
    Label volumeLabel;
    @FXML
    Label numberLabel;
    @FXML
    Label isbnLabel;
    @FXML
    Label journalLabel;
    @FXML
    Label doiLabel;
    @FXML
    Label keywordsLabel;
    @FXML
    Label booktitleLabel;
    @FXML
    Label addressLabel;
    @FXML
    Label seriesLabel;
    @FXML
    Label urlLabel;
    @FXML
    Label urlDateLabel;
    @FXML
    Label fileLabel;
    @FXML
    Label priceLabel;
    @FXML
    Label editorLabel;
    @FXML
    Label institutionLabel;
    @FXML
    Label abstractLabel;
    @FXML
    Button closeButton;

    Literature literature;
    Stage stage;

    public LiteratureViewController(Literature literature, Stage stage) {
        this.literature = literature;
        this.stage = stage;
    }

    public void initialize() {
        titleLabel.setMaxWidth(650);
        titleLabel.setWrapText(true);
        titleLabel.setText("Titel: " + literature.getTitle());
        authorLabel.setMaxWidth(650);
        authorLabel.setWrapText(true);
        authorLabel.setText("Autor: " + literature.getAuthor());
        titleLabel.setWrapText(true);
        publisherLabel.setText("Verlag: " + literature.getPublisher());
        titleLabel.setWrapText(true);
        yearLabel.setText("Jahr: " + literature.getYear());
        titleLabel.setWrapText(true);
        pagesLabel.setText("Seiten: " + literature.getPages());
        titleLabel.setWrapText(true);
        isbnLabel.setText("ISBN/ISSN: " + literature.getIsbn());
        journalLabel.setWrapText(true);
        journalLabel.setMaxWidth(230);
        journalLabel.setText("Journal: " + literature.getJournal());
        keywordsLabel.setText("Schlüsselwörter: " + literature.getKeywords());
        keywordsLabel.setMaxWidth(450);
        keywordsLabel.setWrapText(true);
        booktitleLabel.setText("Buchtitel: " + literature.getBooktitle());
        addressLabel.setText("Adresse: " + literature.getAddress());
        seriesLabel.setText("Serie: " + literature.getSeries());
        urlLabel.setMaxWidth(400);
        urlLabel.setWrapText(true);
        urlLabel.setText("URL: " + literature.getUrl());
        urlDateLabel.setText("URL-Datum: " + literature.getUrldate());
        priceLabel.setText("Preis: " + literature.getPrice());
        institutionLabel.setWrapText(true);
        institutionLabel.setMaxWidth(230);
        institutionLabel.setText("Institution: " + literature.getInstitution());

        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();
            }
        });
    }
}
