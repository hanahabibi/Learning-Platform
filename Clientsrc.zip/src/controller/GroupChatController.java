package controller;

import handler.MyStompSessionHandler;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import model.*;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;
import service.ChatService;
import service.UserService;
import value.Values;

import javax.imageio.ImageIO;
import java.io.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class GroupChatController {

    @FXML
    Button sendButton;
    @FXML
    ListView chatsOverview; //Nachrichten in einem Chat
    @FXML
    ListView messageBasePane; //laufende Chats
    @FXML
    TextArea textArea;

    User loggedInUser;
    User user;
    FXMLLoader loader;

    Chat chat;
    ArrayList<ChatPersonController> chatPersonController;
    WebSocketClient client;
    WebSocketStompClient stompClient;
    MyStompSessionHandler stompSessionHandler;
    StompSession session;
    String URL = Values.Base_URL + "/chatmessage/";
    MainWindowController mainWindowController;
    ChatService chatService;
    UserService userService;
    String chatkey;
    Course course;
    List<Participant> participantsList;


    public GroupChatController() {

    }

    public GroupChatController(User loggedInUser, Course course, List<Participant> participantsList, MainWindowController mainWindowController) {
        this.loggedInUser = loggedInUser;
        this.course = course;
        this.participantsList = participantsList;
        this.setMainWindowController(mainWindowController);
        this.chatService = mainWindowController.chatService;
        client = new StandardWebSocketClient();
        SockJsClient sockJsClient = new SockJsClient(List.of(new WebSocketTransport(client)));
        stompClient = new WebSocketStompClient(sockJsClient);
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());
        stompSessionHandler = new MyStompSessionHandler(course.getUserkey() + "-" + course.getCoursekey());
        stompSessionHandler.setGroupChatController(this);
        userService = new UserService();
        chatPersonController = new ArrayList<>();
        try {
            session = stompClient.connect(URL, stompSessionHandler).get();

        } catch (Exception e) {
            e.printStackTrace();
        }


        chatService = new ChatService();

    }


    public MainWindowController getMainWindowController() {
        return mainWindowController;
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
        loggedInUser = mainWindowController.loggedInUser;
    }


    @FXML
    public void initialize() throws IOException {

        List<Integer> idComponents = new ArrayList<>();
        idComponents.add(course.getUserkey());
        idComponents.add(course.getCoursekey());
        chatkey = chatService.createGroupChatkey(idComponents);

        try {
            chatService.getChatByChatKey(chatkey);
            for (Participant a : participantsList) {
                userService.getUser(a.getUserkey());
                ChatPersonController tmpController = new ChatPersonController(userService.getCurrentUser());
                chatPersonController.add(tmpController);
                loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/fxml/ChatPerson.fxml"));
                loader.setController(tmpController);
                chatsOverview.getItems().add(loader.load());
            }

            if (chatService.getCurrentChat().getChatkey() != null) {
                try {
                    if (!chatService.directoryExists(Values.Dir_Path + File.separator + loggedInUser.getUserkey() + "-" + chatkey + ".txt")) {
                        if (!chatService.directoryExists(Values.Dir_Path)) {
                            chatService.createChatDirectory();
                        }
                        chatService.createChatFile(chatkey, loggedInUser.getUserkey());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } else {
                Chat tmpchat = new Chat(chatkey, "group", course.getUserkey(), course.getCoursekey());
                chatService.addNewChat(tmpchat);

                try {
                    if (!chatService.directoryExists(Values.Dir_Path + File.separator + loggedInUser.getUserkey() + "-" + chatkey + ".txt")) {
                        if (!chatService.directoryExists(Values.Dir_Path)) {
                            chatService.createChatDirectory();
                        }
                        chatService.createChatFile(chatkey, loggedInUser.getUserkey());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            loadLocalMessages(chatkey);

        } catch (IOException e) {
            e.printStackTrace();
        }

        chatsOverview.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {

                try {
                    if (mouseEvent.getClickCount() == 2) {
                        for (int i = 0; i < chatsOverview.getItems().size(); i++) {

                            if (chatsOverview.getItems().get(i) == chatsOverview.getSelectionModel().getSelectedItem()) {
                                ChatPersonController tmp = chatPersonController.get(i);
                                mainWindowController.openPrivateChatTab(loggedInUser, tmp.getChatUser());
                            }
                        }

                    }
                } catch (
                        Exception e) {
                    e.printStackTrace();
                }
            }
        });

        sendButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                if (textArea.getText() != null) {
                    Timestamp temp = new Timestamp(System.currentTimeMillis());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String timeStamp = sdf.format(temp);
                    try {
                        userService.getUser(mainWindowController.loggedInUser.getUserkey());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    User sender = userService.getCurrentUser();
                    String content = sender.getFirstname() + ": " + textArea.getText();

                    ChatMessage tmp = new ChatMessage(chatkey, mainWindowController.loggedInUser.getUserkey(), 0, content, timeStamp);
                    textArea.clear();


                    session.send("/app/message/" + chatkey, tmp);

                }
            }
        });

        mainWindowController.tabMenu.getSelectionModel().getSelectedItem().setOnClosed(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                if (mainWindowController.tabMenu.getSelectionModel().getSelectedItem().getText().contains("Gruppenchat")) {
                    session.disconnect();
                }
            }
        });

    }
    //}


    //lädt alte Nachrichten
    public void loadLocalMessages(String chatkey) throws IOException {

        //findet Datei in der Chatlines gespeichert sind
        File file = new File(Values.Dir_Path + File.separator + loggedInUser.getUserkey() + "-" + chatkey + ".txt");
        FileInputStream fis = new FileInputStream(file);
        InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
        BufferedReader bufferedReader = new BufferedReader(isr);
        String line;

        //liest Datei Zeile für Zeile aus
        while ((line = bufferedReader.readLine()) != null && line != "") {

            char[] ca = line.toCharArray();

            //liest Nachricht aus
            StringBuilder lineForBubble = new StringBuilder();
            int i = 5;
            while (i < ca.length && ca[i] != '}') {
                lineForBubble.append(ca[i]);
                i++;
            }
            //liest Timestamp aus
            int beginningOfTimeStamp = line.indexOf("(@*") + 3;
            int endOfTimeStamp = beginningOfTimeStamp + 19;
            String timeStamp = line.substring(beginningOfTimeStamp, endOfTimeStamp);
            int temp = Integer.parseInt(line.substring(0, line.indexOf(":")));

            //prüft auf welche Seite die Nachricht muss
            if (temp == mainWindowController.loggedInUser.getUserkey()) {
                addRightMessage(lineForBubble.toString(), timeStamp);
            } else {
                addLeftMessage(lineForBubble.toString(), timeStamp);
            }
        }
    }


    public void addLeftMessage(String txt, String timeStamp) throws IOException {
        HBox hBox = new HBox();
        BubbledLabel tmp = new BubbledLabel(txt, timeStamp);
        tmp.setBackground(new Background(new BackgroundFill(Color.LIGHTPINK, null, null)));
        hBox.getChildren().add(tmp);
        hBox.setAlignment(Pos.BASELINE_LEFT);
        messageBasePane.getItems().add(hBox);

    }

    public void addRightMessage(String txt, String timeStamp) throws IOException {
        HBox hBox = new HBox();
        BubbledLabel tmp = new BubbledLabel(txt, timeStamp);
        tmp.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, null, null)));
        tmp.setBubbleSpec(BubbleSpec.FACE_RIGHT_CENTER);
        hBox.getChildren().add(tmp);
        hBox.setAlignment(Pos.BASELINE_RIGHT);
        messageBasePane.getItems().add(hBox);
    }


}
