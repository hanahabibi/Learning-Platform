package controller;

import exception.StudentNotFoundException;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.*;
import service.ChatService;
import service.TopicService;


import model.Topic;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class MainWindowController extends Node {

    //Der aktuell eingeloggte User
    User loggedInUser;

    User user;

    public ProfileController profileController;
    public CourseViewAllController courseViewAllController;
    public PrivateChatController privateChatController;
    public CalendarController calendarController;
    public ChatService chatService;
    public CurrentDateController currentDateController;
    public ReminderEmailController reminderEmailController;

    @FXML
    MenuItem ueberMenuItem;
    @FXML
    public Tab profileTab;
    @FXML
    public TabPane tabMenu;
    @FXML
    public Tab courseView;
    @FXML
    public Tab calendarView;
    @FXML
    public MenuItem closeMenuItem;
    @FXML
    public MenuItem logOutMenuItem;

    Stage stage;

    public MainWindowController(User loggedInUser, Stage stage) throws IOException {
        this.loggedInUser = loggedInUser;
        chatService = new ChatService();
        this.currentDateController = new CurrentDateController(this);
        this.reminderEmailController = new ReminderEmailController(this);
        this.stage = stage;
    }


    @FXML
    public void initialize() {
        DialogRunnable dialogRunnable = new DialogRunnable(this);
        Thread popupthread = new Thread(dialogRunnable, "popupthread");
        popupthread.start();

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                popupthread.stop();
            }
        });

        //@Author Kuri
        try {
            FXMLLoader loader = new FXMLLoader();
            URL tmp = getClass().getResource("/fxml/Profile.fxml");
            loader.setLocation(tmp);
            profileController = new ProfileController(loggedInUser, loggedInUser);
            profileController.setMainWindowController(this);
            loader.setController(profileController);
            AnchorPane anchorPane1 = loader.load();
            profileTab.setContent(anchorPane1);
            profileTab.setText("Profil");

            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/CourseViewAll.fxml"));
            courseViewAllController = new CourseViewAllController(this);
            loader.setController(courseViewAllController);
            AnchorPane anchorPane2 = loader.load();
            courseView.setContent(anchorPane2);
            courseView.setText("Veranstaltungen");

            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/CalendarView.fxml"));
            calendarController = new CalendarController(this);
            loader.setController(calendarController);
            AnchorPane anchorPane3 = loader.load();
            calendarView.setContent(anchorPane3);
            calendarView.setClosable(false);
            calendarView.setText("Kalender");

            //Chat @Author Noemi

            //wenn Chats vorhanden sind wird ChatTab angezeigt, sonst nicht

                loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/fxml/Chat.fxml"));
                privateChatController = new PrivateChatController(loggedInUser, user, this);
                loader.setController(privateChatController);
                AnchorPane anchorPane4 = loader.load();
                Tab tmpTap = new Tab();
                tmpTap.setText("Chats");
                tmpTap.setClosable(false);
                tabMenu.getTabs().add(tmpTap);
                tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(anchorPane4);


        } catch (Exception e) {
            System.out.println(e.getCause() + " ," + e.getMessage());
            e.printStackTrace();
        }

        //@Author Kuri
        ueberMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Alert aboutAlert = new Alert(Alert.AlertType.INFORMATION);
                aboutAlert.setTitle("ProjectX für SEP UNI DUE");
                aboutAlert.setHeaderText("Entwickelt von...");
                aboutAlert.setContentText("Frederik Gnass 3099469\n" +
                        "\n" +
                        "Hana Habibi 3100348\n" +
                        "\n" +
                        "Noemi Kallweit 3098817\n" +
                        "\n" +
                        "Thorben Kronewald-Lamken 3091481\n" +
                        "\n" +
                        "Vera Theodora Mitschulat 3093828\n" +
                        "\n" +
                        "Kurinchinilavan Thangeswaran 3098849");

                aboutAlert.showAndWait();
            }
        });

        //@Author Kuri
        closeMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage stage = (Stage) tabMenu.getScene().getWindow();
                stage.close();
            }
        });
        //@Author Kuri
        logOutMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage primaryStage = (Stage) tabMenu.getScene().getWindow();
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/StartWindow.fxml"));
                    loader.setController(new StartWindowController(primaryStage));
                    Parent root = loader.load();
                    primaryStage.setScene(new Scene(root));
                    primaryStage.show();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        courseView.setOnSelectionChanged(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                if (tabMenu.getSelectionModel().getSelectedItem().equals(courseView)) {
                    try {
                        if (courseView.isSelected()) {
                            courseViewAllController.initialize();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });


    }

    public void goBackToProfile(User userToSee) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Profile.fxml"));
        ProfileController profileController = new ProfileController(loggedInUser, userToSee);
        profileController.setMainWindowController(this);
        loader.setController(profileController);
        AnchorPane anchorPane = loader.load();
        tabMenu.getSelectionModel().getSelectedItem().setContent(anchorPane);
        tabMenu.getSelectionModel().getSelectedItem().setText(userToSee.getLastname());
    }

    //@Author Kuri
    public void openNewCourseTab(Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/CourseView.fxml"));
        CourseViewController courseViewController = new CourseViewController(loggedInUser, course, tabMenu.getTabs().size() - 1);
        loader.setController(courseViewController);
        courseViewController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText(course.getName());
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(tmpPane);
        tabMenu.getSelectionModel().select(tabMenu.getTabs().size() - 1);
    }

    public void updateCourseTab(Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/CourseView.fxml"));
        int index = tabMenu.getSelectionModel().getSelectedIndex();
        CourseViewController courseViewController = new CourseViewController(loggedInUser, course, index);
        loader.setController(courseViewController);
        courseViewController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        tabMenu.getSelectionModel().getSelectedItem().setContent(tmpPane);
        tabMenu.getSelectionModel().select(index);
    }

    public void openCardTab(Course course, int index) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/CardView.fxml"));
        CardViewController cardViewController = new CardViewController(course, index);
        cardViewController.setMainWindowController(this);
        loader.setController(cardViewController);
        AnchorPane anchorPane1 = loader.load();
        tabMenu.getTabs().get(this.tabMenu.getSelectionModel().getSelectedIndex()).setContent(anchorPane1);

    }

    //@Author Noemi
    public void openPasswordTab() throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Password.fxml"));
        PasswordController passwordController = new PasswordController(loggedInUser);
        passwordController.setParent(this);
        loader.setController(passwordController);
        AnchorPane anchorPane1 = loader.load();
        profileTab.setContent(anchorPane1);
        profileTab.setText("Passwort bearbeiten");

    }

    public CurrentDateController showDialogPane(Reminder reminder) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/DialogPanePopUp.fxml"));
        loader.setController(currentDateController);
        Stage window = new Stage();
        Parent root = loader.load();
        Scene scene = new Scene(root);
        window.setScene(scene);
        currentDateController.setUpDialog(reminder);
        window.show();

        return currentDateController;

    }

    //@Author Noemi
    public void openProfileTab() throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Profile.fxml"));
        ProfileController profileController = new ProfileController(loggedInUser, loggedInUser);
        profileController.setMainWindowController(this);
        loader.setController(profileController);
        AnchorPane anchorPane1 = loader.load();
        profileTab.setContent(anchorPane1);
        profileTab.setText("Profil");

    }

    public void openProfileTab(User userToSee) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Profile.fxml"));
        ProfileController profileController = new ProfileController(loggedInUser, userToSee);
        profileController.setMainWindowController(this);
        loader.setController(profileController);
        AnchorPane anchorPane1 = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText(userToSee.getLastname());
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(anchorPane1);
        tabMenu.getSelectionModel().select(tabMenu.getTabs().size() - 1);

    }


    //@Author Kuri
    public void openAddCourseTab() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AddCourse.fxml"));
        AddCourseController addCourseController = new AddCourseController();
        addCourseController.setMainWindowController(this);
        loader.setController(addCourseController);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Hinzufügen");
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(tmpPane);
        addCourseController.setIndex(tabMenu.getTabs().size() - 1);
        tabMenu.getSelectionModel().select(tabMenu.getTabs().size() - 1);
    }

    public void openAddEventTab(int courseKey, int indexfrom) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AddEventView.fxml"));
        AddEventController addEventController = new AddEventController(this, courseKey, indexfrom);
        loader.setController(addEventController);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Hinzufügen");
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(tmpPane);
        addEventController.setIndex(tabMenu.getTabs().size() - 1);
        tabMenu.getSelectionModel().select(tabMenu.getTabs().size() - 1);
    }

    public void openAddReminderTab(int eventid, int indexFrom) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AddReminderView.fxml"));
        AddReminderController addReminderController = new AddReminderController(this, eventid, indexFrom);
        loader.setController(addReminderController);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Hinzufügen");
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(tmpPane);
        addReminderController.setIndex(tabMenu.getTabs().size() - 1);
        tabMenu.getSelectionModel().select(tabMenu.getTabs().size() - 1);
    }

    public void openAddTopic() throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Topic.fxml"));
        AddTopicController addTopicController = new AddTopicController(loggedInUser, this);
        addTopicController.setMainWindowController(this);
        loader.setController(addTopicController);
        AnchorPane anchorPane1 = loader.load();
        profileTab.setContent(anchorPane1);
        profileTab.setText("Themenangebot hinzufügen");

    }
    public void openEditProfileTab() throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/EditProfile.fxml"));
        EditProfileController editProfileController = new EditProfileController(loggedInUser);
        editProfileController.setMainWindowController(this);
        loader.setController(editProfileController);
        AnchorPane anchorPane1 = loader.load();
        profileTab.setContent(anchorPane1);
        profileTab.setText("Profil bearbeiten");
    }

    public void openEditTopic(Topic topic) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Topic.fxml"));
        EditTopicController editTopicController = new EditTopicController(topic, this);
        editTopicController.setMainWindowController(this);
        loader.setController(editTopicController);
        AnchorPane anchorPane1 = loader.load();
        profileTab.setContent(anchorPane1);
        profileTab.setText("Thema bearbeiten");

    }

    public void openFriendsListTab() throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Friendslist.fxml"));
        FriendListController friendListController = new FriendListController(loggedInUser);
        friendListController.setMainWindowController(this);
        loader.setController(friendListController);
        AnchorPane anchorPane1 = loader.load();
        profileTab.setContent(anchorPane1);
        profileTab.setText("Freundschaftsliste");
    }

    public void openReminderTab(Reminder reminder) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/ReminderView.fxml"));
        ReminderController reminderController = new ReminderController(this, reminder);
        reminderController.setIndex(tabMenu.getTabs().size());
        loader.setController(reminderController);
        AnchorPane anchorPane1 = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText(reminder.getTitle());
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(anchorPane1);
    }

    public void openEventTab(model.Event event, int indexFrom) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/EventView.fxml"));
        EventController eventController = new EventController(this, event, indexFrom);
        eventController.setIndex(tabMenu.getTabs().size());
        loader.setController(eventController);
        AnchorPane anchorPane1 = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText(event.getName());
        tmpTap.setClosable(true);
        tabMenu.getTabs().add(tmpTap);
        tabMenu.getTabs().get(tabMenu.getTabs().size() - 1).setContent(anchorPane1);
    }

    public void openParticipantsList(Course course, MainWindowController mainWindowController) throws IOException {

        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;

        if (index > tabMenu.getTabs().size() - 1 || tabMenu.getTabs().get(index).getText() != "Teilnehmerliste") {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/ParticipantsList.fxml"));
            ParticipantsListController participantsListController = new ParticipantsListController(course, mainWindowController);
            loader.setController(participantsListController);
            AnchorPane anchorPane1 = loader.load();
            Tab tmpTap = new Tab();
            tmpTap.setText("Teilnehmerliste");
            tmpTap.setClosable(true);
            tmpTap.setContent(anchorPane1);
            tabMenu.getTabs().add(index, tmpTap);
            tabMenu.getSelectionModel().select(index);
        } else {
            tabMenu.getSelectionModel().select(index);
        }

    }

    public void openFeedbackTab(ArrayList questions, Quiz quiz, User user) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/QuizFeedback.fxml"));
        QuizFeedbackController quizFeedbackController = new QuizFeedbackController(questions, quiz, user);
        quizFeedbackController.setMainWindowController(this);
        loader.setController(quizFeedbackController);
        AnchorPane anchorPane1 = loader.load();
        tabMenu.getSelectionModel().getSelectedItem().setContent(anchorPane1);
        tabMenu.getSelectionModel().getSelectedItem().setText("Auswertung");
    }

    public void openCourseAfterQuiz(User user, Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/CourseView.fxml"));
        CourseViewController courseViewController = new CourseViewController(user, course, tabMenu.getTabs().size() - 1);
        courseViewController.setMainWindowController(this);
        loader.setController(courseViewController);
        AnchorPane anchorPane1 = loader.load();
        tabMenu.getSelectionModel().getSelectedItem().setContent(anchorPane1);
        tabMenu.getSelectionModel().getSelectedItem().setText(course.getName());
    }

    public void openQuizStatisics(Quiz quiz) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/QuizStatistik.fxml"));
        QuizStatistikController quizController = new QuizStatistikController(quiz);
        loader.setController(quizController);
        quizController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Quiz lösen");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);
    }

    public void openQuizPopUp(Course course, boolean value) throws IOException {
        Stage primaryStage = new Stage();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/QuizPopup.fxml"));
        loader.setController(new QuizPopupController(this, primaryStage, course, loggedInUser, value));
        Parent root = null;
        root = loader.load();
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public void openAnswerQuiz(User user, Quiz quiz) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AnswerQuiz.fxml"));
        AnswerQuizController quizController = new AnswerQuizController(user, quiz);
        loader.setController(quizController);
        quizController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Quiz lösen");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);
    }

    public void openAnswerEvaluation(Quiz a) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AnswerEvaluation.fxml"));
        AnswerEvaluationController quizController = new AnswerEvaluationController(a, loggedInUser);
        loader.setController(quizController);
        quizController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Evaluation ausfüllen");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);
    }

    public void openAddQuiz(User user, Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AddQuiz.fxml"));
        AddQuizController quizController = new AddQuizController(user, course);
        loader.setController(quizController);
        quizController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Quiz erstellen");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);
    }

    public void openAddEvaluation(User user, Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AddEvaluation.fxml"));
        AddEvaluationController quizController = new AddEvaluationController(user, course);
        loader.setController(quizController);
        quizController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Evaluation erstellen");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);
    }

    public void openGroupChat(User loggedInUser, Course course, List<Participant> participantsList) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/Chat.fxml"));
        GroupChatController groupChatController = new GroupChatController(loggedInUser, course, participantsList, this);
        loader.setController(groupChatController);
        groupChatController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Gruppenchat");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);

    }

    public void openPrivateChatTab(User loggedInUser, User user) throws IOException {

        this.loggedInUser = loggedInUser;
        this.user = user;


        if (tabMenu.getTabs().get(3).getText() == "Chats") {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/Chat.fxml"));
            PrivateChatController privateChatController = new PrivateChatController(loggedInUser, user, this);
            loader.setController(privateChatController);
            AnchorPane tmpPane = loader.load();
            tabMenu.getTabs().get(3).setContent(tmpPane);
            tabMenu.getSelectionModel().select(3);
        } else {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/fxml/Chat.fxml"));
            PrivateChatController privateChatController = new PrivateChatController(loggedInUser, user, this);
            loader.setController(privateChatController);
            AnchorPane tmpPane = loader.load();
            Tab tmpTap = new Tab();
            tmpTap.setText("Chats");
            tmpTap.setClosable(false);
            tmpTap.setContent(tmpPane);
            int index = 3;
            tabMenu.getTabs().add(index, tmpTap);
            tabMenu.getSelectionModel().select(index);
        }
    }

    public void openAddQuizXML(User user, Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/AddQuizXML.fxml"));
        AddQuizXMLController quizController = new AddQuizXMLController(user, course);
        loader.setController(quizController);
        quizController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Quiz aus XML-Datei einlesen");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);
    }

    public void openTopicOverview(Topic topic, User lecturer) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/TopicOverview.fxml"));
        TopicOverviewController topicOverviewController = new TopicOverviewController(topic, this, lecturer);
        topicOverviewController.setMainWindowController(this);
        loader.setController(topicOverviewController);
        AnchorPane anchorPane = loader.load();
        tabMenu.getSelectionModel().getSelectedItem().setContent(anchorPane);
        tabMenu.getSelectionModel().getSelectedItem().setText(topic.getTitle());
    }

    public void openLiteratureTableView(Topic topic, User lecturer) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/LiteratureTableView.fxml"));
        loader.setController(new LiteratureTableViewController(topic, lecturer, this));
        AnchorPane anchorPane = loader.load();
        tabMenu.getSelectionModel().getSelectedItem().setContent(anchorPane);
    }


    public User getLoggedInUser() {
        return loggedInUser;
    }

    public void setLoggedInUser(User loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    public void openEvalStatisics(Course course) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/fxml/EvaluationStatistics.fxml"));
        EvaluationsStatisticsController evaluationsStatisticsController = new EvaluationsStatisticsController(course);
        loader.setController(evaluationsStatisticsController);
        evaluationsStatisticsController.setMainWindowController(this);
        AnchorPane tmpPane = loader.load();
        Tab tmpTap = new Tab();
        tmpTap.setText("Evaluations Statistik");
        tmpTap.setClosable(true);
        tmpTap.setContent(tmpPane);
        int index = tabMenu.getSelectionModel().getSelectedIndex() + 1;
        tabMenu.getTabs().add(index, tmpTap);
        tabMenu.getSelectionModel().select(index);

    }
}
