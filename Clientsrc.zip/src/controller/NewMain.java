package controller;

public class NewMain {
    public static void main(String[] args) {
        Main.main(args);
    }

}
