package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Course;
import model.Questions;
import model.Quiz;
import model.User;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import service.QuizService;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class AddEvaluationController {

    QuizService quizService;

    Quiz quiz;
    Course course;
    User user;
    public MainWindowController mainWindowController;

    int questionIndex = 0;
    int questionIndexListView = 1;

    @FXML
    public ListView<String> ListViewQuestions;
    @FXML
    public Button ButtonNextEvaluationQuestion, ButtonLastEvaluationQuestion, ButtonSaveEvaluation;
    @FXML
    public Label LabelQuestion;
    @FXML
    public TextArea TextAreaWriteEvaluationQuestion;

    public AddEvaluationController(User user, Course course) {
        this.user = user;
        this.course = course;
        quiz = new Quiz();
        quizService = new QuizService();
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public void initialize() {
        ListViewQuestions.getItems().add("E-Frage: " + questionIndexListView);
        LabelQuestion.setText("E-Frage: " + questionIndexListView);

        ArrayList<Questions> questions = new ArrayList<Questions>();

        ButtonNextEvaluationQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (questions.size() <= questionIndex) {
                    Questions temp = new Questions(String.valueOf(questionIndex), "", "", "", "", "", "", "");
                    questions.add(temp);

                    System.out.println("Frage: " + questions.size());

                    questions.get(questionIndex).setFrage(TextAreaWriteEvaluationQuestion.getText());
                    /*questions.get(questionIndex).setAntwortA("");
                    questions.get(questionIndex).setAntwortB("");
                    questions.get(questionIndex).setAntwortC("");
                    questions.get(questionIndex).setAntwortD("");*/

                    /*String correctAnswer = "";

                    questions.get(questionIndex).setRichtigeAntwort(correctAnswer);*/

                    questionIndex = questionIndex + 1;
                    questionIndexListView = questionIndexListView + 1;
                    ListViewQuestions.getItems().add("E-Frage: " + questionIndexListView);
                    LabelQuestion.setText("E-Frage: " + questionIndexListView);

                    TextAreaWriteEvaluationQuestion.clear();

                } else {
                    questionIndex = questionIndex + 1;
                    questionIndexListView = questionIndexListView + 1;

                    TextAreaWriteEvaluationQuestion.setText(questions.get(questionIndex).getFrage());

                    //questionIndex = questionIndex + 1;
                    //questionIndexListView = questionIndexListView + 1;
                    LabelQuestion.setText("Frage: " + questionIndexListView);

                    String richtigeantwort = questions.get(questionIndex).getRichtigeAntwort();
                }
            }
        });

        ButtonLastEvaluationQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (questionIndexListView >= 1) {
                    questionIndex = questionIndex - 1;
                    questionIndexListView = questionIndexListView - 1;
                    LabelQuestion.setText("E-Frage: " + questionIndexListView);

                    TextAreaWriteEvaluationQuestion.setText(questions.get(questionIndex).getFrage());

                    String richtigeantwort = questions.get(questionIndex).getRichtigeAntwort();
                }
            }
        });

        ButtonSaveEvaluation.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (!TextAreaWriteEvaluationQuestion.getText().equals("")) {
                    Questions temp = new Questions(String.valueOf(questionIndex), "", "", "", "", "", "", "");
                    questions.add(temp);

                    questions.get(questionIndex).setFrage(TextAreaWriteEvaluationQuestion.getText());

                    String correctAnswer = "";
                    questions.get(questionIndex).setRichtigeAntwort(correctAnswer);
                }

                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newDefaultInstance();
                DocumentBuilder builder;

                try {
                    builder = dbFactory.newDocumentBuilder();
                    Document doc = builder.newDocument();

                    //value Beispiel: (1,0,0,0)-(2,0,0,0)-(2,0,0,0)/userkey@versuche+1-userkey@versuche+0

                    StringBuilder newQuizString = new StringBuilder();

                    Element root = doc.createElement("Evaluationsfragen");

                    for (int i = 0; i < questions.size(); i++) {

                        Element fragenzeile = doc.createElement("Fragenzeile");
                        root.appendChild(fragenzeile);

                        Element fragenummer = doc.createElement("Fragennummer");
                        Text TextFragenummer = doc.createTextNode(String.valueOf((i + 1)));
                        fragenummer.appendChild(TextFragenummer);
                        fragenzeile.appendChild(fragenummer);

                        Element frage = doc.createElement("Frage");
                        Text TextFrage = doc.createTextNode(questions.get(i).getFrage());
                        frage.appendChild(TextFrage);
                        fragenzeile.appendChild(frage);

                        /*Element antwortA = doc.createElement("AntwortA");
                        Text TextAntwortA = doc.createTextNode("");
                        antwortA.appendChild(TextAntwortA);
                        fragenzeile.appendChild(antwortA);

                        Element antwortB = doc.createElement("AntwortB");
                        Text TextAntwortB = doc.createTextNode("");
                        antwortB.appendChild(TextAntwortB);
                        fragenzeile.appendChild(antwortB);

                        Element antwortC = doc.createElement("AntwortC");
                        Text TextAntwortC = doc.createTextNode("");
                        antwortC.appendChild(TextAntwortC);
                        fragenzeile.appendChild(antwortC);

                        Element antwortD = doc.createElement("AntwortD");
                        Text TextAntwortD = doc.createTextNode("");
                        antwortD.appendChild(TextAntwortD);
                        fragenzeile.appendChild(antwortD);

                        Element korrekteAntwort = doc.createElement("KorrekteAntwort");
                        Text TextKorrekteAntwort = doc.createTextNode("");
                        korrekteAntwort.appendChild(TextKorrekteAntwort);
                        fragenzeile.appendChild(korrekteAntwort);*/

                        newQuizString.append("(0,0,0,0)-");
                    }

                    int lastMinus = newQuizString.lastIndexOf("-");
                    newQuizString.deleteCharAt(lastMinus);
                    newQuizString.append("/");
                    newQuizString.append(newQuizString);
                    newQuizString.append(0);


                    doc.appendChild(root);

                    String path = "./Evaluation/Evaluation " + course.getName() + ".xml";
                    if (!directoryExists("./Evaluation")) {
                        new File("./Evaluation").mkdirs();
                    }

                    File file = new File(path);

                    DOMSource source = new DOMSource(doc);
                    Result result = new StreamResult(file);

                    TransformerFactory transformerFactory = TransformerFactory.newInstance();
                    Transformer transformer = transformerFactory.newTransformer();
                    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
                    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                    transformer.transform(source, result);
                    System.out.println("Daten gespeichert in: " + path);

                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    StreamResult streamResult = new StreamResult(bos);
                    transformer.transform(source, streamResult);
                    //byte []array=bos.toByteArray();

                    byte[] array = Files.readAllBytes(Path.of(path));

                    quiz.setWhoworkedonthatquiz(newQuizString.toString());
                    System.out.println(newQuizString.toString());
                    quiz.setCoursekey(course.getCoursekey());
                    quiz.setQuiz(array);
                    quiz.setType("eval");
                    quizService.addQuiz(quiz);


                    mainWindowController.openCourseAfterQuiz(user, course);

                } catch (ParserConfigurationException | TransformerException | IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }

    //@Author Noemi copy pasted von Kuri
    public boolean directoryExists(String path) throws FileNotFoundException, UnsupportedEncodingException {

        File file = new File(path);
        return (file.exists());
    }
}
