package controller;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.util.StringConverter;
import model.Event;
import service.EventService;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AddEventController {
    private MainWindowController mainWindowController;
    private EventService eventService;

    private int courseKey;
    private int hour;
    private int minute;
    Date datesql;
    private int index;
    public int indexFrom;


    @FXML
    Label headline;
    @FXML
    TextField nameTextfield;
    @FXML
    TextField timeTextfield;
    @FXML
    DatePicker datepicker;
    @FXML
    Button finishButton;
    @FXML
    Label errorLabel;


    public AddEventController(MainWindowController mainWindowController, int courseKey, int indexFrom) {
        this.mainWindowController = mainWindowController;
        this.eventService = new EventService();
        this.courseKey = courseKey;
        this.indexFrom = indexFrom;
    }

    public void initialize() throws IOException {
        errorLabel.setVisible(false);

        try {

            finishButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        addNewEvent();
                        mainWindowController.tabMenu.getSelectionModel().select(indexFrom + 1);
                        mainWindowController.tabMenu.getTabs().remove(index);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addNewEvent() throws IOException {

        dissectTime();

        LocalDate date = datepicker.getValue();
        String[] dateArray = date.toString().split("-");

        if (dateArray.length == 0) {
            errorLabel.setVisible(true);
            errorLabel.setText("Bitte ein Datum angeben");
        } else if (timeTextfield.getText().isEmpty()) {
            errorLabel.setVisible(true);
            errorLabel.setText("Bitte eine Uhrzeit angeben");
        } else if (nameTextfield.getText().isEmpty()) {
            errorLabel.setVisible(true);
            errorLabel.setText("Bitte einen Namen angeben");
        } else {
            datesql = java.sql.Date.valueOf(date);
            Event tmp = new Event(nameTextfield.getText(), courseKey, hour, minute, datesql);
            tmp.setTimestr(tmp.timeString());
            eventService.addEvent(tmp);

        }
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getIndexFrom() {
        return indexFrom;
    }

    public void setIndexFrom(int indexFrom) {
        this.indexFrom = indexFrom;
    }

    public void dissectTime() {
        String[] tmp = new String[2];
        tmp = timeTextfield.getText().split(":");
        hour = Integer.parseInt(tmp[0]);
        minute = Integer.parseInt(tmp[1]);

    }

}
