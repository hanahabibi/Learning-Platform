package controller;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.util.StringConverter;
import model.Event;
import model.Reminder;
import service.ReminderService;

import java.awt.*;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class AddReminderController {

    @FXML
    TextField nameTextField;
    @FXML
    DatePicker datePicker;
    @FXML
    javafx.scene.control.TextField timeTextField;
    @FXML
    ChoiceBox<String> typChoiceBox;
    @FXML
    javafx.scene.control.Button finishButton;
    @FXML
    javafx.scene.control.Label errorLabel;

    public ReminderService reminderService;
    public MainWindowController mainWindowController;
    public int eventid;
    public int index, indexFrom;
    public Date datesql;
    public int hour;
    public int minute;

    public AddReminderController(MainWindowController mainWindowController, int eventid, int indexFrom) {
        this.mainWindowController = mainWindowController;
        this.eventid = eventid;
        this.reminderService = new ReminderService();
        this.indexFrom = indexFrom;
    }

    public void initialize() throws IOException {
        typChoiceBox.getItems().add("E-Mail");
        typChoiceBox.getItems().add("Pop-Up");
        typChoiceBox.setValue("Pop-Up");

        errorLabel.setVisible(false);
        try {
            finishButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        addNewReminder();
                        mainWindowController.tabMenu.getSelectionModel().select(indexFrom + 1);
                        mainWindowController.tabMenu.getTabs().remove(index);
                        mainWindowController.currentDateController.fetchReminders(mainWindowController.currentDateController.currentDate.get(Calendar.YEAR), mainWindowController.currentDateController.currentDate.get(Calendar.MONTH) + 1, mainWindowController.currentDateController.currentDate.get(Calendar.DAY_OF_MONTH));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            datePicker.setConverter(new StringConverter<LocalDate>() {
                String pattern = "yyyy-MM-dd";
                DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

                {
                    datePicker.setPromptText(pattern.toLowerCase());
                }

                public String toString(LocalDate date) {
                    if (date != null) {
                        return dateFormatter.format(date);
                    } else {
                        return "";
                    }
                }

                public LocalDate fromString(String string) {
                    if (string != null && !string.isEmpty()) {
                        return LocalDate.parse(string, dateFormatter);
                    } else {
                        return null;
                    }
                }

            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void addNewReminder() throws IOException {
        dissectTime();

        LocalDate date = datePicker.getValue();
        String[] dateArray = date.toString().split("-");

        if (dateArray.length == 0) {
            errorLabel.setVisible(true);
            errorLabel.setText("Bitte ein Datum angeben");
        } else if (timeTextField.getText().isEmpty()) {
            errorLabel.setVisible(true);
            errorLabel.setText("Bitte eine Uhrzeit angeben");
        } else if (nameTextField.getText().isEmpty()) {
            errorLabel.setVisible(true);
            errorLabel.setText("Bitte einen Namen angeben");
        } else {
            datesql = Date.valueOf(date);
            System.out.println(datesql.toString());
            boolean poe = true;
            if (typChoiceBox.getValue().equals("E-Mail")) {
                poe = false;
            }

            Reminder tmp = new Reminder(nameTextField.getText(), hour, minute, datesql.toString(), poe, eventid);
            reminderService.addReminder(tmp);

        }
    }

    public void dissectTime() {
        String[] tmp = new String[2];
        tmp = timeTextField.getText().split(":");
        hour = Integer.parseInt(tmp[0]);
        minute = Integer.parseInt(tmp[1]);

    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
