package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import model.Lecturer;
import model.Student;
import model.User;
import service.LecturerService;
import service.StudentService;
import service.UserService;

import java.io.IOException;

public class PasswordController extends Child {

    public User userToCreate;
    public Stage stage;
    public LecturerService lecturerService;
    public StudentService studentService;
    public UserService userService;
    boolean showBackButton;
    boolean showCancelButton;

    public MainWindowController mainWindowController;
    @FXML
    public PasswordField UserInputSetPassword;
    @FXML
    public PasswordField UserInputSetPasswordAgain;
    @FXML
    public Button ConfirmButton;
    @FXML
    public Button goBackButton;
    @FXML
    public Button CancelButton;
    @FXML
    public Label ErrorCodePasswordLabel;
    @FXML
    public Label ErrorCodePasswordLabel1;
    @FXML
    public Label ErrorCodePasswordLabel2;
    @FXML
    public Label ErrorCodePasswordLabel3;
    @FXML
    public Label ErrorCodePasswordLabel4;
    @FXML
    public Label ErrorCodePasswordLabel5;
    @FXML
    public Label ErrorCodePasswordLabelPW1;
    @FXML
    public Label ErrorCodePasswordLabelPW2;

    public PasswordController(Stage stage, User userToCreate) {
        this.stage = stage;
        this.userToCreate = userToCreate;
        userService = new UserService();
        studentService = new StudentService();
        lecturerService = new LecturerService();
        showBackButton = true;
        showCancelButton = false;
    }

    public PasswordController(User currentUser) {
        this.userToCreate = currentUser;
        userService = new UserService();
        studentService = new StudentService();
        lecturerService = new LecturerService();
        showBackButton = false;
        showCancelButton = true;
    }

    @FXML
    public void initialize() throws InterruptedException, IOException {
        goBackButton.setVisible(showBackButton);
        CancelButton.setVisible(showCancelButton);

        ConfirmButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                //Bekomme die eingegebenen Passwörter
                String UserInputPasswordOne = UserInputSetPassword.getText();
                String UserInputPasswordTwo = UserInputSetPasswordAgain.getText();

                //Werte die Passwörter aus. Wurden die Gleichen Passwörter eingegeben?
                if (UserInputPasswordOne.equals(UserInputPasswordTwo)) {
                    //Folgt das Passwort dem Muster?
                    if (UserInputPasswordOne.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[.@$!%*?&(){}<>+#;:_-])[A-Za-z\\d.@$!%*?&(){}<>+#;:_-]{8,32}$")) {
                        //setze das User-Passwort
                        userToCreate.setPassword(UserInputPasswordOne);

                        try {
                            userService.setUser(userToCreate);
                            userService.getUserByEmail(userToCreate.getEmail());
                            userToCreate.setUserkey(userService.getCurrentUser().getUserkey());
                            if (userToCreate.getIsstudent() == 1) {
                                studentService.setStudent((Student) userToCreate);
                            } else {
                                lecturerService.setLecturer((Lecturer) userToCreate);
                            }
                            if (showBackButton == false) {
                                mainWindowController.openEditProfileTab();
                            } else {
                                backToStart();
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }

                    } else {
//Fehler für Passwort Vorgaben
                        ErrorCodePasswordLabel.setText("Das Passwort erfüllt nicht die Vorgaben:");
                        ErrorCodePasswordLabel1.setText("Mindestens eine Zahl [0-9]");
                        ErrorCodePasswordLabel2.setText("Mindestens einen kleinen Buchstaben [a-z]");
                        ErrorCodePasswordLabel3.setText("Mindestens einen großen Buchstaben [A-Z]");
                        ErrorCodePasswordLabel4.setText("Mindestens ein Sonderzeichen [.@$!%*?&(){}<>+#;:_-]");
                        ErrorCodePasswordLabel5.setText("Mindestens 8, aber höchstens 32 Zeichen");
                    }
                } else {
//Fehler für nicht gleiche Passwörter
                    ErrorCodePasswordLabelPW1.setText("Die Passwörter stimmen nicht überein");
                    ErrorCodePasswordLabelPW2.setText("Die Passwörter stimmen nicht überein");
                }

            }
        });

        goBackButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/RoleWindow.fxml"));
                    loader.setController(new RoleWindowController(userToCreate, stage));
                    Parent root = loader.load();
                    stage.setScene(new Scene(root));
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        });

        CancelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openEditProfileTab();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    public void setParent(MainWindowController parentController) {
        this.mainWindowController = parentController;
    }

    public void backToStart() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/StartWindow.fxml"));
        loader.setController(new StartWindowController(stage));
        Parent root = loader.load();
        stage.setScene(new Scene(root));
    }

}
