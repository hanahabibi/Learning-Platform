package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Literature;
import model.Topic;
import model.User;
import service.BibTexReader;
import service.TopicService;
import service.UserService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class TopicOverviewController {

    @FXML
    Label titleLabel;
    @FXML
    Label descriptionLabel;
    @FXML
    Label lecturerLabel;
    @FXML
    Button closeButton;
    @FXML
    Button editTopicButton;
    @FXML
    Button deleteTopicButton;
    @FXML
    Button literatureListButton;
    @FXML
    AnchorPane anchorPane;
    @FXML
    TableView<Literature> tableView;
    @FXML
    TableColumn<Literature, String> typeColumn;
    @FXML
    TableColumn<Literature, String> titleColumn;
    @FXML
    TableColumn<Literature, String> authorColumn;
    @FXML
    TableColumn<Literature, String> publisherColumn;
    @FXML
    TableColumn<Literature, String> yearColumn;

    Topic topic;
    TopicService topicService;
    User lecturer;
    UserService userService;
    MainWindowController mainWindowController;
    //enthält "Objekte" aus der .txt Datei
    ObservableList<ObservableList<String>> contentOfColumns = FXCollections.observableArrayList();
    ObservableList<Literature> literatureWithAllAttributes = FXCollections.observableArrayList();

    public TopicOverviewController(Topic topic, MainWindowController mainWindowController, User lecturer) {
        this.topic = topic;
        topicService = new TopicService();
        this.lecturer = lecturer;
        userService = new UserService();
        this.mainWindowController = mainWindowController;
    }

    public void initialize() throws IOException {

        //setzt Label
        titleLabel.setMaxWidth(336);
        titleLabel.setWrapText(true);
        titleLabel.setText(topic.getTitle());
        descriptionLabel.setMaxWidth(336);
        descriptionLabel.setWrapText(true);
        descriptionLabel.setText("Beschreibung: \n" + topic.getDescription());
        lecturerLabel.setText("Betreuende Lehrperson: \n" + lecturer.getFirstname() + " " + lecturer.getLastname());
        tableView = new TableView<>();
        tableView.setPrefHeight(480);
        tableView.setPrefWidth(580);
        tableView.setLayoutX(-8);
        tableView.setLayoutY(-1);
        if (topic.getLiterature() != null) {
            setTableView();
        }

        //Studenten können Themen weder bearbeiten noch löschen -> Buttons werden nicht angezeigt
        if (mainWindowController.loggedInUser.getIsstudent() == 1) {
            editTopicButton.setVisible(false);
            deleteTopicButton.setVisible(false);
        }
        //für Lehrpersonen haben die Buttons Funktionen
        else {

            //öffnet die Bearbeitungsansicht
            editTopicButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        mainWindowController.openEditTopic(topic);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

            //löscht das Thema aus der Datenbank
            deleteTopicButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        topicService.deleteTopic(topic.getTopickey());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Thema gelöscht");
                        alert.setContentText("Ihr Thema wurde erfolgreich gelöscht.");
                        alert.showAndWait();
                        mainWindowController.openProfileTab();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            });
        }
        //öffnet wieder das Profil der Lehrperson
        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    userService.getUser(topic.getLecturerkey());
                    mainWindowController.goBackToProfile(lecturer);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //öffnet die Tabelle mit der Literatur
        literatureListButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if (topic.getLiterature() == null) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Keine Literatur hinterlegt");
                        alert.setContentText("Für dieses Thema ist keine Literatur hinterlegt.");
                        alert.showAndWait();
                    } else {
                        mainWindowController.openLiteratureTableView(topic, lecturer);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        tableView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (!tableView.getItems().isEmpty()) {
                        if (mouseEvent.getClickCount() == 2) {
                            Literature tmp = tableView.getSelectionModel().getSelectedItem();
                            Stage primaryStage = new Stage();
                            FXMLLoader loader = new FXMLLoader();
                            loader.setLocation(getClass().getResource("/fxml/LiteratureView.fxml"));
                            loader.setController(new LiteratureViewController(findLiterature(tmp), primaryStage));
                            Parent root = loader.load();
                            primaryStage.setScene(new Scene(root));
                            primaryStage.show();

                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void setTableView() throws IOException {
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleColumn.setMinWidth(250.0);
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        authorColumn.setMinWidth(250.0);
        publisherColumn.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));

        File tempFile = File.createTempFile("literature", ".txt", null);
        FileOutputStream fos = new FileOutputStream(tempFile);
        fos.write(topic.getLiterature());

        //enthält den Inhalt der Tabelle nach Spalten sortiert
        contentOfColumns = BibTexReader.readAttributes(BibTexReader.fileAsString(tempFile));

        //enthält fertige Literature Objekte
        ObservableList<Literature> columns = LiteratureTableViewController.getLiteratureFromReader(contentOfColumns);
        literatureWithAllAttributes = LiteratureTableViewController.getLiteratureWithAllAttributes(contentOfColumns);
        columns.remove(0); // leere Zeile
        tableView.setItems(columns);
        tableView.getColumns().addAll(typeColumn, titleColumn, authorColumn, publisherColumn, yearColumn);
        anchorPane.getChildren().add(tableView);

    }

    public Literature findLiterature(Literature literature) {
        for (Literature a : literatureWithAllAttributes) {
            if (a.getTitle().equals(literature.getTitle()) && a.getYear().equals(literature.getYear())) {
                return a;
            }
        }
        return new Literature();
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

}
