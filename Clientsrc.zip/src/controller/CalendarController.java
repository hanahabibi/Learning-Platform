package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import model.Course;
import model.Event;
import model.Participant;
import model.User;
import service.CourseService;
import service.EventService;
import service.ParticipantService;
import value.Values;

import java.io.IOException;
import java.net.MalformedURLException;
import java.time.LocalDate;
import java.util.*;

public class CalendarController {

    //Controller
    public MainWindowController mainWindowController;
    public CurrentDateController currentDateController;
    //FXML
    @FXML
    public DatePicker setDateDatePicker;
    @FXML
    public DatePicker calendarDatePicker;
    @FXML
    public Label dateSetterLabel;
    @FXML
    public TableView eventTableView;
    @FXML
    public TableColumn<Event, String> timeColumn;
    @FXML
    public TableColumn<Event, String> nameColumn;

    //Services
    public EventService eventService;
    public ParticipantService participantService;
    public CourseService courseService;

    //Attribute für internen Gebrauch
    //Alle Events für den Tag
    public ObservableList<Event> eventsForThePickedDay = FXCollections.observableArrayList();
    //Alle Events von allen belegten Kursen
    public ObservableList<Event> allEventsForLoggedInUser = FXCollections.observableArrayList();
    ArrayList<Integer> courseslist = new ArrayList<Integer>(); //Alle belegten Kurse von denen die Events benoetigt werden
    public Calendar a;
    public User loggedInUser;
    public int currentyear;
    public int currentmonth;
    public int currentday;
    public final String BASE_URL = Values.Base_URL;


    public CalendarController(MainWindowController mainWindowController) throws MalformedURLException {
        this.mainWindowController = mainWindowController;
        this.currentDateController = mainWindowController.currentDateController;
        participantService = new ParticipantService();
        courseService = new CourseService();
        this.a = Calendar.getInstance();
        eventService = new EventService();
        this.loggedInUser = mainWindowController.getLoggedInUser();
    }

    public void initialize() throws IOException, InterruptedException {

        //Neue Tabellenspalten
        timeColumn.setCellValueFactory(new PropertyValueFactory<Event, String>("timestr"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<Event, String>("name"));

        //holt alle Events aus allen Courses in den der User drinnen ist
        getEvents();
        //Setzt den dafault Tag zu dem aktuellen Tag
        setDefaultDate();
        //lädt den inhalt zu dem aktuellen Tag
        loadCurrentDay();
        setCurrentDate();

        try {


            setDateDatePicker.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        setCurrentDate();
                    } catch (IOException | InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });

            calendarDatePicker.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {

                    loadCurrentDay();


                }
            });

            eventTableView.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    if (mouseEvent.getClickCount() == 2) {
                        try {
                            mainWindowController.openEventTab((Event) eventTableView.getSelectionModel().getSelectedItem(), 2);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setCurrentDate() throws IOException, InterruptedException {
        LocalDate Date = setDateDatePicker.getValue();
        if (Date != null) {
            Calendar tmp = Calendar.getInstance();
            tmp.set(Date.getYear(), Date.getMonthValue(), Date.getDayOfMonth());
            currentDateController.setCurrentDate(tmp);

        }
    }


    public void loadCurrentDay() {

        eventsForThePickedDay.clear();
        LocalDate date = calendarDatePicker.getValue();
        //Durchsucht alle Events nach den für den ausgewaehlten Tag
        int year = date.getYear();
        int month = date.getMonthValue();
        int day = date.getDayOfMonth();

        for (Event event : allEventsForLoggedInUser) {
            if (event.getYear() == year && event.getMonth() == month && event.getDay() == day) {
                eventsForThePickedDay.add(event);
            }
        }

        if (eventsForThePickedDay.isEmpty()) {
            eventsForThePickedDay.add(new Event("Keine Ereignisse an diesem Tag", 0, 0, 0, java.sql.Date.valueOf(date)));
        }
        eventTableView.getItems().setAll(eventsForThePickedDay);

    }

    public void getEvents() throws IOException {
        participantService.getParticipant(loggedInUser.getUserkey());
        for (Participant a : participantService.getCurrentParticipantList()) {
            eventService.getALLEventsForCourse(a.getCoursekey());
            allEventsForLoggedInUser.addAll(eventService.getEventList());
        }
    }


    public void setDefaultDate() {
        calendarDatePicker.setValue(LocalDate.now());
        setDateDatePicker.setValue(LocalDate.now());

    }

}
