package controller;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import model.Event;
import model.Participant;
import model.Reminder;
import model.User;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;

public class DialogRunnable implements Runnable {

    public CurrentDateController currentDateController;
    public MainWindowController mainWindowController;
    public ReminderEmailController reminderEmailController;
    public User loggedInUser;

    public DialogRunnable(MainWindowController mainWindowController) {

        this.currentDateController = mainWindowController.currentDateController;
        this.mainWindowController = mainWindowController;
        this.reminderEmailController = mainWindowController.reminderEmailController;
        this.loggedInUser = mainWindowController.getLoggedInUser();
    }

    @Override
    public void run() {
        long initTime = System.currentTimeMillis();
        long initTime2 = System.currentTimeMillis();
        boolean on = true;
        int hour = currentDateController.currentDate.get(Calendar.HOUR_OF_DAY);
        int minute = currentDateController.currentDate.get(Calendar.MINUTE);


        while (on) {

            if (System.currentTimeMillis() - initTime2 > 60000) {
                initTime2 = System.currentTimeMillis();
                System.out.println(currentDateController.getCurrentDate().toString());
                ObservableList<Reminder> a = currentDateController.reminders;
                for (Reminder reminder : a) {
                    if ((reminder.getHour() <= hour && reminder.getMinute() <= minute && !reminder.containsUser(loggedInUser.getUserkey()) && reminder.isEmailorpopup() == true) || (reminder.getHour() < hour && !reminder.containsUser(loggedInUser.getUserkey()) && reminder.isEmailorpopup() == true)) {
                        System.out.println("Probiere Reminder zuschreiben");
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    mainWindowController.showDialogPane(reminder);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        try {
                            currentDateController.hasSeenReminder(reminder, loggedInUser.getUserkey());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } else if (!reminder.containsUser(loggedInUser.getUserkey()) && (reminder.isEmailorpopup() == false)) {
                        try {
                            reminderEmailController.sendEmail(reminder);

                            currentDateController.eventService.getEventByID(reminder.getEventid());
                            Event event = currentDateController.eventService.getCurrentEvent();

                            currentDateController.participantService.getParticipantsOfCourse(event.getCoursekey());
                            List<Participant> allparti = currentDateController.participantService.getCurrentParticipantList();
                            for (Participant d : allparti) {

                                currentDateController.hasSeenReminder(reminder, d.getUserkey());

                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

            if (System.currentTimeMillis() - initTime > 300000) {
                initTime = System.currentTimeMillis();
                try {
                    currentDateController.fetchReminders(currentDateController.currentDate.get(Calendar.YEAR), currentDateController.currentDate.get(Calendar.MONTH), currentDateController.currentDate.get(Calendar.DAY_OF_MONTH));
                    hour = currentDateController.currentDate.get(Calendar.HOUR_OF_DAY);
                    minute = currentDateController.currentDate.get(Calendar.MINUTE);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    ;
}
