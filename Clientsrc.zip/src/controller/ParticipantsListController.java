package controller;

import exception.LecturerNotFoundException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Callback;
import model.*;
import service.LecturerService;
import service.ParticipantService;
import service.StudentService;
import service.UserService;

import java.io.IOException;


public class ParticipantsListController {

    private Course course;
    private MainWindowController mainWindowController;
    private ObservableList<Student> studentObservableList;
    private ObservableList<Lecturer> lecturerObservableList;
    @FXML
    private ListView ListViewLecturer;
    @FXML
    private ListView ListViewStudent;
    @FXML
    private Label LecturerLabel;
    @FXML
    private Label StudentLabel;

    private ObservableList<User> userObservableList;

    private ParticipantService participantService;
    private UserService userService;
    private StudentService studentService;
    private LecturerService lecturerService;

    public ParticipantsListController(Course course, MainWindowController mainWindowController) {
        this.course = course;
        this.mainWindowController = mainWindowController;
        participantService = new ParticipantService();
        userService = new UserService();
        studentService = new StudentService();
        lecturerService = new LecturerService();
        studentObservableList = FXCollections.observableArrayList();
        lecturerObservableList = FXCollections.observableArrayList();
    }


    public void initialize() throws IOException {
        seperateUsersByRole();
        ListViewStudent.setItems(studentObservableList);
        ListViewLecturer.setItems(lecturerObservableList);

        ListViewStudent.setCellFactory(new Callback<ListView<Student>, ListCell<Student>>() {
            @Override
            public ListCell call(ListView<Student> listView) {
                ListCell<Student> cell = new ListCell<Student>() {
                    @Override
                    protected void updateItem(Student student, boolean b) {
                        super.updateItem(student, b);
                        if (student != null) {
                            setText(student.getFirstname() + " " + student.getLastname());
                            if (student.getUserkey() == mainWindowController.loggedInUser.getUserkey()) {
                                setStyle("-fx-background-color:#93f55b");
                            }
                        }
                    }
                };
                return cell;
            }
        });

        ListViewLecturer.setCellFactory(new Callback<ListView<Lecturer>, ListCell<Lecturer>>() {
            @Override
            public ListCell call(ListView<Lecturer> listView) {
                ListCell<Lecturer> cell = new ListCell<Lecturer>() {
                    @Override
                    protected void updateItem(Lecturer lecturer, boolean b) {
                        super.updateItem(lecturer, b);
                        if (lecturer != null) {
                            setText(lecturer.getFirstname() + " " + lecturer.getLastname());
                            if (lecturer.getUserkey() == mainWindowController.loggedInUser.getUserkey()) {
                                setStyle("-fx-background-color:#93f55b");
                            }
                        }
                    }
                };
                return cell;
            }
        });


        ListViewLecturer.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {
                        User tmp = (User) ListViewLecturer.getSelectionModel().getSelectedItem();
                        if (tmp.getUserkey() == mainWindowController.loggedInUser.getUserkey()) {
                            mainWindowController.tabMenu.getSelectionModel().select(0);
                        } else {
                            mainWindowController.openProfileTab(tmp);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        ListViewStudent.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {
                        User tmp = (User) ListViewStudent.getSelectionModel().getSelectedItem();
                        if (tmp.getUserkey() == mainWindowController.loggedInUser.getUserkey()) {
                            mainWindowController.tabMenu.getSelectionModel().select(0);
                        } else {
                            mainWindowController.openProfileTab(tmp);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    public void seperateUsersByRole() throws IOException {
        participantService.getParticipantsOfCourse(course.getCoursekey());
        ObservableList<Participant> tmpList = FXCollections.observableArrayList();
        tmpList.setAll(participantService.getCurrentParticipantList());
        try {
            for (Participant a : tmpList
            ) {
                userService.getUser(a.getUserkey());
                if (userService.getCurrentUser().getIsstudent() == 1) {
                    studentService.getStudentByUserKey(a.getUserkey());
                    studentService.getCurrentStudent().join(userService.getCurrentUser());
                    studentObservableList.add(studentService.getCurrentStudent());

                } else {
                    lecturerService.getLecturerByUserKey(a.getUserkey());
                    lecturerService.getCurrentLecturer().join(userService.getCurrentUser());
                    lecturerObservableList.add(lecturerService.getCurrentLecturer());
                }
            }
        } catch (LecturerNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
    public void goToProfile(MouseEvent event) throws IOException {
        Parent toProfileParent = FXMLLoader.load(getClass().getResource("Profil.fxml"));
        Scene ToProfileScene = new Scene(toProfileParent);

        //get stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(ToProfileScene);
        window.show();

    }

}

