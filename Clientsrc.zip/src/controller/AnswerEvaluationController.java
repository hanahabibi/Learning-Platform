package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Participant;
import model.Questions;
import model.Quiz;
import model.User;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import service.ParticipantService;
import service.QuizService;
import service.StringService;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.ArrayList;

public class AnswerEvaluationController {

    User user;
    QuizService quizService;
    Quiz quiz;
    ParticipantService participantService;
    boolean passed = false;

    int questionIndex = 0;
    private MainWindowController mainWindowController;


    @FXML
    public ListView<String> ListViewQuestions;
    @FXML
    public CheckBox EvaluationCheckBoxAgree, EvaluationCheckBoxDisagree, CheckBoxAnswerNeutral, CheckBoxAnswerUnassessable;
    @FXML
    public Button ButtonLastQuestion, ButtonNextQuestion, ButtonEndEvaluation;
    @FXML
    public Label LabelQuestion;
    @FXML
    public TextArea TextAreaShowQuestion;


    public AnswerEvaluationController(Quiz a, User loggedInUser) throws IOException {
        this.user = loggedInUser;
        this.quiz = a;
        quizService = new QuizService();
        participantService = new ParticipantService();
        participantService.getParticipant(user.getUserkey());
        for (Participant b : participantService.getCurrentParticipantList()) {
            if (b.getCoursekey() == a.getCoursekey()) {
                if (b.getPassed() == 1) {
                    passed = true;
                }
            }
        }

    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public void initialize() throws IOException, ParserConfigurationException, SAXException {

        String directory = "./Evaluation";
        File XMLevaluation;
        if (!directoryExists(directory)) {
            new File(directory).mkdirs();
        }
        XMLevaluation = new File("./Evaluation/Evaluation " + ".xml");

        byte[] data = quiz.getQuiz();

        try (FileOutputStream stream = new FileOutputStream(XMLevaluation)) {
            stream.write(data);
            stream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document doc = builder.parse(XMLevaluation);

        NodeList QuestionNumber = doc.getElementsByTagName("Fragennummer");
        NodeList Questions = doc.getElementsByTagName("Frage");

        ArrayList<model.Questions> questions = new ArrayList<Questions>();

        for (int i = 0; i < Questions.getLength(); i++) {
            ListViewQuestions.getItems().add("Frage: " + (i + 1));
            Questions temp = new Questions(QuestionNumber.item(i).getTextContent(), Questions.item(i).getTextContent(), "");
            questions.add(temp);
        }

        TextAreaShowQuestion.setText(questions.get(questionIndex).getFrage());
        LabelQuestion.setText("Frage: " + questions.get(questionIndex).getFragenZahl());

        ButtonNextQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (EvaluationCheckBoxAgree.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("A");
                    EvaluationCheckBoxAgree.setSelected(false);
                } else if (EvaluationCheckBoxDisagree.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("B");
                    EvaluationCheckBoxDisagree.setSelected(false);
                } else if (CheckBoxAnswerNeutral.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("C");
                    CheckBoxAnswerNeutral.setSelected(false);
                } else if (CheckBoxAnswerUnassessable.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("D");
                    CheckBoxAnswerUnassessable.setSelected(false);
                }

                if (questionIndex <= Questions.getLength() - 1) {
                    questionIndex = questionIndex + 1;
                }

                String userantwort = questions.get(questionIndex).getUserAntwort();

                if (!userantwort.equals("")) {
                    if (userantwort.equals("A")) {
                        EvaluationCheckBoxAgree.setSelected(true);
                    }
                    if (userantwort.equals("B")) {
                        EvaluationCheckBoxDisagree.setSelected(true);
                    }
                    if (userantwort.equals("C")) {
                        CheckBoxAnswerNeutral.setSelected(true);
                    }
                    if (userantwort.equals("D")) {
                        CheckBoxAnswerUnassessable.setSelected(true);
                    }
                }


                // Gucken, ob die nächste Frage die letzte Frage ist
                if (questionIndex <= Questions.getLength() - 1) {
                    // Elemente aus dem Konstruktor setzten
                    TextAreaShowQuestion.setText(questions.get(questionIndex).getFrage());
                    LabelQuestion.setText("Frage: " + questions.get(questionIndex).getFragenZahl());
                }

            }
        });

        ButtonLastQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (questionIndex >= 0) {
                    EvaluationCheckBoxAgree.setSelected(false);
                    EvaluationCheckBoxDisagree.setSelected(false);
                    CheckBoxAnswerNeutral.setSelected(false);
                    CheckBoxAnswerUnassessable.setSelected(false);

                    questionIndex = questionIndex - 1;

                    TextAreaShowQuestion.setText(questions.get(questionIndex).getFrage());
                    LabelQuestion.setText("Frage: " + questions.get(questionIndex).getFragenZahl());

                    String userantwort = questions.get(questionIndex).getUserAntwort();

                    //Antwort einlesen und Checkbox bei vorher beantworteter Antwort setzten
                    if (userantwort.equals("A")) {
                        EvaluationCheckBoxAgree.setSelected(true);
                    }
                    if (userantwort.equals("B")) {
                        EvaluationCheckBoxDisagree.setSelected(true);
                    }
                    if (userantwort.equals("C")) {
                        CheckBoxAnswerNeutral.setSelected(true);
                    }
                    if (userantwort.equals("D")) {
                        CheckBoxAnswerUnassessable.setSelected(true);
                    }
                }
            }
        });


        ButtonEndEvaluation.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                if (EvaluationCheckBoxAgree.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("A");
                    EvaluationCheckBoxAgree.setSelected(false);
                } else if (EvaluationCheckBoxDisagree.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("B");
                    EvaluationCheckBoxDisagree.setSelected(false);
                } else if (CheckBoxAnswerNeutral.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("C");
                    CheckBoxAnswerNeutral.setSelected(false);
                } else if (CheckBoxAnswerUnassessable.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("D");
                    CheckBoxAnswerUnassessable.setSelected(false);
                }

                String tmp = quiz.getWhoworkedonthatquiz();

                StringService tmpStringService = new StringService("");
                tmpStringService.loadEval(tmp);

                for (int i = 0; i < questions.size(); i++) {

                    String userAntwort = questions.get(i).getUserAntwort();
                    if (passed) {
                        switch (userAntwort) {
                            case "A":
                                tmpStringService.getAnswersFromPassed()[i][0]++;
                                break;
                            case "B":
                                tmpStringService.getAnswersFromPassed()[i][1]++;
                                break;
                            case "C":
                                tmpStringService.getAnswersFromPassed()[i][2]++;
                                break;
                            case "D":
                                tmpStringService.getAnswersFromPassed()[i][3]++;
                                break;
                        }
                    } else {
                        switch (userAntwort) {
                            case "A":
                                tmpStringService.getAnswersFromFailed()[i][0]++;
                                break;
                            case "B":
                                tmpStringService.getAnswersFromFailed()[i][1]++;
                                break;
                            case "C":
                                tmpStringService.getAnswersFromFailed()[i][2]++;
                                break;
                            case "D":
                                tmpStringService.getAnswersFromFailed()[i][3]++;
                                break;
                        }
                    }
                }

                tmpStringService.addUserToEvalList(user.getUserkey());

                quiz.setWhoworkedonthatquiz(tmpStringService.buildStringEval().substring(0, tmpStringService.buildStringEval().length()));

                try {
                    quizService.addQuiz(quiz);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                mainWindowController.tabMenu.getTabs().remove(mainWindowController.tabMenu.getSelectionModel().getSelectedItem());

            }
        });


    }


    //@Author Noemi copy pasted von Fred
    public boolean directoryExists(String path) throws FileNotFoundException, UnsupportedEncodingException {
        File file = new File(path);
        return (file.exists());
    }

}
