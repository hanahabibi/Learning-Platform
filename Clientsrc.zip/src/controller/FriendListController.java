package controller;

import exception.StudentNotFoundException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import model.Course;
import model.Friend;
import model.Student;
import model.User;

import service.StudentService;
import service.UserService;

import java.io.IOException;

class FriendListController {

    private MainWindowController mainWindowController;

    User user;

    UserService userService;
    StudentService studentService;
    ObservableList<User> friendslist = FXCollections.observableArrayList();
    ObservableList<User> friendrequests = FXCollections.observableArrayList();

    @FXML
    private Label titleLabel;
    @FXML
    private Button sendMessageButton;
    @FXML
    private ListView<User> ListViewFriends;
    @FXML
    private Button closeButton;
    @FXML
    private ListView<User> friendRequestsList;

    public FriendListController(User user) {
        this.user = user;
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
        this.studentService = new StudentService();
        this.userService = new UserService();
    }

    @FXML
    public void initialize() throws IOException, StudentNotFoundException {
        friendslist.clear();
        sendMessageButton.setVisible(false);
        Student student = null;
        studentService.getAllStudent();
        for (Student a : studentService.getStudentList()) {
            if (a.getUserkey() == user.getUserkey()) {
                student = a;
            }
        }

        ObservableList<User> allFriends = FXCollections.observableArrayList();
        ObservableList<User> friendrequestsent = FXCollections.observableArrayList();
        ObservableList<User> friendrequestrecieved = FXCollections.observableArrayList();
        if (student != null) {

            if (student.getFriends() != null && student.getFstate() != null) {
                String friendsliststr = student.getFriends();
                String fstateliststr = student.getFstate();
                String[] studentl = friendsliststr.split(" ");
                String[] fstatel = fstateliststr.split(" ");
                int[] studentlint = new int[studentl.length];
                int[] fstatelint = new int[fstatel.length];
                for (int i = 0; i < studentl.length; i++) {
                    studentlint[i] = Integer.parseInt(studentl[i]);
                    fstatelint[i] = Integer.parseInt(fstatel[i]);
                    userService.getUser(studentlint[i]);
                    allFriends.add(userService.getCurrentUser());
                }
                for (int i = 0; i < allFriends.size(); i++) {
                    if (fstatelint[i] == 3) {
                        friendslist.add(allFriends.get(i));
                    } else if (fstatelint[i] == 2) {
                        friendrequestrecieved.add(allFriends.get(i));
                    } else if (fstatelint[i] == 1) {
                        friendrequestsent.add(allFriends.get(i));
                    } else {
                        allFriends.remove(allFriends.get(i));
                    }
                }
            }
        }


        ListViewFriends.setItems(friendslist);
        friendRequestsList.setItems(friendrequestrecieved);

        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openProfileTab();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        ListViewFriends.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {
                        studentService.getStudentByUserKey(ListViewFriends.getSelectionModel().getSelectedItem().getUserkey());
                        userService.getUser(ListViewFriends.getSelectionModel().getSelectedItem().getUserkey());
                        studentService.getCurrentStudent().join(userService.getCurrentUser());
                        mainWindowController.openProfileTab(studentService.getCurrentStudent());
                    }
                } catch (IOException | StudentNotFoundException e) {
                    e.printStackTrace();
                }

            }
        });

        friendRequestsList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {

                        studentService.getStudentByUserKey(friendRequestsList.getSelectionModel().getSelectedItem().getUserkey());
                        userService.getUser(friendRequestsList.getSelectionModel().getSelectedItem().getUserkey());
                        studentService.getCurrentStudent().join(userService.getCurrentUser());
                        mainWindowController.openProfileTab(studentService.getCurrentStudent());
                    }
                } catch (IOException | StudentNotFoundException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    public Label getTitleLabel() {
        return titleLabel;
    }

    public void setTitleLabel(Label titleLabel) {
        this.titleLabel = titleLabel;
    }

    public Button getSendMessageButton() {
        return sendMessageButton;
    }

    public void setSendMessageButton(Button sendMessageButton) {
        this.sendMessageButton = sendMessageButton;
    }

    public ListView getListViewFriends() {
        return ListViewFriends;
    }

    public void setListViewFriends(ListView listViewFriends) {
        ListViewFriends = listViewFriends;
    }

    public Button getCloseButton() {
        return closeButton;
    }

    public void setCloseButton(Button closeButton) {
        this.closeButton = closeButton;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
