package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.*;
import service.*;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ReminderEmailController {

    public MailService mailService;
    public ReminderService reminderService;
    public EventService eventService;
    public CourseService courseService;
    public UserService userService;
    public ParticipantService participantService;
    public List<Reminder> reminderForTheDay = FXCollections.observableArrayList();
    public MainWindowController mainWindowController;
    public Calendar c = Calendar.getInstance();

    public ReminderEmailController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
        this.mailService = new MailService();
        this.reminderService = new ReminderService();
        this.eventService = new EventService();
        this.courseService = new CourseService();
        this.userService = new UserService();
        this.participantService = new ParticipantService();


    }

    public ObservableList<User> getParticipants(int coursekey) throws IOException {
        ObservableList<User> erg = FXCollections.observableArrayList();
        participantService.getParticipantsOfCourse(coursekey);
        List<Participant> temp = participantService.getCurrentParticipantList();

        for (Participant p : temp) {
            userService.getUser(p.getUserkey());
            erg.add(userService.getCurrentUser());
        }
        return erg;
    }

    public void sendEmail(Reminder reminder) throws IOException {
        eventService.getEventByID(reminder.getEventid());
        Event event = eventService.getCurrentEvent();
        courseService.getCourseByID(event.getCoursekey());
        Course course = courseService.getCurrentCourse();
        ObservableList<User> participants = FXCollections.observableArrayList();
        participants = getParticipants(event.getCoursekey());
        String title = "Erinnerung: " + event.getName();
        String text = "Erinnerung zu " + course.getName() + ". Der Termin " + event.getName() + " ist am " + event.dateToString() + " um " + event.timeString() + "." + reminder.getTitle();

        for (User a : participants) {
            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mailService.sendMailTo(a.getEmail(), title, text);
        }
    }

    public void getRemindersForDay(int[] a) throws IOException {
        String date = "";
        if (a[1] < 10 && a[2] < 10)
            date = Integer.toString(a[0]) + "-0" + Integer.toString(a[1]) + "-0" + Integer.toString(a[2]);
        if (a[1] < 10) date = Integer.toString(a[0]) + "-0" + Integer.toString(a[1]) + "-" + Integer.toString(a[2]);
        if (a[2] < 10) date = Integer.toString(a[0]) + "-" + Integer.toString(a[1]) + "-0" + Integer.toString(a[2]);
        else date = Integer.toString(a[0]) + "-" + Integer.toString(a[1]) + "-" + Integer.toString(a[2]);
        reminderService.getAllReminderForDay(date);

        reminderForTheDay = reminderService.getReminderList();
    }

}

