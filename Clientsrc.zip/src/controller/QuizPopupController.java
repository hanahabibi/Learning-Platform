package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Course;
import model.Quiz;
import model.User;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import service.QuizService;
import service.StringService;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class QuizPopupController {

    MainWindowController mainWindowController;
    Stage stage;
    StringService stringService;
    Quiz quiz;
    QuizService quizService;
    Course course;
    User user;
    int quizcounter = 1;

    ArrayList<Quiz> quizzes;
    ObservableList quiznames;
    boolean fromCourse;

    @FXML
    public ListView<String> ListViewChooseQuiz;

    public QuizPopupController(MainWindowController mainWindowController, Stage primaryStage, Course course, User user, boolean fromCourse) {
        this.mainWindowController = mainWindowController;
        this.stage = primaryStage;
        this.course = course;
        this.user = user;
        quizService = new QuizService();
        quizzes = new ArrayList();
        quiznames = FXCollections.observableArrayList();
        this.fromCourse = fromCourse;
    }

    public void initialize() throws IOException, ParserConfigurationException, SAXException {

        quizService.getQuizByCourseKey(course.getCoursekey());
        for (int i = 0; i < quizService.getQuizList().size(); i++) {

            String directory = "./Quiz";
            File XMLquiz;
            if (!directoryExists(directory)) {
                new File(directory).mkdirs();
            }

            XMLquiz = new File("./Quiz/Quiz.xml");

            byte[] data = quizService.getQuizList().get(i).getQuiz();

            try (FileOutputStream stream = new FileOutputStream(XMLquiz)) {
                stream.write(data);
                stream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            Document doc = builder.parse(XMLquiz);

            Element root = doc.getDocumentElement();

            if (root.getNodeName().contains("Quizfragen")) {
                quizzes.add(quizService.getQuizList().get(i));
                quiznames.add("Quiz: " + quizcounter);
                quizcounter = quizcounter + 1;
            }

        }

        ListViewChooseQuiz.setItems(quiznames);


        ListViewChooseQuiz.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    if (!fromCourse) {
                        Quiz temp = (Quiz) quizzes.get(ListViewChooseQuiz.getSelectionModel().getSelectedIndex());
                        try {
                            mainWindowController.openAnswerQuiz(mainWindowController.loggedInUser, temp);
                            stage.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Quiz temp = (Quiz) quizzes.get(ListViewChooseQuiz.getSelectionModel().getSelectedIndex());
                        try {
                            mainWindowController.openQuizStatisics(temp);
                            stage.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    //@Author Noemi copy pasted von Fred
    public boolean directoryExists(String path) throws FileNotFoundException, UnsupportedEncodingException {

        File file = new File(path);
        return (file.exists());
    }
}
