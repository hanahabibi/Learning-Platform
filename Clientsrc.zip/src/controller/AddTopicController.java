package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import model.Topic;
import model.User;
import service.TopicService;
import java.io.*;
import java.nio.file.Files;

public class AddTopicController {

    @FXML
    Label literatureLabel;
    @FXML
    Label lecturerLabel;
    @FXML
    TextField titleTextField;
    @FXML
    TextArea descriptionTextArea;
    @FXML
    Button uploadLiteratureButton;
    @FXML
    Button confirmButton;
    @FXML
    Button cancelButton;
    @FXML
    Button showLiteratureTableButton;
    @FXML
    AnchorPane anchorPane;

    User loggedInUser;
    TopicService topicService;
    MainWindowController mainWindowController;

    public byte[] literature;

    //contructor
    public AddTopicController(User loggedInUser, MainWindowController mainWindowController) {
        this.loggedInUser = loggedInUser;
        this.mainWindowController = mainWindowController;
        topicService = new TopicService();
    }


    @FXML
    public void initialize() {

        lecturerLabel.setText("betreuende Lehrperson: \n" + loggedInUser.getFirstname() + " " + loggedInUser.getLastname());
        showLiteratureTableButton.setVisible(false);
        literatureLabel.setVisible(false);
        anchorPane.setVisible(false);

        confirmButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                //speichern, ob Textfelder ausgefüllt sind
                Boolean titleBool = false;
                Boolean descriptionBool = false;

                try {
                    if (titleTextField.getText() != "") {
                        titleTextField.getText();
                        topicService.getTopicByTitle(titleTextField.getText());
                        if (topicService.getCurrentTopic().getTitle() == null) {
                            titleBool = true;
                        }

                        //wenn Titel schon in Datenbank existiert
                        else {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Thema bereits vorhanden");
                            alert.setContentText("Es existert bereits ein Thema mit diesem Titel. Bitte geben Sie einen anderen Titel ein.");
                            alert.showAndWait();
                            titleTextField.clear();
                            descriptionTextArea.clear();
                        }
                    }

                    if (descriptionTextArea.getText() != "") {
                        descriptionBool = true;
                    }

                    //wenn alles richtig ausgefüllt ist
                    if (titleBool && descriptionBool) {
                        Topic newTopic = new Topic(titleTextField.getText(), descriptionTextArea.getText(), loggedInUser.getUserkey(), literature);
                        topicService.addTopic(newTopic);
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Thema hinzugefügt");
                        alert.setContentText("Ihr Thema wurde erfolgreich hinzugefügt.");
                        alert.showAndWait();
                        mainWindowController.openProfileTab();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //wenn "Abbrechen"-Button gedrückt wird
        cancelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    //öffnet wieder Profil der Lehrperson(loggedInUser)
                    mainWindowController.openProfileTab();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //öffnet FileChooser
        uploadLiteratureButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();

                try {
                    //setzt .txt FileChooser
                    FileChooser.ExtensionFilter extFiltertxt = new FileChooser.ExtensionFilter("txt files (*.txt)", "*.txt");
                    FileChooser.ExtensionFilter extFilterTXT = new FileChooser.ExtensionFilter("TXT files (*.TXT)", "*.TXT");
                    fileChooser.getExtensionFilters().addAll(extFiltertxt, extFilterTXT);

                    File file = fileChooser.showOpenDialog(null);

                    //wandelt File in Byte Array um
                    if (file != null) {
                        literature = Files.readAllBytes(file.toPath());
                        literature = Files.readAllBytes(file.toPath());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        showLiteratureTableButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openLiteratureTableView(topicService.getCurrentTopic(), loggedInUser);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
    }
}
