package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Literature;
import model.Topic;
import model.User;
import service.BibTexReader;
import service.TopicService;
import service.UserService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;

public class EditTopicController {

    @FXML
    AnchorPane anchorPane;
    @FXML
    TableView<Literature> tableView;
    @FXML
    TableColumn<Literature, String> typeColumn;
    @FXML
    TableColumn<Literature, String> titleColumn;
    @FXML
    TableColumn<Literature, String> authorColumn;
    @FXML
    TableColumn<Literature, String> publisherColumn;
    @FXML
    TableColumn<Literature, String> yearColumn;
    @FXML
    TextField titleTextField;
    @FXML
    Label lecturerLabel;
    @FXML
    TextArea descriptionTextArea;
    @FXML
    Button uploadLiteratureButton;
    @FXML
    Button confirmButton;
    @FXML
    Button cancelButton;
    @FXML
    Button showLiteratureTableButton;

    Topic topic;
    TopicService topicService;
    UserService userService;
    MainWindowController mainWindowController;
    public byte[] literature;
    //enthält "Objekte" aus der .txt Datei
    ObservableList<ObservableList<String>> contentOfColumns = FXCollections.observableArrayList();
    ObservableList<Literature> literatureWithAllAttributes = FXCollections.observableArrayList();

    public EditTopicController(Topic topic, MainWindowController mainWindowController) {
        this.topic = topic;
        topicService = new TopicService();
        userService = new UserService();
        this.mainWindowController = mainWindowController;
    }

    public void initialize() throws IOException {
        userService.getUser(topic.getLecturerkey());
        User lecturer = userService.getCurrentUser();
        titleTextField.setText(topic.getTitle());
        descriptionTextArea.setText(topic.getDescription());
        lecturerLabel.setText("Betreuende Lehrperson: \n" + lecturer.getFirstname() + " " + lecturer.getLastname());

        tableView = new TableView<>();
        tableView.setPrefHeight(472);
        tableView.setPrefWidth(575);
        tableView.setLayoutX(-8);
        tableView.setLayoutY(-1);
        if (topic.getLiterature() != null) {
            literature = topic.getLiterature();
            setTableView();
        }

        //ändert die Eigenschaften in der Datenbank
        confirmButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                //speichern, ob Textfelder ausgefüllt sind
                Boolean titleBool = false;
                Boolean descriptionBool = false;

                try {
                    topicService.getTopicByTopickey(topic.getTopickey());
                    if (titleTextField.getText() != "") {
                        titleBool = true;
                    }
                    if (descriptionTextArea.getText() != "") {
                        descriptionBool = true;
                    }

                    //wenn alles richtig ausgefüllt ist
                    if (titleBool && descriptionBool) {
                        topicService.getTopicByTopickey(topic.getTopickey());
                        topicService.getCurrentTopic().setTitle(titleTextField.getText());
                        topicService.getCurrentTopic().setDescription(descriptionTextArea.getText());
                        topicService.getCurrentTopic().setLecturerkey(lecturer.getUserkey());
                        topicService.getCurrentTopic().setLiterature(literature);
                        topicService.addTopic(topicService.getCurrentTopic());
                        if (titleTextField.getText().equals(topic.getTitle()) && descriptionTextArea.getText().equals(topic.getDescription())) {
                            if (topic.getLiterature() == null && topicService.getCurrentTopic().getLiterature() == null && literature == null) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Thema wurde nicht verändert");
                                alert.setContentText("Sie haben keine Angaben an diesem Thema geändert.");
                                alert.showAndWait();
                                mainWindowController.openTopicOverview(topicService.getCurrentTopic(), mainWindowController.loggedInUser);
                            } else if (topic.getLiterature() != null) {
                                if (!topic.getLiterature().equals(literature)) {
                                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                    alert.setTitle("Thema wurde nicht verändert");
                                    alert.setContentText("Sie haben keine Angaben an diesem Thema geändert.");
                                    alert.showAndWait();
                                    mainWindowController.openTopicOverview(topicService.getCurrentTopic(), mainWindowController.loggedInUser);
                                }
                            } else {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Thema geändert");
                                alert.setContentText("Ihr Thema wurde erfolgreich abgeändert.");
                                alert.showAndWait();
                                mainWindowController.openTopicOverview(topicService.getCurrentTopic(), mainWindowController.loggedInUser);
                            }
                        } else {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Thema geändert");
                            alert.setContentText("Ihr Thema wurde erfolgreich abgeändert.");
                            alert.showAndWait();
                            mainWindowController.openTopicOverview(topicService.getCurrentTopic(), mainWindowController.loggedInUser);
                        }
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Fehlende Angaben");
                        alert.setContentText("Bitte füllen Sie alle Textfelder aus.");
                        alert.showAndWait();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //öffnet FileChooser
        uploadLiteratureButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();

                try {
                    //setzt .txt FileChooser
                    FileChooser.ExtensionFilter extFiltertxt = new FileChooser.ExtensionFilter("txt files (*.txt)", "*.txt");
                    FileChooser.ExtensionFilter extFilterTXT = new FileChooser.ExtensionFilter("TXT files (*.TXT)", "*.TXT");
                    fileChooser.getExtensionFilters().addAll(extFiltertxt, extFilterTXT);

                    File file = fileChooser.showOpenDialog(null);

                    //wandelt File in Byte Array um
                    if (file != null) {
                        literature = Files.readAllBytes(file.toPath());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Literaturliste hochgeladen");
                        alert.setContentText("Die Literaturliste wurde erfolgreich hochgeladen. Bestätigen Sie die Änderungen, um wieder zur Übersicht zu gelangen.");
                        alert.showAndWait();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        showLiteratureTableButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (topic.getLiterature() == null) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Keine Literatur hinterlegt");
                    alert.setContentText("Für dieses Thema ist keine Literatur hinterlegt.");
                    alert.showAndWait();
                } else {
                    try {
                        mainWindowController.openLiteratureTableView(topic, mainWindowController.loggedInUser);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        tableView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (!tableView.getItems().isEmpty()) {
                        if (mouseEvent.getClickCount() == 2) {
                            Literature tmp = tableView.getSelectionModel().getSelectedItem();
                            Stage primaryStage = new Stage();
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/LiteratureView.fxml"));
                            loader.setController(new LiteratureViewController(findLiterature(tmp), primaryStage));
                            Parent root = loader.load();
                            primaryStage.setScene(new Scene(root));
                            primaryStage.show();

                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //wenn auf "Abbrechen"-Button gedrückt wird -> geht zurpück zur Themenübersicht
        cancelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openTopicOverview(topic, mainWindowController.loggedInUser);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


    }

    public void setTableView() throws IOException {
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleColumn.setMinWidth(250.0);
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        authorColumn.setMinWidth(250.0);
        publisherColumn.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));

        File tempFile = File.createTempFile("literature", ".txt", null);
        FileOutputStream fos = new FileOutputStream(tempFile);
        fos.write(topic.getLiterature());

        //enthält den Inhalt der Tabelle nach Spalten sortiert
        contentOfColumns = BibTexReader.readAttributes(BibTexReader.fileAsString(tempFile)/*, BibTexReader.getTypes(tempFile)*/);

        //enthält fertige Literature Objekte
        ObservableList<Literature> columns = LiteratureTableViewController.getLiteratureFromReader(contentOfColumns);
        literatureWithAllAttributes = LiteratureTableViewController.getLiteratureWithAllAttributes(contentOfColumns);
        columns.remove(1); // Zeile, die nur Attributbezeichnungen enthält
        columns.remove(0); // leere Zeile
        tableView.setItems(columns);
        tableView.getColumns().addAll(typeColumn, titleColumn, authorColumn, publisherColumn, yearColumn);
        anchorPane.getChildren().add(tableView);

    }

    public Literature findLiterature(Literature literature) {
        for (Literature a : literatureWithAllAttributes) {
            if (a.getTitle().equals(literature.getTitle()) && a.getYear().equals(literature.getYear())) {
                return a;
            }
        }
        return new Literature();
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }
}
