package controller;

import handler.MyStompSessionHandler;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import model.*;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;
import service.ChatMessageService;
import service.ChatService;
import service.UserService;
import value.Values;


import javax.imageio.ImageIO;
import java.io.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PrivateChatController {

    @FXML
    Button sendButton;
    @FXML
    ListView chatsOverview; //Nachrichten in einem Chat
    @FXML
    ListView messageBasePane; //laufende Chats
    @FXML
    TextArea textArea;

    User loggedInUser;
    User user;
    FXMLLoader loader;

    Chat chat;
    ArrayList<ChatPersonController> chatPersonController;
    WebSocketClient client;
    WebSocketStompClient stompClient;
    MyStompSessionHandler stompSessionHandler;
    StompSession session;
    String URL = Values.Base_URL + "/chatmessage/";
    MainWindowController mainWindowController;
    ChatService chatService;
    ChatMessageService chatMessageService;
    UserService userService;
    String chatkey;

    public PrivateChatController() {

    }

    public PrivateChatController(User loggedInUser, User user, MainWindowController mainWindowController) {
        this.loggedInUser = loggedInUser;
        this.user = user;
        this.setMainWindowController(mainWindowController);
        this.chatService = mainWindowController.chatService;
        client = new StandardWebSocketClient();
        SockJsClient sockJsClient = new SockJsClient(List.of(new WebSocketTransport(client)));
        stompClient = new WebSocketStompClient(sockJsClient);
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());
        stompSessionHandler = new MyStompSessionHandler(loggedInUser.getUserkey());
        stompSessionHandler.setPrivateChatController(this);
        userService = new UserService();
        try {
            session = stompClient.connect(URL, stompSessionHandler).get();
        } catch (Exception e) {
            e.printStackTrace();
        }

        chatPersonController = new ArrayList();
        chatService = new ChatService();
        chatMessageService = new ChatMessageService();

    }


    public MainWindowController getMainWindowController() {
        return mainWindowController;
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
        loggedInUser = mainWindowController.loggedInUser;
    }

    String path = Values.Dir_Path;

    @FXML
    public void initialize() throws IOException {

        if (user == null) {
            List<Chat> tmp = chatService.getChatsByUserKey(loggedInUser.getUserkey());
            for (Chat a : tmp) {
                loader = new FXMLLoader();
                int chatPartner1 = Integer.parseInt(a.getChatkey().split("-")[0]);
                int chatPartner2 = Integer.parseInt(a.getChatkey().split("-")[1]);
                if (loggedInUser.getUserkey() == chatPartner1) {
                    userService.getUser(chatPartner2);
                } else {
                    userService.getUser(chatPartner1);
                }
                user = userService.getCurrentUser();

                ChatPersonController personController = new ChatPersonController(user);
                loader.setLocation(getClass().getResource("/fxml/ChatPerson.fxml"));
                loader.setController(personController);
                AnchorPane tmpa = loader.load();
                chatPersonController.add(personController);
                chatsOverview.getItems().add(tmpa);
                showOfflineMessages(loggedInUser.getUserkey());

            }

        } else {
            List<User> chatMembers = new ArrayList<>();
            chatMembers.add(loggedInUser);
            chatMembers.add(user);
            chatkey = chatService.createPrivateChatkey(chatMembers);

            try {
                chatService.getChatByChatKey(chatkey);

                if (chatService.getCurrentChat().getChatkey() != null) {
                    try {
                        if (!chatService.directoryExists(Values.Dir_Path + File.separator + loggedInUser.getUserkey() + "-" + chatkey + ".txt")) {
                            if (!chatService.directoryExists(Values.Dir_Path)) {
                                chatService.createChatDirectory();
                            }
                            chatService.createChatFile(chatkey, loggedInUser.getUserkey());
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else {
                    Chat tmpchat = new Chat(chatkey, "private", loggedInUser.getUserkey(), user.getUserkey());
                    chatService.addNewChat(tmpchat);

                    try {
                        if (!chatService.directoryExists(Values.Dir_Path + File.separator + loggedInUser.getUserkey() + "-" + chatkey + ".txt")) {
                            if (!chatService.directoryExists(Values.Dir_Path)) {
                                chatService.createChatDirectory();
                            }
                            chatService.createChatFile(chatkey, loggedInUser.getUserkey());
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                chatService.getChatByChatKey(chatkey);
                chat = chatService.getCurrentChat();
                loader = new FXMLLoader();
                ChatPersonController personController = new ChatPersonController(user);
                loader.setLocation(getClass().getResource("/fxml/ChatPerson.fxml"));
                loader.setController(personController);
                AnchorPane tmp = loader.load();
                chatPersonController.add(personController);
                chatsOverview.getItems().add(tmp);

            } catch (IOException e) {
                e.printStackTrace();
            }

            loadLocalMessages(chatkey);
        }


        chatsOverview.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 1) {

                    try {
                        for (int i = 0; i < chatsOverview.getItems().size(); i++) {
                            if (chatsOverview.getItems().get(i) == chatsOverview.getSelectionModel().getSelectedItem()) {
                                ArrayList<User> tmpUserList = new ArrayList<>();
                                tmpUserList.add(chatPersonController.get(i).getChatUser());
                                tmpUserList.add(mainWindowController.loggedInUser);
                                chatkey = chatService.createPrivateChatkey(tmpUserList);

                                user = chatPersonController.get(i).getChatUser();

                                messageBasePane.getItems().clear();
                                loadLocalMessages(chatkey);

                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ;
                }
            }
        });

        sendButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if (textArea.getText() != null) {
                        Timestamp temp = new Timestamp(System.currentTimeMillis());
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String timeStamp = sdf.format(temp);

                        ChatMessage tmp = new ChatMessage(chatkey, mainWindowController.loggedInUser.getUserkey(), user.getUserkey(), textArea.getText(), timeStamp);

                        textArea.clear();
                        session.send("/app/message/" + user.getUserkey(), tmp);
                        session.send("/app/message/" + loggedInUser.getUserkey(), tmp);
                        chatMessageService.addChatMessage(tmp);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    public void showOfflineMessages(int userkey) throws IOException {
        List<ChatMessage> allMessages = new ArrayList<>();
        chatMessageService.getALlChatMessage();
        if (chatMessageService.getChatMessageList() != null) {
            allMessages = chatMessageService.getChatMessageList();
            for (ChatMessage a : allMessages) {
                if (a.getReceiverid() == userkey) {
                    chatService.createMessage(a, a.getReceiverid());
                    chatMessageService.deleteChatMessage(a);
                }
            }
        }
    }

    public int chatExist(int userkey) {
        for (int i = 0; i < chatPersonController.size(); i++) {
            if (chatPersonController.get(i).getChatUser().getUserkey() == userkey)
                return i;
        }
        return -1;
    }

    //lädt alte Nachrichten
    public void loadLocalMessages(String chatkey) throws IOException {

        //findet Datei in der Chatlines gespeichert sind
        File file = new File(Values.Dir_Path + File.separator + loggedInUser.getUserkey() + "-" + chatkey + ".txt");
        FileInputStream fis = new FileInputStream(file);
        InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
        BufferedReader bufferedReader = new BufferedReader(isr);
        String line;

        //liest Datei Zeile für Zeile aus
        while ((line = bufferedReader.readLine()) != null && line != "") {

            char[] ca = line.toCharArray();

            //liest Nachricht aus
            StringBuilder lineForBubble = new StringBuilder();
            int i = 5;
            while (i < ca.length && ca[i] != '}') {
                lineForBubble.append(ca[i]);
                i++;
            }
            //liest Timestamp aus
            int beginningOfTimeStamp = line.indexOf("(@*") + 3;
            int endOfTimeStamp = beginningOfTimeStamp + 19;
            String timeStamp = line.substring(beginningOfTimeStamp, endOfTimeStamp);
            int temp = Integer.parseInt(line.substring(0, line.indexOf(":")));

            //prüft auf welche Seite die Nachricht muss
            if (temp == mainWindowController.loggedInUser.getUserkey()) {
                addRightMessage(lineForBubble.toString(), timeStamp);
            } else {
                addLeftMessage(lineForBubble.toString(), timeStamp);
            }
        }
    }


    /*
    Userkeys aufsteigend sortieren
    --> wenn in Chat Tabelle vorhanden und noch kein Chat-Ordner: erstelle chat ordner
    --> wenn kein Chat vorhanden: erstelle chat + Ordner


 */


    //erstellt lokalen Chat Ordner
    public void createChatDirectory() {

        new File(Values.Dir_Path).mkdirs();

    }


    //prüft, ob Chat Datei existiert
    public boolean directoryExists(String path) throws FileNotFoundException, UnsupportedEncodingException {

        File file = new File(path);
        return (file.exists());
    }

    public void openChat(User user) throws IOException {

    }


    public void addLeftMessage(String txt, String timeStamp) throws IOException {
        HBox hBox = new HBox();
        BubbledLabel tmp = new BubbledLabel(txt, timeStamp);
        tmp.setBackground(new Background(new BackgroundFill(Color.LIGHTPINK, null, null)));
        hBox.getChildren().add(tmp);
        hBox.setAlignment(Pos.BASELINE_LEFT);
        messageBasePane.getItems().add(hBox);

    }

    public void addRightMessage(String txt, String timeStamp) throws IOException {
        HBox hBox = new HBox();
        BubbledLabel tmp = new BubbledLabel(txt, timeStamp);
        tmp.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, null, null)));
        tmp.setBubbleSpec(BubbleSpec.FACE_RIGHT_CENTER);
        hBox.getChildren().add(tmp);
        hBox.setAlignment(Pos.BASELINE_RIGHT);
        messageBasePane.getItems().add(hBox);
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ListView getMessageBasePane() {
        return messageBasePane;
    }

    public void setMessageBasePane(ListView messageBasePane) {
        this.messageBasePane = messageBasePane;
    }

    public ListView getChatsOverview() {
        return chatsOverview;
    }

    public void setChatsOverview(ListView chatsOverview) {
        this.chatsOverview = chatsOverview;
    }

    public ArrayList<ChatPersonController> getChatPersonController() {
        return chatPersonController;
    }

    public void setChatPersonController(ArrayList<ChatPersonController> chatPersonController) {
        this.chatPersonController = chatPersonController;
    }
}
