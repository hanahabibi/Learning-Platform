package controller;


import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.util.Duration;
import model.Course;

import java.util.Calendar;

import javafx.event.ActionEvent;
import model.Participant;
import service.CourseService;
import service.ParticipantService;


import java.io.*;

public class AddCourseController {
    public int index;
    public MainWindowController mainWindowController;
    public CourseService courseService;
    public ParticipantService patricipantService;
    public ObservableList choiceBoxSemOrVorOrProList = FXCollections.observableArrayList("Vorlesung", "Seminar", "Projektgruppe");
    public ObservableList choiceBoxSemOrVorList = FXCollections.observableArrayList("Projektgruppe");
    public ObservableList choiceBoxSemesterList = FXCollections.observableArrayList();
    @FXML
    public AnchorPane tab;
    @FXML
    public Button chooseCSV;
    @FXML
    public Button addCourse;
    @FXML
    public TextField courseName;
    @FXML
    public ChoiceBox choiceBoxSemOrVor;
    @FXML
    public ChoiceBox choiceBoxSemester;
    @FXML
    public ListView showImportedCourses;
    @FXML
    public Button fertigButton;
    @FXML
    public Label errorOutPut;
    @FXML
    public ListView addedCourses;

    public BufferedReader br;
    public String line = "";


    public AddCourseController() {

        courseService = new CourseService();
        this.patricipantService = new ParticipantService();
    }

    @FXML
    public void initialize() throws InterruptedException, IOException {
        if (mainWindowController.loggedInUser.getIsstudent() == 0) {
            choiceBoxSemOrVor.setValue("Vorlesung");
            choiceBoxSemOrVor.setItems(choiceBoxSemOrVorOrProList);

            choiceBoxSemester.setValue(currentSemesterToString(determineCurrentSemester()));
            choiceBoxSemester.setItems(followingSemester(determineCurrentSemester()));
        } else {
            choiceBoxSemOrVor.setValue("Projektgruppe");
            choiceBoxSemOrVor.setItems(choiceBoxSemOrVorList);

            choiceBoxSemester.setValue(currentSemesterToString(determineCurrentSemester()));
            choiceBoxSemester.setItems(followingSemester(determineCurrentSemester()));
        }
        addCourse.setOnAction((EventHandler<ActionEvent>) actionEvent -> {
            String name = courseName.getText();
            String semester = (String) choiceBoxSemester.getValue();
            String type = (String) choiceBoxSemOrVor.getValue();


            Course newCourse = new Course(name, semester, type);
            newCourse.setUserkey(mainWindowController.loggedInUser.getUserkey());

            try {
                boolean courseAlreadyExist = false;
                courseService.getCourseByName(name);
                if (!courseService.getCourseList().isEmpty()) {
                    for (Course a : courseService.getCourseList()) {
                        if (a.equals(newCourse)) {
                            courseAlreadyExist = true;
                            break;
                        }
                    }
                }

                if (!courseAlreadyExist) {

                    courseService.addCourse(newCourse);
                    addedCourses.getItems().add(newCourse);
                    patricipantService.addNewParticipant(new Participant(mainWindowController.getLoggedInUser().getUserkey(), courseService.getCurrentCourse().getCoursekey(), 0));
                } else {
                    errorOutPut.setText("Kurs mit selbem Namen exisitiert bereits");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            PauseTransition transition = new PauseTransition(Duration.seconds(3));
            transition.setOnFinished(f -> errorOutPut.setText(""));
            transition.play();
        });

        chooseCSV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                FileChooser fileChooser = new FileChooser();
                try {
                    //Set extension filter
                    FileChooser.ExtensionFilter extFiltercsv = new FileChooser.ExtensionFilter("csv files (*.csv)", "*.csv");
                    FileChooser.ExtensionFilter extFilterCSV = new FileChooser.ExtensionFilter("CSV files (*.CSV)", "*.CSV");

                    fileChooser.getExtensionFilters().addAll(extFilterCSV, extFiltercsv);
                    //Show open file dialog
                    File file = fileChooser.showOpenDialog(null);


                    String line = "";
                    String splitBy = ";";
                    ObservableList<Course> addCourse = FXCollections.observableArrayList();
                    ObservableList<Course> notAddedCourses = FXCollections.observableArrayList();
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Dialog");
                    alert.setHeaderText("Following Courses already exist and were therfore not added");
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    br = new BufferedReader(new FileReader(file));
                    line = br.readLine();
                    while ((line = br.readLine()) != null)   //returns a Boolean value
                    {
                        String[] course = line.split(splitBy); // use comma as separator
                        String name = course[0];
                        String semester = course[2];
                        String type = course[1];
                        semester = sortInToSemester(semester); // formatiere um
                        //zu erstellender Kurs mit richtigem  userkey
                        Course newCourse = new Course(name, semester, type);
                        newCourse.setUserkey(mainWindowController.loggedInUser.getUserkey());
                        courseService.getCourseByName(name);

                        boolean courseAlreadyExist = false;
                        courseService.getCourseByName(name);
                        if (!courseService.getCourseList().isEmpty()) {
                            for (Course a : courseService.getCourseList()) {
                                if (a.equals(newCourse)) {
                                    courseAlreadyExist = true;
                                    break;
                                }
                            }
                        }

                        //prüfe ob Kurs bereits existiert Anmerkung: Kurs ist nur dann gleich, wenn name,semester und typ den gleichen String haben


                        if (!courseAlreadyExist) {
                            courseService.addCourse(newCourse);
                            addCourse.add(newCourse);
                            patricipantService.addNewParticipant(new Participant(mainWindowController.getLoggedInUser().getUserkey(), courseService.getCurrentCourse().getCoursekey(), 0));
                        } else {
                            notAddedCourses.add(newCourse);
                        }
                    }

                    addedCourses.getItems().addAll(addCourse);
                    if (notAddedCourses.size() > 0) {
                        alert.setContentText(notAddedCourses.toString());
                        alert.showAndWait();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


        });

        fertigButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                mainWindowController.tabMenu.getSelectionModel().select(1);
                mainWindowController.tabMenu.getTabs().remove(index);

            }

        });
    }

    public String currentSemesterToString(int[] currentSemesterArray) {
        String currentSemester;
        if (currentSemesterArray.length == 2) {
            currentSemester = "WS" + " " + currentSemesterArray[0] + "/" + currentSemesterArray[1];
        } else {
            currentSemester = "SS" + " " + currentSemesterArray[0];
        }
        return currentSemester;
    }

    public ObservableList<String> followingSemester(int[] currentSemesterArray) {
        ObservableList<String> allSemesterChoices = FXCollections.observableArrayList();
        boolean SSOrWS;
        if (currentSemesterArray.length == 2) {
            SSOrWS = true;
        } else SSOrWS = false;

        for (int i = 0; i <= 3; i++) {

            if (SSOrWS) {
                allSemesterChoices.add("WS " + (currentSemesterArray[0] + i) + "/" + (currentSemesterArray[0] + i + 1));
                allSemesterChoices.add("SS " + (currentSemesterArray[0] + i));
            } else {
                allSemesterChoices.add("SS " + (currentSemesterArray[0] + i));
                allSemesterChoices.add("WS " + (currentSemesterArray[0] + i) + "/" + (currentSemesterArray[0] + i + 1));
            }

        }
        return allSemesterChoices;

    }

    public String sortInToSemester(String semester) {
        String semesterResult = "";
        String[] temp = semester.split(" ");
        temp[0] = temp[0].toUpperCase();
        CharSequence ws = "WISE";
        CharSequence ss = "SOSE";
        System.out.println(semester);
        System.out.println(temp[0]);
        System.out.println(temp[1]);
        if (temp[0].contains(ws)) {
            if (temp[1].length() == 5) {
                String firstYear = temp[1].substring(0, 2);
                String secondYear = temp[1].substring(3);
                semesterResult = "WS" + " " + firstYear + "/" + secondYear;
                System.out.println(semesterResult);
            }
            if (temp[1].length() == 9) {
                String firstYear = temp[1].substring(2, 4);
                String secondYear = temp[1].substring(7);
                semesterResult = "WS" + " " + firstYear + "/" + secondYear;
                System.out.println(semesterResult);
            }
        }
        if (temp[0].contains(ss)) {
            System.out.println(temp[1].length());
            if (temp[1].length() == 4) {
                String firstYear = temp[1].substring(2);
                semesterResult = "SS" + " " + firstYear;
                System.out.println(semesterResult);
            }
        }
        System.out.println(semesterResult);
        return semesterResult;

    }

    public int[] determineCurrentSemester() {
        Calendar CurrentDateTemp = Calendar.getInstance();

        Calendar tempEndSS = Calendar.getInstance();
        Calendar tempStartSS = Calendar.getInstance();
        Calendar tempStartWS = Calendar.getInstance();
        Calendar tempEndWS = Calendar.getInstance();

        for (int i = 2020; i < 2030; i++) {
            //Sommersemester
            tempEndSS.set(i, 9, 30, 23, 59);
            tempStartSS.set(i, 4, 1, 0, 0);
            if (CurrentDateTemp.after(tempStartSS) && CurrentDateTemp.before(tempEndSS)) {
                String year = String.valueOf(i);
                year = year.substring(1);
                int yearInt = Integer.parseInt(year);
                int[] currentSemester = {yearInt};
                return currentSemester;
            }

            //wenn man noch im ersten jahr des wintersemesters ist
            tempStartWS.set(i, 10, 1, 0, 0);
            tempEndWS.set(i + 1, 3, 31, 23, 59);
            if (CurrentDateTemp.after(tempStartSS) && CurrentDateTemp.before(tempEndSS)) {
                String yearFirst = String.valueOf(i);
                String yearSecond = String.valueOf(i + 1);
                yearFirst = yearFirst.substring(1);
                yearSecond = yearSecond.substring(1);
                int yearFirstInt = Integer.parseInt(yearFirst);
                int yearSecondInt = Integer.parseInt(yearSecond);
                int[] currentSemester = {yearFirstInt, yearSecondInt};
                return currentSemester;
            }

            //wenn man im zweiten jahr des wintersemester ist
            tempStartWS.set(i - 1, 10, 1, 0, 0);
            tempEndWS.set(i, 3, 31, 23, 59);
            if (CurrentDateTemp.after(tempStartSS) && CurrentDateTemp.before(tempEndSS)) {
                String yearFirst = String.valueOf(i - 1);
                String yearSecond = String.valueOf(i);
                yearFirst = yearFirst.substring(1);
                yearSecond = yearSecond.substring(1);
                int yearFirstInt = Integer.parseInt(yearFirst);
                int yearSecondInt = Integer.parseInt(yearSecond);
                int[] currentSemester = {yearFirstInt, yearSecondInt};
                return currentSemester;
            }
        }
        int[] worst = new int[1];
        worst[0] = 0;
        return worst;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }
}