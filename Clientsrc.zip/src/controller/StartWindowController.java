package controller;

import exception.*;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.User;
import service.LecturerService;
import service.StudentService;
import service.UserService;

import java.io.IOException;

public class StartWindowController {

    private final Stage stage;
    public User loggedUser;


    //für Http Anfragen
    public UserService userService;
    public StudentService studentService;
    public LecturerService lecturerService;


    @FXML
    public PasswordField UserInputLoginPassword;
    @FXML
    public TextField UserInputLogin;
    @FXML
    public Button LoginButton;
    @FXML
    public Button RegisterButton;
    @FXML
    public Label ClientOutputError;
    @FXML
    public Button proceedAnywayButton;


    @FXML
    public void initialize() throws IOException {
        userService = new UserService();
        studentService = new StudentService();
        lecturerService = new LecturerService();
        CreateProfileController createProfileController = new CreateProfileController(stage, null);

        //@Author Kuri
        LoginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                loginUserWithAuth();
            }
        });

        //@Author Kuri
        RegisterButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CreateProfile.fxml"));
                    loader.setController(createProfileController);
                    Parent root = loader.load();
                    stage.setScene(new Scene(root));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        UserInputLogin.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode().equals(KeyCode.ENTER)) {
                    if (!UserInputLogin.getText().isEmpty()) {
                        loginUserWithAuth();
                    }
                    UserInputLoginPassword.requestFocus();
                }
            }
        });

        UserInputLoginPassword.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode().equals(KeyCode.ENTER)) {
                    loginUserWithAuth();
                }
            }
        });

        proceedAnywayButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                loginUserWithoutAuth();
            }
        });
    }

    //@Author Kuri
    //prüfe eingabe und melde Nutzer an, bei erfolgreichem Login setze loggedUser.
    public void loginUserWithoutAuth() {

        String login = UserInputLogin.getText();
        String LoginPassword = UserInputLoginPassword.getText();
        try {
            //Eingabe ist keine Email
            if (!login.contains("@")) {
                //Prüfe korrekte Eingabe Format der Matrikellnummer
                if (login.length() == 7 && login.matches("(\\d)+")) {
                    //prüfe ob Student mit Matrikelnummer existiert, sonst werfe Exception
                    studentService.getStudentByID(Integer.parseInt(login));
                    //existiert Student, so frage Datenbank nach anderen Daten des Studenten ab
                    if (studentService.getCurrentStudent().getSubject() != null) {
                        userService.getUser(studentService.getCurrentStudent().getUserkey());
                        //Ist eingegebenes Passowrt gleich dem aus der Datenbank?
                        if (userService.getCurrentUser().getPassword().equals(LoginPassword)) {
                            //wenn authorisiert, ergänze dem Studenten die Information aus User Tabele
                            studentService.getCurrentStudent().join(userService.getCurrentUser());
                            loggedUser = studentService.getCurrentStudent();
                        } else {
                            throw new WrongPasswordException();
                        }
                    } else {
                        throw new NoUserExisting();
                    }
                } else {
                    throw new LoginNotFoundException();
                }
            }
            //Eingabe ist Email
            else {
                //passt Email dem Format?
                if (login.contains("@")) {
                    userService.getUserByEmail(login);
                    if (userService.getCurrentUser().getEmail() != null) {
                        //Ist eingegebenes Passowrt gleich dem aus der Datenbank?
                        if (userService.getCurrentUser().getPassword().equals(LoginPassword)) {
                            //wenn authorisiert, und User ist Student, dann ergänze dem Studenten informationen
                            if (userService.getCurrentUser().getIsstudent() == 1) {
                                studentService.getStudentByUserKey(userService.getCurrentUser().getUserkey());
                                loggedUser = studentService.getCurrentStudent();
                                loggedUser.join(userService.getCurrentUser());
                            }
                            // Nutzer ist kein Student -> Nutzer ist Lehrender
                            else {
                                lecturerService.getLecturerByUserKey(userService.getCurrentUser().getUserkey());
                                loggedUser = lecturerService.getCurrentLecturer();
                                loggedUser.join(userService.getCurrentUser());
                            }
                        } else {
                            throw new WrongPasswordException();
                        }
                    } else {
                        throw new NoUserExisting();
                    }

                } else {
                    throw new LoginNotFoundException();
                }
            }

            loadScreenWithUser();


        } catch (WrongPasswordException | StudentNotFoundException | NoUserExisting | LecturerNotFoundException | LoginNotFoundException e) {
            ClientOutputError.setText(e.getMessage());
            e.printStackTrace();
        } catch (IOException | IllegalArgumentException e) {
            e.printStackTrace();
            ClientOutputError.setText("Eingabe Fehler");
        } catch (Exception e) {
            e.printStackTrace();
        }
        PauseTransition transition = new PauseTransition(Duration.seconds(3));
        transition.setOnFinished(f -> ClientOutputError.setText(""));
        transition.play();
    }

    public void loginUserWithAuth() {

        String login = UserInputLogin.getText();
        String LoginPassword = UserInputLoginPassword.getText();
        try {
            //Eingabe ist keine Email
            if (!login.contains("@")) {
                //Prüfe korrekte Eingabe Format der Matrikellnummer
                if (login.length() == 7 && login.matches("(\\d)+")) {
                    //prüfe ob Student mit Matrikelnummer existiert, sonst werfe Exception
                    studentService.getStudentByID(Integer.parseInt(login));
                    //existiert Student, so frage Datenbank nach anderen Daten des Studenten ab
                    if (studentService.getCurrentStudent().getSubject() != null) {
                        userService.getUser(studentService.getCurrentStudent().getUserkey());
                        //Ist eingegebenes Passowrt gleich dem aus der Datenbank?
                        if (userService.getCurrentUser().getPassword().equals(LoginPassword)) {
                            //wenn authorisiert, ergänze dem Studenten die Information aus User Tabele
                            studentService.getCurrentStudent().join(userService.getCurrentUser());
                            loggedUser = studentService.getCurrentStudent();
                        } else {
                            throw new WrongPasswordException();
                        }
                    } else {
                        throw new NoUserExisting();
                    }
                } else {
                    throw new LoginNotFoundException();
                }
            }
            //Eingabe ist Email
            else {
                //passt Email dem Format?
                if (login.contains("@")) {
                    userService.getUserByEmail(login);
                    if (userService.getCurrentUser().getEmail() != null) {
                        //Ist eingegebenes Passowrt gleich dem aus der Datenbank?
                        if (userService.getCurrentUser().getPassword().equals(LoginPassword)) {
                            //wenn authorisiert, und User ist Student, dann ergänze dem Studenten informationen
                            if (userService.getCurrentUser().getIsstudent() == 1) {
                                studentService.getStudentByUserKey(userService.getCurrentUser().getUserkey());
                                loggedUser = studentService.getCurrentStudent();
                                loggedUser.join(userService.getCurrentUser());
                            }
                            // Nutzer ist kein Student -> Nutzer ist Lehrender
                            else {
                                lecturerService.getLecturerByUserKey(userService.getCurrentUser().getUserkey());
                                loggedUser = lecturerService.getCurrentLecturer();
                                loggedUser.join(userService.getCurrentUser());
                            }
                        } else {
                            throw new WrongPasswordException();
                        }
                    } else {
                        throw new NoUserExisting();
                    }

                } else {
                    throw new LoginNotFoundException();
                }
            }

            loadAuthWindow(loggedUser.getEmail());

        } catch (WrongPasswordException | StudentNotFoundException | NoUserExisting | LecturerNotFoundException | LoginNotFoundException e) {
            ClientOutputError.setText(e.getMessage());
            e.printStackTrace();
        } catch (IOException | IllegalArgumentException e) {
            e.printStackTrace();
            ClientOutputError.setText("Eingabe Fehler");
        } catch (Exception e) {
            e.printStackTrace();
        }
        PauseTransition transition = new PauseTransition(Duration.seconds(3));
        transition.setOnFinished(f -> ClientOutputError.setText(""));
        transition.play();
    }

    private void loadAuthWindow(String email) throws IOException {
        Stage primaryStage = new Stage();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/AuthWindow.fxml"));
        loader.setController(new AuthWindowController(this, primaryStage));
        Parent root = loader.load();
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public StartWindowController(Stage stage) {
        this.stage = stage;
    }

    public void loadScreenWithUser() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/MainWindow.fxml"));
        loader.setController(new MainWindowController(loggedUser, stage));
        Parent root = loader.load();
        stage.setScene(new Scene(root));
    }

}
