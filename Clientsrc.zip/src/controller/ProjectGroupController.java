package controller;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import model.*;
import service.CourseService;
import service.LearningMaterialService;
import service.ParticipantService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;


public class ProjectGroupController {
    User user;
    Course course;

    @FXML
    private Button addUser;
    @FXML
    private Button addMaterial;
    @FXML
    private Label title;
    @FXML
    private Button groupchat;
    @FXML
    private ListView groupMaterialList;


    ParticipantService participantService;
    CourseService courseService;
    LearningMaterialService learningMaterialService;
    byte[] blobfile;
    ObservableList<LearningMaterial> materialList = FXCollections.observableArrayList();

    private MainWindowController mainWindowController;
    int index;

    public ProjectGroupController(User user, Course course, int index) {
        this.user = user;
        this.course = course;
        participantService = new ParticipantService();
        courseService = new CourseService();
        learningMaterialService = new LearningMaterialService();
        this.index = index;
    }


    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    @FXML
    public void initialize() throws IOException {

        courseService.setCurrentCourse(course);
        participantService.getParticipantsOfCourse(course.getCoursekey());
        title.setText(course.getName());

        if (participantService.getCurrentParticipantList() != null) {
            if (!isParticipant(participantService.getCurrentParticipantList(), user.getUserkey())) {
                groupchat.setVisible(false);
                groupMaterialList.setVisible(false);
                addMaterial.setVisible(false);
                addUser.setVisible(false);


            } else if (isParticipant(participantService.getCurrentParticipantList(), user.getUserkey())) {
                groupMaterialList.setVisible(true);
                learningMaterialService.getMaterialbyCourseKey(course.getCoursekey());
                materialList.setAll(learningMaterialService.getListOfMaterial());
                getGroupMaterialList().setItems(materialList);

                if (user instanceof Student) {
                    addUser.setVisible(false);
                }
            }
            if (user instanceof Lecturer) {
                groupchat.setVisible(false);
            }
        }
        if (user instanceof Student) {
            participantService.getParticipantsOfCourse(course.getCoursekey());
            for (Participant participant : participantService.getCurrentParticipantList()) {
                if (participant.getUserkey() == user.getUserkey()) {
                    addUser.setVisible(false);
                    break;
                }
            }
        }


        addMaterial.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                FileChooser fileChooser = new FileChooser();
                try {
                    //Set extension filter
                    FileChooser.ExtensionFilter extFilterPDF = new FileChooser.ExtensionFilter("PDF files (*.PDF)", "*.PDF");
                    FileChooser.ExtensionFilter extFilterpdf = new FileChooser.ExtensionFilter("pdf files (*.pdf)", "*.pdf");
                    FileChooser.ExtensionFilter extFilterdocx = new FileChooser.ExtensionFilter("docx files (*.docx)", "*.docx");
                    FileChooser.ExtensionFilter extFilterdoc = new FileChooser.ExtensionFilter("doc files (*.doc)", "*.doc");
                    fileChooser.getExtensionFilters().addAll(extFilterPDF, extFilterpdf, extFilterdocx, extFilterdoc);
                    File file = fileChooser.showOpenDialog(null);
                    if (file != null) {
                        blobfile = Files.readAllBytes(file.toPath());
                        LearningMaterial newlearningmaterial = new LearningMaterial(file.getName(), course.getCoursekey(), blobfile);
                        learningMaterialService.addMaterial(newlearningmaterial);
                        initialize();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


        addUser.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/fxml/SearchStudent.fxml"));
                    SearchStudentController searchStudentController = new SearchStudentController(user, course, mainWindowController.tabMenu.getTabs().size() - 1);
                    searchStudentController.setMainWindowController(mainWindowController);
                    loader.setController(searchStudentController);
                    AnchorPane anchorPane1 = loader.load();
                    mainWindowController.tabMenu.getTabs().get(mainWindowController.tabMenu.getTabs().size() - 1).setContent(anchorPane1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        groupMaterialList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {

                        DirectoryChooser directoryChooser = new DirectoryChooser();
                        File selectedDircotry = directoryChooser.showDialog(null);
                        writeResponseBodyToDisk(learningMaterialService.downloadMaterial(((LearningMaterial) groupMaterialList.getSelectionModel().getSelectedItem()).getLearningmaterialkey()), selectedDircotry, ((LearningMaterial) groupMaterialList.getSelectionModel().getSelectedItem()).getName());

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        groupchat.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

            }
        });
    }

    private void writeResponseBodyToDisk(Byte[] downloadMaterial, File file, String name) {
        try {
            File fileToSave = new File(file + File.separator + name);
            FileOutputStream tmp = new FileOutputStream(fileToSave);

            byte[] bytes = new byte[downloadMaterial.length];
            for (int i = 0; i < downloadMaterial.length; i++) {
                bytes[i] = downloadMaterial[i];
            }


            tmp.write(bytes);
            tmp.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isParticipant(List<Participant> participantsl, int userkey) {
        for (Participant participant : participantService.getCurrentParticipantList()) {
            if (participant.getUserkey() == user.getUserkey()) {
                return true;
            }
        }
        return false;
    }

    public ListView getGroupMaterialList() {
        return groupMaterialList;
    }
}

