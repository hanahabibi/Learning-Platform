package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import service.QuizService;
import service.UserService;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

public class AddQuizXMLController {

    private final User user;
    private final Course course;
    public byte[] XMLFile;

    QuizService quizService;
    Quiz quiz;

    @FXML
    private Button ButtonchooseXML, ButtonSaveXMLQuiz;
    @FXML
    private TextArea TextAreaQuizPreview;

    private MainWindowController mainWindowController;

    public AddQuizXMLController(User user, Course course) {
        this.user = user;
        this.course = course;
        quiz = new Quiz();
        quizService = new QuizService();
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public void initialize() {

        ButtonchooseXML.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();
                try {
                    //Set extension filter
                    FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("XML files (*.XML)", "*.XML");
                    FileChooser.ExtensionFilter extFilterjpg = new FileChooser.ExtensionFilter("xml files (*.xml)", "*.xml");
                    fileChooser.getExtensionFilters().addAll(extFilterJPG, extFilterjpg);
                    //Show open file dialog
                    File file = fileChooser.showOpenDialog(null);

                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document doc = builder.parse(file);

                    NodeList Questions = doc.getElementsByTagName("Frage");
                    NodeList AnswerA = doc.getElementsByTagName("AntwortA");
                    NodeList AnswerB = doc.getElementsByTagName("AntwortB");
                    NodeList AnswerC = doc.getElementsByTagName("AntwortC");
                    NodeList AnswerD = doc.getElementsByTagName("AntwortD");
                    NodeList CorrectAnswer = doc.getElementsByTagName("KorrekteAntwort");

                    String result = "";

                    for (int i = 0; i < Questions.getLength(); i++) {
                        result = result + "Frage: " + (i + 1) + "\n" + Questions.item(i).getTextContent() + "\n" + "Antwort A: " + AnswerA.item(i).getTextContent() + "\n" + "Antwort B: " + AnswerB.item(i).getTextContent() + "\n" + "Antwort C: " + AnswerC.item(i).getTextContent() + "\n" + "Antwort D: " + AnswerD.item(i).getTextContent() + "\n" + "Korrekte Antwort: " + CorrectAnswer.item(i).getTextContent() + "\n" + "\n";
                    }

                    TextAreaQuizPreview.setText(result);

                    DOMSource source = new DOMSource(doc);
                    Result quizResult = new StreamResult(file);

                    TransformerFactory transformerFactory = TransformerFactory.newInstance();
                    Transformer transformer = transformerFactory.newTransformer();
                    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
                    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                    transformer.transform(source, quizResult);

                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    StreamResult streamResult = new StreamResult(bos);
                    transformer.transform(source, streamResult);

                    byte[] array = Files.readAllBytes(Path.of(file.getPath()));

                    quiz.setCoursekey(course.getCoursekey());
                    quiz.setQuiz(array);
                    quiz.setType("quiz");
                    quizService.addQuiz(quiz);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        ButtonSaveXMLQuiz.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openCourseAfterQuiz(user, course);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
