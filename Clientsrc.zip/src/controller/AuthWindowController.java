package controller;

import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;
import service.MailService;

import java.io.IOException;

public class AuthWindowController {
    StartWindowController startWindowController;
    MailService mailService;
    String code;
    Stage stage;

    public AuthWindowController(StartWindowController startWindowController, Stage stage) {
        this.startWindowController = startWindowController;
        this.mailService = new MailService();
        this.stage = stage;
    }

    @FXML
    Button confirmButton;
    @FXML
    Button resendButton;
    @FXML
    Button abortButton;
    @FXML
    TextField inputTextField;
    @FXML
    Label errorOutPutLabel;


    @FXML
    public void initialize() throws IOException {
        mailService.generateCode(startWindowController.loggedUser.getEmail());
        code = mailService.getCode();

        confirmButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (inputTextField.getText().equals(code)) {
                    try {
                        startWindowController.loadScreenWithUser();
                        stage.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    errorOutPutLabel.setText("Der eingegebene Code ist Falsch");
                }
                PauseTransition transition = new PauseTransition(Duration.seconds(3));
                transition.setOnFinished(f -> errorOutPutLabel.setText(""));
                transition.play();
            }
        });

        resendButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mailService.generateCode(startWindowController.loggedUser.getEmail());
                    code = mailService.getCode();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        abortButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();
            }
        });
    }


}
