package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import model.Event;
import model.Reminder;
import service.CourseService;
import service.EventService;
import service.ReminderService;

import java.io.IOException;

public class EventController {

    @FXML
    Label courseNameLabel;
    @FXML
    Label eventName;
    @FXML
    Label eventDate;
    @FXML
    Label eventTime;
    @FXML
    Button addReminderButton;
    @FXML
    Button deleteEventButton;
    @FXML
    ListView reminderList;

    public Event event;
    public MainWindowController mainWindowController;
    public CourseService courseService;
    public EventService eventService;
    public ReminderService reminderService;
    public int index;
    public int indexFrom;
    public ObservableList<Reminder> reminder = FXCollections.observableArrayList();


    public EventController(MainWindowController mainWindowController, Event event, int indexFrom) {
        this.mainWindowController = mainWindowController;
        this.event = event;
        this.courseService = new CourseService();
        this.eventService = new EventService();
        this.reminderService = new ReminderService();
        this.indexFrom = indexFrom;
    }

    public void initialize() throws IOException {
        deleteEventButton.setVisible(false);
        fillReminderList();
        eventName.setText(event.getName());
        courseService.getCourseByID(event.getCoursekey());
        courseNameLabel.setText(courseService.getCurrentCourse().getName());
        eventDate.setText(event.dateToString());
        eventTime.setText(event.timeString());

        try {

            deleteEventButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    deleteEvent();
                    mainWindowController.tabMenu.getSelectionModel().select(indexFrom);
                    mainWindowController.tabMenu.getTabs().remove(index);
                }
            });

            addReminderButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        mainWindowController.openAddReminderTab(event.eventID, index);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

            reminderList.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        if (mouseEvent.getClickCount() == 2) {
                            Reminder tmp = (Reminder) reminderList.getSelectionModel().getSelectedItem();
                            mainWindowController.openReminderTab(tmp);

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillReminderList();

    }

    public void fillReminderList() throws IOException {
        reminderService.getAllReminderForEvent(event.getEventID());
        reminder.setAll(reminderService.getReminderList());

        reminderList.setItems(reminder);

    }


    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void deleteEvent() {

    }
}
