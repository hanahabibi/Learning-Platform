package controller;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import model.User;

import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;

public class ChatPersonController {
    @FXML
    ImageView chatPicImageView;

    @FXML
    Label chatNameLabel;
    User chatUser;

    public ChatPersonController(User user) {
        chatUser = user;
    }

    @FXML
    public void initialize() throws IOException {
        chatNameLabel.setText(chatUser.getFirstname() + " " + chatUser.getLastname());
        ByteArrayInputStream bis = new ByteArrayInputStream(chatUser.getProfilepicture());
        chatPicImageView.setImage(SwingFXUtils.toFXImage(ImageIO.read(bis), null));
    }

    public User getChatUser() {
        return chatUser;
    }

    public void setChatUser(User chatUser) {
        this.chatUser = chatUser;
    }


    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ChatPersonController) {
            return ((ChatPersonController) obj).chatUser.getUserkey() == this.chatUser.getUserkey();
        }
        return false;
    }
}
