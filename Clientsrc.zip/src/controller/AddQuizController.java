package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Course;
import model.Questions;
import model.Quiz;
import model.User;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import service.QuizService;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class AddQuizController {

    QuizService quizService;

    Quiz quiz;
    Course course;
    User user;
    public MainWindowController mainWindowController;
    int questionIndex = 0;
    int questionIndexListView = 1;

    @FXML
    public ListView<String> ListViewQuestions;
    @FXML
    public TextArea TextAreaAnswerA, TextAreaAnswerB, TextAreaAnswerC, TextAreaAnswerD;
    @FXML
    public Button ButtonNextQuizQuestion, ButtonLastQuizQuestion, ButtonSaveQuiz;
    @FXML
    public Label LabelQuestion;
    @FXML
    public TextArea TextAreaWriteQuestion;
    @FXML
    public CheckBox CheckBoxAnswerA, CheckBoxAnswerB, CheckBoxAnswerC, CheckBoxAnswerD;

    public AddQuizController(User user, Course course) {
        this.user = user;
        this.course = course;
        quiz = new Quiz();
        quizService = new QuizService();
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public void initialize() {

        ListViewQuestions.getItems().add("Frage: " + questionIndexListView);
        LabelQuestion.setText("Frage: " + questionIndexListView);

        ArrayList<Questions> questions = new ArrayList<Questions>();

        ButtonNextQuizQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (questions.size() <= questionIndex) {
                    Questions temp = new Questions(String.valueOf(questionIndex), "", "", "", "", "", "", "");
                    questions.add(temp);

                    System.out.println("Frage: " + questions.size());

                    questions.get(questionIndex).setFrage(TextAreaWriteQuestion.getText());
                    questions.get(questionIndex).setAntwortA(TextAreaAnswerA.getText());
                    questions.get(questionIndex).setAntwortB(TextAreaAnswerB.getText());
                    questions.get(questionIndex).setAntwortC(TextAreaAnswerC.getText());
                    questions.get(questionIndex).setAntwortD(TextAreaAnswerD.getText());

                    String correctAnswer = "";

                    if (CheckBoxAnswerA.isSelected()) {
                        correctAnswer = "A";
                    }
                    if (CheckBoxAnswerB.isSelected()) {
                        correctAnswer = "B";
                    }
                    if (CheckBoxAnswerC.isSelected()) {
                        correctAnswer = "C";
                    }
                    if (CheckBoxAnswerD.isSelected()) {
                        correctAnswer = "D";
                    }

                    System.out.println("Gespeicherte Antwort: " + correctAnswer);

                    questions.get(questionIndex).setRichtigeAntwort(correctAnswer);

                    questionIndex = questionIndex + 1;
                    questionIndexListView = questionIndexListView + 1;
                    ListViewQuestions.getItems().add("Frage: " + questionIndexListView);
                    LabelQuestion.setText("Frage: " + questionIndexListView);

                    TextAreaWriteQuestion.clear();
                    TextAreaAnswerA.clear();
                    TextAreaAnswerB.clear();
                    TextAreaAnswerC.clear();
                    TextAreaAnswerD.clear();
                    CheckBoxAnswerA.setSelected(false);
                    CheckBoxAnswerB.setSelected(false);
                    CheckBoxAnswerC.setSelected(false);
                    CheckBoxAnswerD.setSelected(false);

                } else {
                    questionIndex = questionIndex + 1;
                    questionIndexListView = questionIndexListView + 1;

                    TextAreaWriteQuestion.setText(questions.get(questionIndex).getFrage());
                    CheckBoxAnswerA.setText(questions.get(questionIndex).getAntwortA());
                    CheckBoxAnswerB.setText(questions.get(questionIndex).getAntwortB());
                    CheckBoxAnswerC.setText(questions.get(questionIndex).getAntwortB());
                    CheckBoxAnswerD.setText(questions.get(questionIndex).getAntwortD());

                    //questionIndex = questionIndex + 1;
                    //questionIndexListView = questionIndexListView + 1;
                    LabelQuestion.setText("Frage: " + questionIndexListView);

                    String richtigeantwort = questions.get(questionIndex).getRichtigeAntwort();

                    if (!richtigeantwort.equals("")) {
                        if (richtigeantwort.equals("A")) {
                            CheckBoxAnswerA.setSelected(true);
                            System.out.println("Antwort A wurde ausgelesen");
                        }
                        if (richtigeantwort.equals("B")) {
                            CheckBoxAnswerB.setSelected(true);
                            System.out.println("Antwort B wurde ausgelesen");
                        }
                        if (richtigeantwort.equals("C")) {
                            CheckBoxAnswerC.setSelected(true);
                            System.out.println("Antwort C wurde ausgelesen");
                        }
                        if (richtigeantwort.equals("D")) {
                            CheckBoxAnswerD.setSelected(true);
                            System.out.println("Antwort D wurde ausgelesen");
                        }
                    }
                }
            }
        });

        ButtonLastQuizQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (questionIndexListView >= 1) {
                    questionIndex = questionIndex - 1;
                    questionIndexListView = questionIndexListView - 1;
                    LabelQuestion.setText("Frage: " + questionIndexListView);

                    //LabelQuestion.setText(questions.get(questionIndex).getFragenZahl());
                    TextAreaWriteQuestion.setText(questions.get(questionIndex).getFrage());
                    TextAreaAnswerA.setText(questions.get(questionIndex).getAntwortA());
                    TextAreaAnswerB.setText(questions.get(questionIndex).getAntwortB());
                    TextAreaAnswerC.setText(questions.get(questionIndex).getAntwortC());
                    TextAreaAnswerD.setText(questions.get(questionIndex).getAntwortD());

                    String richtigeantwort = questions.get(questionIndex).getRichtigeAntwort();

                    System.out.println(richtigeantwort);

                    if (!richtigeantwort.equals("")) {
                        if (richtigeantwort.equals("A")) {
                            CheckBoxAnswerA.setSelected(true);
                            System.out.println("Antwort A wurde ausgelesen");
                        }
                        if (richtigeantwort.equals("B")) {
                            CheckBoxAnswerB.setSelected(true);
                            System.out.println("Antwort B wurde ausgelesen");
                        }
                        if (richtigeantwort.equals("C")) {
                            CheckBoxAnswerC.setSelected(true);
                            System.out.println("Antwort C wurde ausgelesen");
                        }
                        if (richtigeantwort.equals("D")) {
                            CheckBoxAnswerD.setSelected(true);
                            System.out.println("Antwort D wurde ausgelesen");
                        }
                    }
                }
            }
        });

        ButtonSaveQuiz.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                if (!TextAreaWriteQuestion.getText().equals("")) {
                    Questions temp = new Questions(String.valueOf(questionIndex), "", "", "", "", "", "", "");
                    questions.add(temp);

                    questions.get(questionIndex).setFrage(TextAreaWriteQuestion.getText());
                    questions.get(questionIndex).setAntwortA(TextAreaAnswerA.getText());
                    questions.get(questionIndex).setAntwortB(TextAreaAnswerB.getText());
                    questions.get(questionIndex).setAntwortC(TextAreaAnswerC.getText());
                    questions.get(questionIndex).setAntwortD(TextAreaAnswerD.getText());

                    String correctAnswer = "";

                    if (CheckBoxAnswerA.isSelected()) {
                        correctAnswer = "A";
                    }
                    if (CheckBoxAnswerB.isSelected()) {
                        correctAnswer = "B";
                    }
                    if (CheckBoxAnswerC.isSelected()) {
                        correctAnswer = "C";
                    }
                    if (CheckBoxAnswerD.isSelected()) {
                        correctAnswer = "D";
                    }
                    questions.get(questionIndex).setRichtigeAntwort(correctAnswer);
                }

                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newDefaultInstance();
                DocumentBuilder builder;

                try {
                    builder = dbFactory.newDocumentBuilder();
                    Document doc = builder.newDocument();

                    //value Beispiel: (1,0,0,0)-(2,0,0,0)-(2,0,0,0)/userkey@versuche+1-userkey@versuche+0

                    StringBuilder newQuizString = new StringBuilder();

                    Element root = doc.createElement("Quizfragen");

                    for (int i = 0; i < questions.size(); i++) {

                        Element fragenzeile = doc.createElement("Fragenzeile");
                        root.appendChild(fragenzeile);

                        Element fragenummer = doc.createElement("Fragennummer");
                        Text TextFragenummer = doc.createTextNode(String.valueOf((i + 1)));
                        fragenummer.appendChild(TextFragenummer);
                        fragenzeile.appendChild(fragenummer);

                        Element frage = doc.createElement("Frage");
                        Text TextFrage = doc.createTextNode(questions.get(i).getFrage());
                        frage.appendChild(TextFrage);
                        fragenzeile.appendChild(frage);

                        Element antwortA = doc.createElement("AntwortA");
                        Text TextAntwortA = doc.createTextNode(questions.get(i).getAntwortA());
                        antwortA.appendChild(TextAntwortA);
                        fragenzeile.appendChild(antwortA);

                        Element antwortB = doc.createElement("AntwortB");
                        Text TextAntwortB = doc.createTextNode(questions.get(i).getAntwortB());
                        antwortB.appendChild(TextAntwortB);
                        fragenzeile.appendChild(antwortB);

                        Element antwortC = doc.createElement("AntwortC");
                        Text TextAntwortC = doc.createTextNode(questions.get(i).getAntwortC());
                        antwortC.appendChild(TextAntwortC);
                        fragenzeile.appendChild(antwortC);

                        Element antwortD = doc.createElement("AntwortD");
                        Text TextAntwortD = doc.createTextNode(questions.get(i).getAntwortD());
                        antwortD.appendChild(TextAntwortD);
                        fragenzeile.appendChild(antwortD);

                        Element korrekteAntwort = doc.createElement("KorrekteAntwort");
                        Text TextKorrekteAntwort = doc.createTextNode(questions.get(i).getRichtigeAntwort());
                        korrekteAntwort.appendChild(TextKorrekteAntwort);
                        fragenzeile.appendChild(korrekteAntwort);


                    }


                    doc.appendChild(root);

                    String path = "Client/src/resources/Quiz/Quiz " + course.getName() + ".xml";
                    File file = new File(path);

                    DOMSource source = new DOMSource(doc);
                    Result result = new StreamResult(file);

                    TransformerFactory transformerFactory = TransformerFactory.newInstance();
                    Transformer transformer = transformerFactory.newTransformer();
                    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
                    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                    transformer.transform(source, result);
                    System.out.println("Daten gespeichert in: " + path);

                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    StreamResult streamResult = new StreamResult(bos);
                    transformer.transform(source, streamResult);
                    //byte []array=bos.toByteArray();

                    byte[] array = Files.readAllBytes(Path.of(path));

                    quiz.setCoursekey(course.getCoursekey());
                    quiz.setQuiz(array);
                    quiz.setType("quiz");
                    quiz.setWhoworkedonthatquiz("");
                    quizService.addQuiz(quiz);

                    mainWindowController.openCourseAfterQuiz(user, course);

                } catch (ParserConfigurationException | TransformerException | IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

   /* public byte[] readXml(String path){

        File file = new File(path);
        byte[] xmlFile = new byte[(int)file.length()];
        FileInputStream fileInputStream = null;

        try {
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(xmlFile);
            fileInputStream.close();
        } catch (Exception e) {
            System.err.println("File not found or unreadable.");
            e.printStackTrace();
        }

        return xmlFile;
    }*/
}
