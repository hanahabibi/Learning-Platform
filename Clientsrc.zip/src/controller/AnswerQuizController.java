package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.*;
import org.springframework.data.relational.core.sql.Values;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import service.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;


public class AnswerQuizController {


    @FXML
    public ListView<String> ListViewQuestions;
    @FXML
    public CheckBox CheckBoxAnswerA, CheckBoxAnswerB, CheckBoxAnswerC, CheckBoxAnswerD;
    @FXML
    public Button ButtonNextQuestion, ButtonLastQuestion, ButtonEndQuiz;
    @FXML
    public Label LabelQuestion;
    @FXML
    public TextArea TextAreaShowQuestion;

    QuizService quizService;
    Quiz quiz;
    byte[] downloadedQuiz;
    User user;
    int questionIndex = 0;
    private MainWindowController mainWindowController;

    public AnswerQuizController(User user, Quiz quiz) {
        this.user = user;
        this.quiz = quiz;
        quizService = new QuizService();
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }


    public void initialize() throws InterruptedException, IOException, ParserConfigurationException, SAXException {

        //String filename = "Client/src/resources/Quiz/Quiz " + course.getName() + ".xml";
        String directory = "./Quiz";
        File XMLquiz;
        if (!directoryExists(directory)) {
            new File(directory).mkdirs();
        }
        XMLquiz = new File("./Quiz/Quiz.xml");


        byte[] data = quiz.getQuiz();

        try (FileOutputStream stream = new FileOutputStream(XMLquiz)) {
            stream.write(data);
            stream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document doc = builder.parse(XMLquiz);

        NodeList QuestionNumber = doc.getElementsByTagName("Fragennummer");
        NodeList Questions = doc.getElementsByTagName("Frage");
        NodeList AnswerA = doc.getElementsByTagName("AntwortA");
        NodeList AnswerB = doc.getElementsByTagName("AntwortB");
        NodeList AnswerC = doc.getElementsByTagName("AntwortC");
        NodeList AnswerD = doc.getElementsByTagName("AntwortD");
        NodeList CorrectAnswer = doc.getElementsByTagName("KorrekteAntwort");

        ArrayList<Questions> questions = new ArrayList<Questions>();

        for (int i = 0; i < Questions.getLength(); i++) {
            ListViewQuestions.getItems().add("Frage: " + (i + 1));
            Questions temp = new Questions(QuestionNumber.item(i).getTextContent(), Questions.item(i).getTextContent(), AnswerA.item(i).getTextContent(), AnswerB.item(i).getTextContent(), AnswerC.item(i).getTextContent(), AnswerD.item(i).getTextContent(), CorrectAnswer.item(i).getTextContent(), "");
            questions.add(temp);
        }

        TextAreaShowQuestion.setText(questions.get(questionIndex).getFrage());
        CheckBoxAnswerA.setText(questions.get(questionIndex).getAntwortA());
        CheckBoxAnswerB.setText(questions.get(questionIndex).getAntwortB());
        CheckBoxAnswerC.setText(questions.get(questionIndex).getAntwortC());
        CheckBoxAnswerD.setText(questions.get(questionIndex).getAntwortD());
        LabelQuestion.setText("Frage: " + questions.get(questionIndex).getFragenZahl());

        ButtonNextQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                // Antwort setzten
                if (CheckBoxAnswerA.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("A");
                    System.out.println("Antwort A wurde gesetzt");
                    CheckBoxAnswerA.setSelected(false);
                }
                if (CheckBoxAnswerB.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("B");
                    System.out.println("Antwort B wurde gesetzt");
                    CheckBoxAnswerB.setSelected(false);
                }
                if (CheckBoxAnswerC.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("C");
                    System.out.println("Antwort C wurde gesetzt");
                    CheckBoxAnswerC.setSelected(false);
                }
                if (CheckBoxAnswerD.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("D");
                    System.out.println("Antwort D wurde gesetzt");
                    CheckBoxAnswerD.setSelected(false);
                }

                if (questionIndex <= Questions.getLength() - 1) {
                    questionIndex = questionIndex + 1;
                }
                String userantwort = questions.get(questionIndex).getUserAntwort();

                if (!userantwort.equals("")) {
                    if (userantwort.equals("A")) {
                        CheckBoxAnswerA.setSelected(true);
                        System.out.println("Antwort A wurde ausgelesen");
                    }
                    if (userantwort.equals("B")) {
                        CheckBoxAnswerB.setSelected(true);
                        System.out.println("Antwort B wurde ausgelesen");
                    }
                    if (userantwort.equals("C")) {
                        CheckBoxAnswerC.setSelected(true);
                        System.out.println("Antwort C wurde ausgelesen");
                    }
                    if (userantwort.equals("D")) {
                        CheckBoxAnswerD.setSelected(true);
                        System.out.println("Antwort D wurde ausgelesen");
                    }
                }

                // Gucken, ob die nächste Frage die letzte Frage ist
                if (questionIndex <= Questions.getLength() - 1) {
                    // Elemente aus dem Konstruktor setzten
                    TextAreaShowQuestion.setText(questions.get(questionIndex).getFrage());
                    CheckBoxAnswerA.setText(questions.get(questionIndex).getAntwortA());
                    CheckBoxAnswerB.setText(questions.get(questionIndex).getAntwortB());
                    CheckBoxAnswerC.setText(questions.get(questionIndex).getAntwortC());
                    CheckBoxAnswerD.setText(questions.get(questionIndex).getAntwortD());
                    LabelQuestion.setText("Frage: " + questions.get(questionIndex).getFragenZahl());
                }


            }
        });

        ButtonLastQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (questionIndex >= 0) {

                    CheckBoxAnswerA.setSelected(false);
                    CheckBoxAnswerB.setSelected(false);
                    CheckBoxAnswerC.setSelected(false);
                    CheckBoxAnswerD.setSelected(false);

                    questionIndex = questionIndex - 1;

                    TextAreaShowQuestion.setText(questions.get(questionIndex).getFrage());
                    CheckBoxAnswerA.setText(questions.get(questionIndex).getAntwortA());
                    CheckBoxAnswerB.setText(questions.get(questionIndex).getAntwortB());
                    CheckBoxAnswerC.setText(questions.get(questionIndex).getAntwortC());
                    CheckBoxAnswerD.setText(questions.get(questionIndex).getAntwortD());
                    LabelQuestion.setText("Frage: " + questions.get(questionIndex).getFragenZahl());


                    String userantwort = questions.get(questionIndex).getUserAntwort();

                    //Antwort einlesen und Checkbox bei vorher beantworteter Antwort setzten
                    if (userantwort.equals("A")) {
                        CheckBoxAnswerA.setSelected(true);
                        System.out.println("Antwort A wurde ausgelesen");
                    }
                    if (userantwort.equals("B")) {
                        CheckBoxAnswerB.setSelected(true);
                        System.out.println("Antwort B wurde ausgelesen");
                    }
                    if (userantwort.equals("C")) {
                        CheckBoxAnswerC.setSelected(true);
                        System.out.println("Antwort C wurde ausgelesen");
                    }
                    if (userantwort.equals("D")) {
                        CheckBoxAnswerD.setSelected(true);
                        System.out.println("Antwort D wurde ausgelesen");
                    }

                }
            }
        });

        ButtonEndQuiz.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                // Antwort setzten
                if (CheckBoxAnswerA.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("A");
                    System.out.println("Antwort A wurde gesetzt");
                    CheckBoxAnswerA.setSelected(false);
                }
                if (CheckBoxAnswerB.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("B");
                    System.out.println("Antwort B wurde gesetzt");
                    CheckBoxAnswerB.setSelected(false);
                }
                if (CheckBoxAnswerC.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("C");
                    System.out.println("Antwort C wurde gesetzt");
                    CheckBoxAnswerC.setSelected(false);
                }
                if (CheckBoxAnswerD.isSelected()) {
                    questions.get(questionIndex).setUserAntwort("D");
                    System.out.println("Antwort D wurde gesetzt");
                    CheckBoxAnswerD.setSelected(false);
                }

                try {
                    mainWindowController.openFeedbackTab(questions, quiz, user);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        ListViewQuestions.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (!ListViewQuestions.getItems().isEmpty()) {
                    if (mouseEvent.getClickCount() == 2) {
                        String tmp = ListViewQuestions.getSelectionModel().getSelectedItem();
                        System.out.println(tmp);
                    }
                }
            }
        });
    }

    public byte[] getDownloadedQuiz() {
        return downloadedQuiz;
    }

    public void setDownloadedQuiz(byte[] downloadedQuiz) {
        this.downloadedQuiz = downloadedQuiz;
    }

    //@Author Noemi copy pasted von Kuri
    public boolean directoryExists(String path) throws FileNotFoundException, UnsupportedEncodingException {

        File file = new File(path);
        return (file.exists());
    }

}
