package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Literature;
import model.Topic;
import model.User;
import service.BibTexReader;
import service.TopicService;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class LiteratureTableViewController {

    Topic topic;
    TopicService topicService;
    MainWindowController mainWindowController;
    User lecturer;

    public LiteratureTableViewController(Topic topic, User lecturer, MainWindowController mainWindowController) {
        this.topic = topic;
        this.mainWindowController = mainWindowController;
        this.lecturer = lecturer;
        this.topicService = new TopicService();
    }

    @FXML
    AnchorPane anchorPane;
    @FXML
    TableView<Literature> tableView;
    @FXML
    TableColumn<Literature, String> typeColumn;
    @FXML
    TableColumn<Literature, String> titleColumn;
    @FXML
    TableColumn<Literature, String> authorColumn;
    @FXML
    TableColumn<Literature, String> publisherColumn;
    @FXML
    TableColumn<Literature, String> yearColumn;
    @FXML
    TableColumn<Literature, String> pagesColumn;
    @FXML
    TableColumn<Literature, String> volumeColumn;
    @FXML
    TableColumn<Literature, String> numberColumn;
    @FXML
    TableColumn<Literature, String> isbnColumn;
    @FXML
    TableColumn<Literature, String> journalColumn;
    @FXML
    TableColumn<Literature, String> doiColumn;
    @FXML
    TableColumn<Literature, String> keywordsColumn;
    @FXML
    TableColumn<Literature, String> booktitleColumn;
    @FXML
    TableColumn<Literature, String> addressColumn;
    @FXML
    TableColumn<Literature, String> seriesColumn;
    @FXML
    TableColumn<Literature, String> urlColumn;
    @FXML
    TableColumn<Literature, String> urlDateColumn;
    @FXML
    TableColumn<Literature, String> fileColumn;
    @FXML
    TableColumn<Literature, String> priceColumn;
    @FXML
    TableColumn<Literature, String> editorColumn;
    @FXML
    TableColumn<Literature, String> institutionColumn;
    @FXML
    TableColumn<Literature, String> abstractColumn;
    @FXML
    Button closeButton;

    //enthält "Objekte" aus der .txt Datei
    ObservableList<ObservableList<String>> contentOfColumns = FXCollections.observableArrayList();
    ObservableList<Literature> literatureWithAllAttributes = FXCollections.observableArrayList();

    public void initialize() throws IOException {
        //Spalten der TableView
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleColumn.setMinWidth(250.0);
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        authorColumn.setMinWidth(250.0);
        publisherColumn.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        //pagesColumn.setCellValueFactory(new PropertyValueFactory<>("pages"));
        //volumeColumn.setCellValueFactory(new PropertyValueFactory<>("volume"));
        //numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        isbnColumn.setMinWidth(100.0);
        journalColumn.setCellValueFactory(new PropertyValueFactory<>("journal"));
        //doiColumn.setCellValueFactory(new PropertyValueFactory<>("doi"));
        keywordsColumn.setCellValueFactory(new PropertyValueFactory<>("keywords"));
        //booktitleColumn.setCellValueFactory(new PropertyValueFactory<>("booktitle"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        isbnColumn.setMinWidth(100.0);
        //seriesColumn.setCellValueFactory(new PropertyValueFactory<>("series"));
        //urlColumn.setCellValueFactory(new PropertyValueFactory<>("url"));
        //urlDateColumn.setCellValueFactory(new PropertyValueFactory<>("urldate"));
        //fileColumn.setCellValueFactory(new PropertyValueFactory<>("file"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        //editorColumn.setCellValueFactory(new PropertyValueFactory<>("editor"));
        //institutionColumn.setCellValueFactory(new PropertyValueFactory<>("institution"));
        //abstractColumn.setCellValueFactory(new PropertyValueFactory<>("abstrakt"));

        //liest .txt Datei vom Server aus
        File tempFile = File.createTempFile("literature", ".txt", null);
        FileOutputStream fos = new FileOutputStream(tempFile);
        fos.write(topic.getLiterature());

        //enthält den Inhalt der Tabelle nach Spalten sortiert
        contentOfColumns = BibTexReader.readAttributes(BibTexReader.fileAsString(tempFile)/*, BibTexReader.getTypes(tempFile)*/);

        tableView = new TableView<>();
        tableView.setPrefWidth(1080.0);
        tableView.setPrefHeight(605.0);
        //enthält fertige Literature Objekte
        ObservableList<Literature> columns = getLiteratureFromReader(contentOfColumns);
        literatureWithAllAttributes = getLiteratureWithAllAttributes(contentOfColumns);
        columns.remove(1); // Zeile, die nur Attributbezeichnungen enthält
        columns.remove(0); // leere Zeile
        tableView.setItems(columns);
        tableView.getColumns().addAll(typeColumn, titleColumn, authorColumn, publisherColumn, yearColumn, /*pagesColumn,*/
                /*volumeColumn, numberColumn,*/ isbnColumn, journalColumn, /*doiColumn, keywordsColumn, booktitleColumn,*/ addressColumn,
                /*seriesColumn, urlColumn, urlDateColumn, fileColumn,*/ priceColumn /*editorColumn, institutionColumn abstractColumn*/);

        anchorPane.getChildren().add(tableView);

        //öffnet Popup mit Informationen zu der ausgewählten Literatur
        tableView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (!tableView.getItems().isEmpty()) {
                        if (mouseEvent.getClickCount() == 2) {
                            Literature tmp = tableView.getSelectionModel().getSelectedItem();
                            Stage primaryStage = new Stage();
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/LiteratureView.fxml"));
                            loader.setController(new LiteratureViewController(findLiterature(tmp), primaryStage));
                            Parent root = loader.load();
                            primaryStage.setScene(new Scene(root));
                            primaryStage.show();

                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //öffnet wieder die Themenübersicht
        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openTopicOverview(topic, lecturer);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    //liest die Spalten aus und befüllt Literature Objekte
    public static ObservableList<Literature> getLiteratureFromReader(ObservableList<ObservableList<String>> columns) {
        ObservableList<Literature> result = FXCollections.observableArrayList();

      for (int i = 0; i < columns.get(0).size(); i++) {
          Literature temp = new Literature(
                  BibTexReader.formatEntries(columns.get(0).get(i)), BibTexReader.formatEntries(columns.get(1).get(i)), BibTexReader.formatEntries(columns.get(2).get(i)),
                  BibTexReader.formatEntries(columns.get(3).get(i)), BibTexReader.formatEntries(columns.get(4).get(i)), /*BibTexReader.formatEntries(columns.get(5).get(i)),
                    /*BibTexReader.formatEntries(columns.get(6).get(i)), BibTexReader.formatEntries(columns.get(7).get(i)),*/ BibTexReader.formatEntries(columns.get(8).get(i)),
                  BibTexReader.formatEntries(columns.get(9).get(i)), /*BibTexReader.formatEntries(columns.get(10).get(i)),*/BibTexReader.formatEntries(columns.get(11).get(i)),
                  /*BibTexReader.formatEntries(columns.get(12).get(i)),*/ BibTexReader.formatEntries(columns.get(13).get(i)), /*BibTexReader.formatEntries(columns.get(14).get(i)),
                    BibTexReader.formatEntries(columns.get(15).get(i)), BibTexReader.formatEntries(columns.get(16).get(i)), BibTexReader.formatEntries(columns.get(17).get(i)),*/
                  BibTexReader.formatEntries(columns.get(18).get(i)) /*BibTexReader.formatEntries(columns.get(19).get(i)), BibTexReader.formatEntries(columns.get(20).get(i))
                    BibTexReader.formatEntries(columns.get(21).get(i))*/);
          result.add(temp);

      }
        result = filterLiterature(result);
        return result;
    }

    public static ObservableList<Literature> getLiteratureWithAllAttributes(ObservableList<ObservableList<String>> columns) {
        ObservableList<Literature> result = FXCollections.observableArrayList();

        for (int i = 0; i < columns.get(0).size(); i++) {
            Literature temp = new Literature(
                    BibTexReader.formatEntries(columns.get(0).get(i)), BibTexReader.formatEntries(columns.get(1).get(i)), BibTexReader.formatEntries(columns.get(2).get(i)),
                    BibTexReader.formatEntries(columns.get(3).get(i)), BibTexReader.formatEntries(columns.get(4).get(i)), BibTexReader.formatEntries(columns.get(5).get(i)),
                    BibTexReader.formatEntries(columns.get(6).get(i)), BibTexReader.formatEntries(columns.get(7).get(i)), BibTexReader.formatEntries(columns.get(8).get(i)),
                    BibTexReader.formatEntries(columns.get(9).get(i)), BibTexReader.formatEntries(columns.get(10).get(i)), BibTexReader.formatEntries(columns.get(11).get(i)),
                    BibTexReader.formatEntries(columns.get(12).get(i)), BibTexReader.formatEntries(columns.get(13).get(i)), BibTexReader.formatEntries(columns.get(14).get(i)),
                    BibTexReader.formatEntries(columns.get(15).get(i)), BibTexReader.formatEntries(columns.get(16).get(i)), BibTexReader.formatEntries(columns.get(17).get(i)),
                    BibTexReader.formatEntries(columns.get(18).get(i)), BibTexReader.formatEntries(columns.get(19).get(i)), BibTexReader.formatEntries(columns.get(20).get(i)),
                    BibTexReader.formatEntries(columns.get(21).get(i)));
            result.add(temp);
        }
        result = filterLiterature(result);
        return result;
    }

    public Literature findLiterature(Literature literature) {
        for (Literature a : literatureWithAllAttributes) {
            if (a.getTitle().equals(literature.getTitle()) && a.getYear().equals(literature.getYear())) {
                return a;
            }
        }
        return new Literature();
    }

    public static ObservableList<Literature> filterLiterature(ObservableList<Literature> list) {
        ObservableList<Literature> filtered = FXCollections.observableArrayList();
        for (Literature a : list) {
            if (!a.getTitle().equals("---")) {
                filtered.add(a);
            }
        }
        return filtered;
    }
}
