package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Lecturer;
import model.Student;
import model.User;

import java.io.IOException;

public class RoleWindowController {

    Stage stage;
    User userToCreate;

    @FXML
    Button nextButton;
    @FXML
    Button backButton;
    @FXML
    Label researchAreaLabel;
    @FXML
    Label instituteLabel;
    @FXML
    Label subjectLabel;
    @FXML
    TextField researchAreaField;
    @FXML
    TextField instituteField;
    @FXML
    TextField subjectField;
    @FXML
    Label ErrorLabelResearchArea;
    @FXML
    Label ErrorLabelSubject;
    @FXML
    Label ErrorLabelInstitute;

    boolean subjectBool = false;
    boolean instituteBool = false;
    boolean researchAreaBool = false;

    public RoleWindowController(User user, Stage stage) {
        this.userToCreate = user;
        this.stage = stage;
    }


    @FXML
    public void initialize() {

        //view wird für Studenten angepasst
        if (userToCreate instanceof Student) {
            subjectLabel.setText("Studienfach");
            subjectField.setText((((Student) userToCreate).getSubject()));
            instituteField.setVisible(false);
            instituteLabel.setVisible(false);
            researchAreaLabel.setVisible(false);
            researchAreaField.setVisible(false);
        }
        //view wird für Lehrperson angepasst
        else if (userToCreate instanceof Lecturer) {

            researchAreaLabel.setText("Forschungsgebiet");
            instituteLabel.setText("Lehrstuhl");
            instituteField.setText(((Lecturer) userToCreate).getInstitute());
            researchAreaField.setText(((Lecturer) userToCreate).getResearch());
            subjectLabel.setVisible(false);
            subjectField.setVisible(false);
        } else {
        }

        //wird ausgeführt wenn der weiter Button gedrückt wird
        nextButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                //Nutzer ist Student
                if (userToCreate.getIsstudent() == 1) {

                    //prüfe, ob Textfeld ausgefüllt ist
                    if (subjectField.getText() == null) {
                        ErrorLabelSubject.setText("Bitte geben Sie ein Studienfach an. ");
                    } else {
                        subjectBool = true;
                    }
                    //speichere Studienfach
                    if (subjectBool) {
                        ((Student) userToCreate).setSubject(EditProfileController.adjustInputFormat(subjectField.getText()));
                        try {
                            openPasswordWindow();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                    }
                }

                //Nutzer ist Lehrperson
                else {

                    //prüfe, ob Textfelder ausgefüllt sind
                    if (instituteField.getText() == null) {
                        ErrorLabelInstitute.setText("Bitte geben Sie einen Lehrstuhl an.");
                    } else {
                        instituteBool = true;
                    }
                    if (researchAreaField.getText() == null) {
                        ErrorLabelResearchArea.setText("Bitte geben Sie ein Forschungsgebiet an.");
                    } else {
                        researchAreaBool = true;
                    }
                    if (instituteBool && researchAreaBool) {
                        ((Lecturer) userToCreate).setInstitute(EditProfileController.adjustInputFormat(instituteField.getText()));
                        ((Lecturer) userToCreate).setResearch(EditProfileController.adjustInputFormat(researchAreaField.getText()));
                        try {
                            openPasswordWindow();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                    }
                }
            }
        });


        //wird ausgeführt wenn der Zurück Button gedrückt wird
        backButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CreateProfile.fxml"));
                    loader.setController(new CreateProfileController(stage, userToCreate));
                    Parent root = loader.load();

                    //get stage information
                    stage.setScene(new Scene(root));
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        });


    }
    //wird ausgeführt, wenn der weiter Button gedrückt wird
    public void openPasswordWindow() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Password.fxml"));
        loader.setController(new PasswordController(stage, userToCreate));
        Parent root = loader.load();

        //get stage information
        stage.setScene(new Scene(root));
    }


}



