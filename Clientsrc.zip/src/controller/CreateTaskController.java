package controller;


import exception.LecturerNotFoundException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;
import service.ParticipantService;
import service.TaskService;
import service.UserService;

import java.io.IOException;

public class CreateTaskController {
    @FXML
    private TextField inputTextField;
    @FXML
    private Button abortButton;
    @FXML
    private Button confirmButton;
    @FXML
    private ChoiceBox<String> stateChoiceBox;
    @FXML
    private ChoiceBox<String> participantChoiceBox;

    TaskService taskService;
    User loggedInUser;
    Course course;
    Stage stage;
    ObservableList<String> states = FXCollections.observableArrayList();
    ObservableList<Participant> participants = FXCollections.observableArrayList();
    ObservableList<String> usersNames = FXCollections.observableArrayList();
    ParticipantService participantService;
    UserService userService;

    private MainWindowController mainWindowController;


    public CreateTaskController(Course course, Stage stage, MainWindowController mainWindowController) {
        this.course = course;
        this.stage = stage;
        this.taskService = new TaskService();
        this.participantService = new ParticipantService();
        this.userService = new UserService();
        this.setMainWindowController(mainWindowController);
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }


    @FXML
    public void initialize() throws IOException {
        states.addAll("NA - nicht angefangen", "IB - in Bearbeitung", "F - Fertig");
        stateChoiceBox.setItems(states);

        participantService.getParticipantsOfCourse(course.getCoursekey());
        participants.setAll(participantService.getCurrentParticipantList());

        for (Participant a : participants) {
            userService.getUser(a.getUserkey());
            usersNames.add(userService.getCurrentUser().getFirstname() + " " + userService.getCurrentUser().getLastname());
        }
        participantChoiceBox.setItems(usersNames);


        abortButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();
            }
        });

        confirmButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    String taskstr = inputTextField.getText();
                    String state = stateChoiceBox.getSelectionModel().getSelectedItem();
                    int index = participantChoiceBox.getSelectionModel().getSelectedIndex();
                    String name = participantChoiceBox.getSelectionModel().getSelectedItem();
                    int participantuserkey = participants.get(index).getUserkey();

                    if (taskstr != null && (taskstr.length() > 3) && state != null) {
                        Task newtask = new Task(taskstr, state, course.getCoursekey(), participantuserkey, name);
                        taskService.addTask(newtask);
                        mainWindowController.updateCourseTab(course);
                        stage.close();


                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        });

    }

}

