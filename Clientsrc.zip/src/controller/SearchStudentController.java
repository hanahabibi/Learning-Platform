package controller;

import exception.AlreadyAParticipantException;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import model.*;
import org.springframework.util.NumberUtils;
import org.springframework.util.StringUtils;
import service.*;

import java.io.IOException;
import java.util.List;

public class SearchStudentController {

    @FXML
    private Button suchenButton;
    @FXML
    private Button AddStudentButton;
    @FXML
    private Button CloseButton;
    @FXML
    private TextField searchBox;
    @FXML
    private ListView filteredUsers;
    @FXML
    private Label ErrorLabel;

    User user;
    Course course;
    ParticipantService participantService;
    CourseService courseService;
    StudentService studentService;
    UserService userService;
    LecturerService lecturerService;
    ObservableList<User> UserList = FXCollections.observableArrayList();
    User selectedUser;

    private MainWindowController mainWindowController;
    int index;
    public SearchStudentController(User user, Course course, int index) {
        this.user = user;
        this.course = course;
        this.index = index;
        this.participantService = new ParticipantService();
        this.courseService = new CourseService();
        this.studentService = new StudentService();
        this.userService = new UserService();
    }


    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    @FXML
    public void initialize() throws IOException {
        userService.getAllUser();
        studentService.getAllStudent();
        getErrorLabel().setVisible(false);

       /* matrikelnummerSuche.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if (getSearchBox().getText() != null) {
                        UserList.clear();
                        String searchText = getSearchBox().getText();
                        int searchedmn = Integer.parseInt(searchText);
                        studentService.getStudentByID(searchedmn);
                        userService.getUser(studentService.getCurrentStudent().getUserkey());
                        UserList.add(userService.getCurrentUser());
                        searchBox.setText("");
                        getFilteredUsers().setItems(UserList);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        */

        suchenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if (searchBox.getText() != null) {
                        if (isNumeric(searchBox.getText())) {
                            UserList.clear();
                            String searchText = getSearchBox().getText();
                            int searchedmn = Integer.parseInt(searchText);
                            studentService.getStudentByID(searchedmn);
                            userService.getUser(studentService.getCurrentStudent().getUserkey());
                            UserList.add(userService.getCurrentUser());
                        } else {
                            UserList.clear();
                            CharSequence searchTerm = (CharSequence) searchBox.getText();
                            for (User a : userService.getUserList()) {
                                String name = a.getFirstname() + " " + a.getLastname();
                                if (name.toLowerCase().contains(searchTerm.toString().toLowerCase())) {
                                    UserList.add(a);
                                }
                            }
                        }
                        searchBox.setText("");
                        getFilteredUsers().setItems(UserList);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        CloseButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/fxml/CourseView.fxml"));
                    CourseViewController courseViewController = new CourseViewController(user, course, mainWindowController.tabMenu.getTabs().size() - 1);
                    courseViewController.setMainWindowController(mainWindowController);
                    loader.setController(courseViewController);
                    AnchorPane anchorPane1 = loader.load();
                    mainWindowController.tabMenu.getTabs().get(index).setContent(anchorPane1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        filteredUsers.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 1) {
                        if (UserList.size() != 0) {
                            selectedUser = (User) filteredUsers.getSelectionModel().getSelectedItem();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        AddStudentButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if (selectedUser != null) {
                        participantService.getParticipantsOfCourse(course.getCoursekey());
                        if (isParticipant(participantService.getCurrentParticipantList(), selectedUser.getUserkey())) {
                            throw new AlreadyAParticipantException();
                        } else {
                            participantService.addNewParticipant(new Participant(selectedUser.getUserkey(), course.getCoursekey(), 0));
                            getErrorLabel().setVisible(true);
                            getErrorLabel().setTextFill(Color.GREEN);
                            ErrorLabel.setText("Erfolgreich hinzugefügt!");
                            PauseTransition transition = new PauseTransition(Duration.seconds(6));
                            transition.setOnFinished(f -> ErrorLabel.setText(""));
                            transition.play();
                        }
                    }
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                } catch (AlreadyAParticipantException e) {
                    getErrorLabel().setVisible(true);
                    getErrorLabel().setTextFill(Color.RED);
                    ErrorLabel.setText("Dieser Nutzer ist bereits Teilnehmer von dieser Veranstaltung!");
                }
                PauseTransition transition = new PauseTransition(Duration.seconds(4));
                transition.setOnFinished(f -> ErrorLabel.setText(""));
                transition.play();
            }
        });

    }

    public boolean isParticipant(List<Participant> participantsl, int userkey) throws IOException {
        for (Participant a : participantsl) {
            if (a.getUserkey() == userkey) {
                return true;
            }
        }
        return false;
    }

    public boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

   /* public Button getMatrikelnummerSuche() {
        return matrikelnummerSuche;
    }

    public void setMatrikelnummerSuche(Button matrikelnummerSuche) {
        this.matrikelnummerSuche = matrikelnummerSuche;
    }

    public Button getNameSuche() {
        return nameSuche;
    }

    public void setNameSuche(Button nameSuche) {
        this.nameSuche = nameSuche;
    }

    */

    public Button getSuchenButton() {
        return suchenButton;
    }

    public void setSuchenButton(Button suchenButton) {
        this.suchenButton = suchenButton;
    }

    public Label getErrorLabel() {
        return ErrorLabel;
    }

    public void setErrorLabel(Label errorLabel) {
        ErrorLabel = errorLabel;
    }

    public Button getAddStudentButton() {
        return AddStudentButton;
    }

    public void setAddStudentButton(Button addStudentButton) {
        AddStudentButton = addStudentButton;
    }

    public Button getCloseButton() {
        return CloseButton;
    }

    public void setCloseButton(Button closeButton) {
        CloseButton = closeButton;
    }

    public TextField getSearchBox() {
        return searchBox;
    }

    public void setSearchBox(TextField searchBox) {
        this.searchBox = searchBox;
    }

    public ListView getFilteredUsers() {
        return filteredUsers;
    }

    public void setFilteredUsers(ListView filteredStudents) {
        this.filteredUsers = filteredStudents;
    }
}
