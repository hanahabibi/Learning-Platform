package controller;

import exception.StudentNotFoundException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import model.*;
import service.*;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;


public class ProfileController {

    private MainWindowController mainWindowController;

    @FXML
    private ImageView profilePic;
    @FXML
    private Label NameLabel;
    @FXML
    private Label studyFieldLabel_researchAreaLabel;
    @FXML
    private Label chairLabel_matrikelnummer;
    @FXML
    private Label emailAddress;
    @FXML
    private Label addressField;
    @FXML
    private Button profilButton;
    @FXML
    private ListView ListViewCourse;
    @FXML
    private Button addFriendButton;
    @FXML
    private Button sendMessageButton;
    @FXML
    private Button friendListButton;
    @FXML
    private ListView topicList;
    @FXML
    private Label topicLabel;

    //Speicherobjekte
    CourseService courseService;
    ParticipantService participantService;
    ChatService chatService;
    UserService userService;
    StudentService studentService;
    TopicService topicService;
    User userToSee;
    User loggedUser;
    ObservableList<Course> courseslist = FXCollections.observableArrayList();
    ObservableList<User> friendslist = FXCollections.observableArrayList();
    ObservableList<User> friendRequestSent = FXCollections.observableArrayList();
    ObservableList<User> friendRequestReceived = FXCollections.observableArrayList();

    //Konstruktor
    public ProfileController(User user, User clickedUser) {
        this.userToSee = clickedUser;
        this.loggedUser = user;
        courseService = new CourseService();
        participantService = new ParticipantService();
        chatService = new ChatService();
        studentService = new StudentService();
        userService = new UserService();
        topicService = new TopicService();
    }

    @FXML
    public void initialize() throws IOException, StudentNotFoundException {

        try {
            //generelle Infos zeigen
            ListViewCourse.getItems().clear();
            getNameLabel().setText(userToSee.getFirstname() + " " + userToSee.getLastname());
            getEmailAddress().setText(userToSee.getEmail());
            getAddressField().setText(userToSee.getAddress());

            //wenn es das eigene Profil ist: user == loggeduser
            if (userToSee.getUserkey() == loggedUser.getUserkey()) {
                profilButton.setText("Profil bearbeiten");
                addFriendButton.setVisible(false);

                //wenn man Student ist
                if (userToSee.getIsstudent() == 1) {
                    getChairLabel_matrikelnummer().setText(addzeros(((Student) userToSee).getMatnumber()));
                    getStudyFieldLabel_researchAreaLabel().setText(((Student) userToSee).getSubject());
                    topicLabel.setText("       Deine Freunde");
                    if (((Student) userToSee).getFriends() != null) {
                        setFriendsLists((Student) loggedUser);
                        topicList.setItems(friendslist);
                        friendListButton.setVisible(true);
                    }

                    //wenn man Lehrperson ist
                } else if (userToSee.getIsstudent() == 0) {
                    getChairLabel_matrikelnummer().setText(((Lecturer) userToSee).getInstitute());
                    getStudyFieldLabel_researchAreaLabel().setText(((Lecturer) userToSee).getResearch());
                    friendListButton.setVisible(true);
                    friendListButton.setText("Themenangebot hinzufügen");
                    topicLabel.setText("Aktuelle Themenangebote");
                    topicList.setItems(topicService.getTopicsByLecturerkey(loggedUser.getUserkey()));
                }
            }

            //wenn es das Profil eines anderen Nutzers ist
            else {
                profilButton.setText("Nachricht senden");
                friendListButton.setVisible(false);
                addressField.setVisible(false);
                emailAddress.setVisible(true);
                emailAddress.setText(userToSee.getEmail());
                topicList.setItems(topicService.getTopicsByLecturerkey(userToSee.getUserkey()));
                topicList.setVisible(false);
                topicLabel.setVisible(false);

                //wenn der loggedInUser Lehrperson ist
                if (loggedUser.getIsstudent() == 0) {
                    addFriendButton.setVisible(false);
                    friendListButton.setVisible(false);
                    addressField.setVisible(true);
                    addressField.setText(userToSee.getAddress());
                    topicList.setVisible(false);
                    topicLabel.setVisible(false);

                    //wenn eine Lehrperson das Profil eines Studenten anguckt
                    if (userToSee.getIsstudent() == 1) {
                        chairLabel_matrikelnummer.setVisible(true);
                        getChairLabel_matrikelnummer().setText(addzeros(((Student) userToSee).getMatnumber()));
                        getStudyFieldLabel_researchAreaLabel().setText(((Student) userToSee).getSubject());
                    } else if (userToSee.getIsstudent() == 0) {
                        chairLabel_matrikelnummer.setVisible(true);
                        getChairLabel_matrikelnummer().setText(((Lecturer) userToSee).getInstitute());
                        getStudyFieldLabel_researchAreaLabel().setText(((Lecturer) userToSee).getResearch());
                    }
                }
                //wenn der loggedInUser Student ist
                else if (loggedUser.getIsstudent() == 1) {
                    addFriendButton.setVisible(false);

                    //wenn der userToSee Student ist
                    if (userToSee.getIsstudent() == 1) {
                        addFriendButton.setVisible(true);
                        chairLabel_matrikelnummer.setVisible(false);
                        studyFieldLabel_researchAreaLabel.setText(((Student) userToSee).getSubject());
                        topicList.setVisible(false);
                        topicLabel.setVisible(false);
                        studyFieldLabel_researchAreaLabel.setVisible(true);
                        addFriendButton.setText("Freundschaftsanfrage schicken");
                        setFriendsLists((Student) loggedUser);

                        if (contain(friendslist, userToSee)) {
                            addFriendButton.setVisible(false);
                        } else if (contain(friendRequestSent, userToSee)) {
                            addFriendButton.setVisible(true);
                            addFriendButton.setText("Freundschaftsanfrage gesendet");
                        } else if (contain(friendRequestReceived, userToSee)) {
                            addFriendButton.setVisible(true);
                            addFriendButton.setText("Freundschaftsanfrage annehmen");
                        } else {
                            addFriendButton.setVisible(true);
                        }
                    }
                    //wenn der userToSee Lehrperson ist
                    else if (userToSee.getIsstudent() == 0) {
                        getChairLabel_matrikelnummer().setText(((Lecturer) userToSee).getInstitute());
                        getStudyFieldLabel_researchAreaLabel().setText(((Lecturer) userToSee).getResearch());
                        topicLabel.setVisible(true);
                        topicList.setVisible(true);
                        //füllt ein Dummy-Topic in die Liste
                        if (!isParticipant(loggedUser)) {
                            ObservableList<Topic> noTopics = FXCollections.observableArrayList();
                            noTopics.add(new Topic("            Es sind keine Themen verfügbar", "", 0, null));
                            topicList.setItems(noTopics);
                        }
                    }
                }
            }
            if (userToSee.getProfilepicture() != null) {
                ByteArrayInputStream bis = new ByteArrayInputStream(userToSee.getProfilepicture());
                profilePic.setImage(SwingFXUtils.toFXImage(ImageIO.read(bis), null));
            }

            addFriendButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        Student student = (Student) loggedUser;
                        Student clickedStudent = (Student) userToSee;

                        if (student.getFriends() != null && student.getFstate() != null) {
                            setFriendsLists(student);
                        }
                        if (clickedStudent.getFstate() != null && clickedStudent.getFstate() != null) {
                            setFriendsLists(student);
                        }

                        if (addFriendButton.getText().equals("Freundschaftsanfrage annehmen")) {
                            //Status wird beim loggedUser verändert
                            studentService.getStudentByUserKey(loggedUser.getUserkey());
                            if (studentService.getCurrentStudent().getFstate() != "") {
                                int[] fStatesInt = studentService.getFStates(student);
                                int[] friendsInt = studentService.getFriends(student);

                                for (int i = 0; i < fStatesInt.length; i++) {
                                    if (friendsInt[i] == userToSee.getUserkey()) {
                                        fStatesInt[i] = 3;
                                    }
                                }
                                String newfStates = "";
                                for (int i = 0; i < fStatesInt.length; i++) {
                                    newfStates = newfStates + fStatesInt[i] + " ";
                                }
                                studentService.getCurrentStudent().setFstate(newfStates);
                            } else {
                                studentService.getCurrentStudent().setFstate("3 ");
                            }
                            studentService.setStudent(studentService.getCurrentStudent());

                            //Status wird beim UserToSee verändert
                            studentService.getStudentByUserKey(userToSee.getUserkey());
                            if (studentService.getCurrentStudent().getFstate() != "") {
                                int[] fStatesInt = studentService.getFStates(clickedStudent);
                                int[] friendsInt = studentService.getFriends(clickedStudent);

                                for (int i = 0; i < fStatesInt.length; i++) {
                                    if (friendsInt[i] == loggedUser.getUserkey()) {
                                        fStatesInt[i] = 3;
                                    }
                                }
                                String newfStates = "";
                                for (int i = 0; i < fStatesInt.length; i++) {
                                    newfStates = newfStates + fStatesInt[i] + " ";
                                }
                                studentService.getCurrentStudent().setFstate(newfStates);
                            } else {
                                studentService.getCurrentStudent().setFstate("3 ");
                            }
                            studentService.setStudent(studentService.getCurrentStudent());
                            friendslist.add(userToSee);
                            addFriendButton.setText("Anfrage angenommen");
                        } else if (addFriendButton.getText().equals("Freundschaftsanfrage schicken")) {

                            //Status wird beim loggedUser verändert
                            studentService.getStudentByUserKey(loggedUser.getUserkey());
                            if (!studentService.getCurrentStudent().getFstate().equals("")) {
                                String fStates = studentService.getCurrentStudent().getFstate();
                                studentService.getCurrentStudent().setFstate(fStates + 1 + " ");
                                String friends = studentService.getCurrentStudent().getFriends();
                                studentService.getCurrentStudent().setFriends(friends + clickedStudent.getUserkey() + " ");
                            } else {
                                studentService.getCurrentStudent().setFstate("1 ");
                                studentService.getCurrentStudent().setFriends(clickedStudent.getUserkey() + " ");
                            }
                            studentService.setStudent(studentService.getCurrentStudent());

                            //Status wird beim UserToSee verändert
                            studentService.getStudentByUserKey(userToSee.getUserkey());
                            if (!studentService.getCurrentStudent().getFstate().equals("")) {
                                String fStates = studentService.getCurrentStudent().getFstate();
                                studentService.getCurrentStudent().setFstate(fStates + 2 + " ");
                                String friends = studentService.getCurrentStudent().getFriends();
                                studentService.getCurrentStudent().setFriends(friends + loggedUser.getUserkey() + " ");
                            } else {
                                studentService.getCurrentStudent().setFstate("2 ");
                                studentService.getCurrentStudent().setFriends(loggedUser.getUserkey() + " ");
                            }
                            studentService.setStudent(studentService.getCurrentStudent());
                            addFriendButton.setText("Anfrage gesendet");
                        }
                    } catch (StudentNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    /*ObservableList<User> allFriends = FXCollections.observableArrayList();
                    try {
                        Student student = (Student) loggedUser;
                        String friendsliststr = student.getFriends();
                        String fstateliststr = student.getFstate();


                        if (student.getFriends() != null && student.getFstate() != null) {
                            String[] friendl = friendsliststr.split(" ");
                            String[] fstatel = fstateliststr.split(" ");

                            int[] studentlint = new int[friendl.length];
                            int[] fstatelint = new int[fstatel.length];

                            for (int i = 0; i < friendl.length; i++) {
                                studentlint[i] = Integer.parseInt(friendl[i]);
                                fstatelint[i] = Integer.parseInt(fstatel[i]);
                                userService.getUser(studentlint[i]);
                                allFriends.add(userService.getCurrentUser());

                            }

                            for (int i = 0; i < allFriends.size(); i++) {
                                if (fstatelint[i] == 3) {
                                    friendslist.add(allFriends.get(i));
                                } else if (fstatelint[i] == 2) {
                                    friendRequestReceived.add(allFriends.get(i));
                                } else if (fstatelint[i] == 1) {
                                    friendRequestSent.add(allFriends.get(i));
                                } else {
                                    allFriends.remove(allFriends.get(i));
                                }
                            }

                            if (addFriendButton.getText().equals("Accept Request")) {
                                fstatelint[indexof(allFriends, userToSee)] = 3;
                                String str = "";
                                for (int i = 0; i < fstatelint.length; i++) {
                                    str += fstatelint[i] + " ";
                                }

                                studentService.getStudentByUserKey(loggedUser.getUserkey());
                                studentService.getCurrentStudent().setFstate(str);
                                studentService.setStudent(studentService.getCurrentStudent());

                                ObservableList<User> otherallFriends = FXCollections.observableArrayList();

                                studentService.getStudentByUserKey(userToSee.getUserkey());
                                String otherfstatestr = studentService.getCurrentStudent().getFstate();
                                String otherfriendsstr = studentService.getCurrentStudent().getFriends();
                                String[] otherfriendl = otherfriendsstr.split(" ");
                                String[] otherfstatel = otherfstatestr.split(" ");
                                int[] otherstudentlint = new int[otherfriendl.length];
                                int[] otherfstatelint = new int[otherfstatel.length];
                                for (int i = 0; i < otherfriendl.length; i++) {
                                    otherstudentlint[i] = Integer.parseInt(otherfriendl[i]);
                                    otherfstatelint[i] = Integer.parseInt(otherfstatel[i]);
                                    userService.getUser(otherstudentlint[i]);
                                    otherallFriends.add(userService.getCurrentUser());
                                }
                                otherfstatelint[indexof(otherallFriends, loggedUser)] = 3;
                                String otherstr = "";
                                for (int i = 0; i < otherfstatelint.length; i++) {
                                    otherstr += otherfstatelint[i] + " ";
                                }
                                studentService.getStudentByUserKey(userToSee.getUserkey());
                                studentService.getCurrentStudent().setFstate(otherstr);
                                studentService.setStudent(studentService.getCurrentStudent());

                                addFriendButton.setVisible(false);

                            } else if (addFriendButton.getText().equals("Add Friend")) {
                                allFriends.add(userToSee);
                                int[] newarray = new int[allFriends.size()];
                                int[] friendsnewarray = new int[allFriends.size()];
                                for (int i = 0; i < fstatelint.length; i++) {
                                    newarray[i] = fstatelint[i];
                                    friendsnewarray[i] = allFriends.get(i).getUserkey();
                                }

                                newarray[newarray.length - 1] = 1;
                                friendsnewarray[friendsnewarray.length - 1] = userToSee.getUserkey();

                                studentService.getStudentByUserKey(loggedUser.getUserkey());
                                String keystr = "";
                                String statesstr = "";
                                for (int i = 0; i < newarray.length; i++) {
                                    keystr += friendsnewarray[i] + " ";
                                    statesstr += newarray[i] + " ";
                                }
                                studentService.getCurrentStudent().setFriends(keystr);
                                studentService.getCurrentStudent().setFstate(statesstr);

                                studentService.setStudent(studentService.getCurrentStudent());


                                ObservableList<User> otherallFriends = FXCollections.observableArrayList();

                                studentService.getStudentByUserKey(userToSee.getUserkey());
                                String otherfstatestr = studentService.getCurrentStudent().getFstate();
                                String otherfriendsstr = studentService.getCurrentStudent().getFriends();
                                String[] otherfriendl = otherfriendsstr.split(" ");
                                String[] otherfstatel = otherfstatestr.split(" ");
                                int[] otherfriendlint = new int[otherfriendl.length + 1];
                                int[] otherfstatelint = new int[otherfstatel.length + 1];
                                for (int i = 0; i < otherfriendl.length; i++) {
                                    otherfriendlint[i] = Integer.parseInt(otherfriendl[i]);
                                    otherfstatelint[i] = Integer.parseInt(otherfstatel[i]);
                                }
                                otherfriendlint[otherfriendlint.length - 1] = loggedUser.getUserkey();
                                otherfstatelint[otherfriendlint.length - 1] = 2;
                                String okeystr = "";
                                String ostatesstr = "";
                                for (int i = 0; i < otherfriendlint.length; i++) {
                                    okeystr += otherfriendlint[i] + " ";
                                    ostatesstr += otherfstatelint[i] + " ";
                                }

                                studentService.getCurrentStudent().setFriends(okeystr);
                                studentService.getCurrentStudent().setFstate(ostatesstr);
                                studentService.setStudent(studentService.getCurrentStudent());

                                addFriendButton.setText("Request sent");

                            } else if (addFriendButton.getText().equals("Request sent")) {

                                fstatelint[indexof(allFriends, userToSee)] = 3;
                                String str = "";
                                for (int i = 0; i < fstatelint.length; i++) {
                                    str += fstatelint[i] + " ";
                                }
                                studentService.getStudentByUserKey(loggedUser.getUserkey());
                                studentService.getCurrentStudent().setFstate(str);
                                studentService.setStudent(studentService.getCurrentStudent());

                                ObservableList<User> otherallFriends = FXCollections.observableArrayList();

                                studentService.getStudentByUserKey(userToSee.getUserkey());
                                String otherfstatestr = studentService.getCurrentStudent().getFstate();
                                String otherfriendsstr = studentService.getCurrentStudent().getFriends();
                                String[] otherfriendl = otherfriendsstr.split(" ");
                                String[] otherfstatel = otherfstatestr.split(" ");
                                int[] otherstudentlint = new int[otherfriendl.length];
                                int[] otherfstatelint = new int[otherfstatel.length];
                                for (int i = 0; i < otherfriendl.length; i++) {
                                    otherstudentlint[i] = Integer.parseInt(otherfriendl[i]);
                                    otherfstatelint[i] = Integer.parseInt(otherfstatel[i]);
                                    userService.getUser(otherstudentlint[i]);
                                    otherallFriends.add(userService.getCurrentUser());
                                }
                                otherfstatelint[indexof(otherallFriends, userToSee)] = 0;
                                String otherstr = "";
                                for (int i = 0; i < otherfstatelint.length; i++) {
                                    otherstr += otherfstatelint[i] + " ";
                                }
                                studentService.getStudentByUserKey(userToSee.getUserkey());
                                studentService.getCurrentStudent().setFstate(otherstr);
                                studentService.setStudent(studentService.getCurrentStudent());

                                addFriendButton.setText("Add Friend");
                            }
                        }
                        else {

                        }
                    } catch (StudentNotFoundException studentNotFoundException) {
                        studentNotFoundException.printStackTrace();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }*/

                }
            });

            //belegte Veranstaltungen
            participantService.getParticipant(userToSee.getUserkey());
            if (participantService.getCurrentParticipantList() != null) {
                for (Participant participant : participantService.getCurrentParticipantList()) {
                    if (participant.getUserkey() == userToSee.getUserkey()) {
                        courseService.getCourseByID(participant.getCoursekey());
                        courseslist.add(courseService.getCurrentCourse());
                    }
                }
            }
            getListViewCourse().setItems(courseslist);

            //Bei Klick auf Kursliste
            ListViewCourse.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        if (mouseEvent.getClickCount() == 2) {
                            openCourse(mouseEvent);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            //Doppelbelegung Freundesliste und Themenliste
            topicList.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        if (mouseEvent.getClickCount() == 2) {
                            if (loggedUser.getIsstudent() == 0 || userToSee.getIsstudent() == 0) {
                                openTopicOverview(mouseEvent);
                            } else {
                                openFriendsProfile(mouseEvent);
                            }
                        }
                    } catch (IOException | StudentNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Doppelbelegung
        friendListButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                //öffnet die Freundesliste, wenn es das eigene Profil ist
                if (mainWindowController.loggedInUser.getIsstudent() == 1) {
                    try {
                        mainWindowController.openFriendsListTab();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //öffnet "Thema hinzufügen", wenn es das eigene Profil einer Lehrperson ist
                else {
                    try {
                        mainWindowController.openAddTopic();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        //Doppelbelegung
        profilButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                //öffnet "Profil bearbeiten", wenn es das eigene Profil ist
                if (loggedUser.getUserkey() == userToSee.getUserkey()) {
                    try {
                        mainWindowController.openEditProfileTab();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //geht zum Chat Tab, wenn es das Profil eines anderen Users ist
                else {
                    try {
                        mainWindowController.openPrivateChatTab(loggedUser, userToSee);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    //findet User in einer Liste
    public int indexof(ObservableList<User> list, User user) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getUserkey() == user.getUserkey()) {
                return i;
            }
        }
        return -1;
    }

    //prüft, ob Liste gegebenes Objekt enthält
    public boolean contain(ObservableList<User> list, User user) {
        for (User a : list) {
            if (a.getUserkey() == user.getUserkey()) {
                return true;
            }
        }
        return false;
    }

    //öffnet ausgewählten Kurs
    public void openCourse(MouseEvent mouseEvent) throws IOException {
        Course selectedCourse;
        if (courseslist.size() != 0) {
            int currentListSelectionIndex = ListViewCourse.getSelectionModel().getSelectedIndex();
            selectedCourse = courseslist.get(currentListSelectionIndex);
        } else {
            int currentListSelectionIndex = ListViewCourse.getSelectionModel().getSelectedIndex();
            selectedCourse = courseslist.get(currentListSelectionIndex);
        }
        mainWindowController.openNewCourseTab(selectedCourse);
    }

    //öffnet übersicht von ausgewähltem Thema
    public void openTopicOverview(MouseEvent mouseEvent) throws IOException {
        Topic selectedTopic;
        int index = topicList.getSelectionModel().getSelectedIndex();
        if (loggedUser.getIsstudent() == 0) {
            selectedTopic = topicService.getTopicsByLecturerkey(loggedUser.getUserkey()).get(index);
        } else {
            selectedTopic = topicService.getTopicsByLecturerkey(userToSee.getUserkey()).get(index);
        }
        mainWindowController.openTopicOverview(selectedTopic, userToSee);
    }

    public void openFriendsProfile(MouseEvent mouseEvent) throws IOException, StudentNotFoundException {
        User selectedUser;
        int index = topicList.getSelectionModel().getSelectedIndex();
        selectedUser = friendslist.get(index);
        studentService.getStudentByUserKey(selectedUser.getUserkey());
        userService.getUser(selectedUser.getUserkey());
        studentService.getCurrentStudent().join(userService.getCurrentUser());
        mainWindowController.openProfileTab(studentService.getCurrentStudent());
    }

    //liest die Freunde-Daten aus der Datenbank aus und belegt die Listen
    public void setFriendsLists(Student student) throws StudentNotFoundException, IOException {
        friendRequestSent = castToUser(studentService.getFriendsByFState(student, 1));
        friendRequestReceived = castToUser(studentService.getFriendsByFState(student, 2));
        friendslist = castToUser(studentService.getFriendsByFState(student, 3));
    }

    //castet Studenten zu Usern
    public ObservableList<User> castToUser(ObservableList<Student> students) throws IOException {
        ObservableList<User> result = FXCollections.observableArrayList();
        for (Student a : students) {
            userService.getUser(a.getUserkey());
            result.add(userService.getCurrentUser());
        }
        return result;
    }

    //prüft, ob der Student ein Teilnehmer in einem Kurs der Lehrperson ist
    public boolean isParticipant(User student) throws IOException {

        ObservableList<Course> coursesByLecturer = FXCollections.observableArrayList();
        boolean isParticipant = false;
        courseService.getAll();
        List<Course> tmp = courseService.getCourseList();
        for (Course a : tmp) {
            if (a.getUserkey() == userToSee.getUserkey()) {
                coursesByLecturer.add(a);
            }
        }
        for (Course a : coursesByLecturer) {
            participantService.getParticipantsOfCourse(a.getCoursekey());
            List<Participant> participantsOfCourse = participantService.getCurrentParticipantList();
            for (Participant p : participantsOfCourse) {
                if (p.getUserkey() == student.getUserkey()) {
                    isParticipant = true;
                }
            }
        }
        return isParticipant;
    }

    //füllt Matrikelnummer mit Nullen auf
    public String addzeros(int matrikelnummer) {
        if (matrikelnummer < 10) {
            return "000000" + matrikelnummer;
        } else if (matrikelnummer < 100) {
            return "00000" + matrikelnummer;
        } else if (matrikelnummer < 1000) {
            return "0000" + matrikelnummer;
        } else if (matrikelnummer < 10000) {
            return "000" + matrikelnummer;
        } else if (matrikelnummer < 100000) {
            return "00" + matrikelnummer;
        } else if (matrikelnummer < 1000000) {
            return "0" + matrikelnummer;
        } else {
            return String.valueOf(matrikelnummer);
        }
    }

    //Hilfsmethoden
    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public User getUserToSee() {
        return userToSee;
    }

    public void setUserToSee(User userToSee) {
        this.userToSee = userToSee;
    }

    public User getLoggedUser() {
        return loggedUser;
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    public Label getNameLabel() {
        return NameLabel;
    }

    public void setNameLabel(Label nameLabel) {
        NameLabel = nameLabel;
    }

    public Label getStudyFieldLabel_researchAreaLabel() {
        return studyFieldLabel_researchAreaLabel;
    }

    public void setStudyFieldLabel_researchAreaLabel(Label studyFieldLabel_researchAreaLabel) {
        this.studyFieldLabel_researchAreaLabel = studyFieldLabel_researchAreaLabel;
    }

    public Label getChairLabel_matrikelnummer() {
        return chairLabel_matrikelnummer;
    }

    public void setChairLabel_matrikelnummer(Label chairLabel_matrikelnummer) {
        this.chairLabel_matrikelnummer = chairLabel_matrikelnummer;
    }

    public Label getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(Label emailAddress) {
        this.emailAddress = emailAddress;
    }

    public Label getAddressField() {
        return addressField;
    }

    public void setAddressField(Label addressField) {
        this.addressField = addressField;
    }


    public Button getProfilButton() {
        return profilButton;
    }

    public void setProfilButton(Button profilButton) {
        this.profilButton = profilButton;
    }

    public ListView getListViewCourse() {
        return ListViewCourse;
    }

    public void setListViewCourse(ListView listViewCourse) {
        ListViewCourse = listViewCourse;
    }

    public Button getAddFriendButton() {
        return addFriendButton;
    }

    public void setAddFriendButton(Button addFriendButton) {
        this.addFriendButton = addFriendButton;
    }

    public ImageView getProfilePicture() {
        return profilePic;
    }
}


