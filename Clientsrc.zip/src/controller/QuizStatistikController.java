package controller;

import Interfaces.UserInterface;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import model.Course;
import model.Questions;
import model.Quiz;
import model.User;
import service.*;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.io.IOException;
import java.util.ArrayList;

public class QuizStatistikController {


    @FXML
    public Label nameLabel;
    @FXML
    public ListView userAtemptsListView, questionsStatisticsListView;
    @FXML
    public Button ButtonBackToCourse;

    @FXML
    PieChart attendentChart, participantChart;

    Quiz quiz;
    QuizService quizService;
    StringService stringService;
    UserService userService;
    private MainWindowController mainWindowController;
    CourseService courseService;
    ParticipantService participantService;

    QuizStatistikController(Quiz quiz) {
        this.quiz = quiz;
        stringService = new StringService(quiz.getWhoworkedonthatquiz());
        quizService = new QuizService();
        courseService = new CourseService();
        participantService = new ParticipantService();
        userService = new UserService();

    }


    public void initialize() throws IOException {
        courseService.getCourseByID(quiz.getCoursekey());
        quizService.getQuizByCourseKey(quiz.getCoursekey());
        participantService.getParticipantsOfCourse(quiz.getCoursekey());
        nameLabel.setText("Statistik vom Quizs" + quizService.getQuizList().indexOf(quiz) + "der Veranstaltung\n" + courseService.getCurrentCourse().getName());
        float tmp1 = stringService.getUserAtempts().length - 1;
        float tmp2 = participantService.getCurrentParticipantList().size() - stringService.getUserAtempts().length - 1;
        ObservableList<PieChart.Data> tmpList = FXCollections.observableArrayList(new PieChart.Data("Quiz bearbeitet: " + Math.round(tmp1 / (tmp1 + tmp2) * 100) + "%", tmp1),
                new PieChart.Data("Quiz nicht bearbeitet: " + Math.round(tmp2 / (tmp1 + tmp2) * 100) + "%", tmp2));


        attendentChart.setData(tmpList);

        tmp1 = stringService.passedList().size();
        tmp2 = stringService.getUserAtempts().length - 1 - tmp1;
        ObservableList<PieChart.Data> tmpList2 = FXCollections.observableArrayList(new PieChart.Data("Bestanden: " + Math.round(tmp1 / (tmp1 + tmp2) * 100) + "%", tmp1), new PieChart.Data("Nicht bestanden: " + Math.round(tmp2 / (tmp1 + tmp2) * 100) + "%", tmp2));

        participantChart.setData(tmpList2);

        FXMLLoader loader;
        for (int[] a : stringService.getUserAtempts()) {
            loader = new FXMLLoader();
            if (a[0] != 0) {
                userService.getUser(a[0]);

                UserAttemptsView userAttemptsView = new UserAttemptsView(userService.getCurrentUser().getFirstname() + " " + userService.getCurrentUser().getLastname(), a[1] + "");
                loader.setLocation(getClass().getResource("/fxml/UserAtemptsView.fxml"));
                loader.setController(userAttemptsView);
                AnchorPane tmp = loader.load();
                userAtemptsListView.getItems().add(tmp);
            }
        }


        int k = 1;
        for (int[] a : stringService.getAntwortField()) {
            for (int i : a) {
                if (i != 0) {
                    loader = new FXMLLoader();
                    UserAttemptsView userAttemptsView = new UserAttemptsView("Frage " + k, String.valueOf(i));
                    loader.setLocation(getClass().getResource("/fxml/UserAtemptsView.fxml"));
                    loader.setController(userAttemptsView);
                    AnchorPane tmp = loader.load();
                    questionsStatisticsListView.getItems().add(tmp);
                    k++;
                }
            }
        }


        ButtonBackToCourse.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

            }
        });
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public class UserAttemptsView {
        @FXML
        Label userNameLabel, userVersuche;
        String user, versuche;

        public UserAttemptsView(String user, String versuche) {
            this.user = user;
            this.versuche = versuche;
        }

        public void initialize() throws IOException {
            userNameLabel.setText(user);
            userVersuche.setText(versuche);
        }
    }

}
