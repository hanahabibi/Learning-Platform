package controller;

import exception.NoMaterialSelectedException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.*;
import service.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;


public class CourseViewController {

    User user;
    Course course;

    @FXML
    private Button joinThisCourse;
    @FXML
    private Button addCourseMaterial;
    @FXML
    private Label courseNameLabel;
    @FXML
    private Button participantsList;
    @FXML
    private Button addStudentButton;
    @FXML
    private ListView CourseMaterialList;
    @FXML
    private Button deleteMaterialButton;
    @FXML
    private ListView<Event> eventList;
    @FXML
    private Button addEventButton;
    @FXML
    private Button ButtonCourseViewAnswerQuiz, ButtonCourseViewAnswerEvaluation;
    @FXML
    private Button ButtonCourseViewCreateQuiz, ButtonCourseViewCreateEvaluation;
    @FXML
    private Button ButtonReadXMLFile;
    @FXML
    private Label listContentLabel;
    @FXML
    private Label quizLabel, evaluationLabel;
    @FXML
    private Label eventLabel;
    @FXML
    private Separator separatorOne;
    @FXML
    private Separator separatorTwo;
    @FXML
    private ListView<Task> taskList;
    @FXML
    private Button ButtonQuizStatistik, ButtonCourseViewEvaluation;
    @FXML
    private Button cardsButton;


    ParticipantService participantService;
    CourseService courseService;
    EventService eventService;
    LearningMaterialService learningMaterialService;
    UserService userService;
    TaskService taskService;
    CardService cardService;
    QuizService quizService;
    StringService stringService;
    byte[] blobfile;
    ObservableList<LearningMaterial> materialList = FXCollections.observableArrayList();
    ObservableList<Task> tasks = FXCollections.observableArrayList();
    LearningMaterial selectedMaterial;

    private MainWindowController mainWindowController;
    int index;

    public CourseViewController(User user, Course course, int index) {

        this.user = user;
        this.course = course;
        participantService = new ParticipantService();
        courseService = new CourseService();
        eventService = new EventService();
        learningMaterialService = new LearningMaterialService();
        taskService = new TaskService();
        userService = new UserService();
        cardService = new CardService();
        quizService = new QuizService();


        this.index = index;
    }

    public CourseViewController() {

    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    @FXML
    public void initialize() throws IOException {
        quizService.getQuizByCourseKey(course.getCoursekey());
        tasks.clear();
        taskList.setVisible(false);
        learningMaterialService.getMaterialbyCourseKey(course.getCoursekey());
        materialList.setAll(learningMaterialService.getListOfMaterial());
        cardsButton.setVisible(false);
        courseService.setCurrentCourse(course);
        participantService.getParticipantsOfCourse(course.getCoursekey());
        courseNameLabel.setText(course.getName());
        if (courseService.getCurrentCourse().getTyp().equals("Projektgruppe")) {
            eventList.setVisible(false);
            taskList.setVisible(true);
            taskService.getTaskbyCourseKey(course.getCoursekey());
            if (taskService.getListOfTasks() != null) {
                tasks.addAll(taskService.getListOfTasks());
                taskList.setItems(tasks);
            }
        } else {
            fillEventListView();
        }

        if (participantService.getCurrentParticipantList() != null) {
            if (!isParticipant(participantService.getCurrentParticipantList(), user.getUserkey())) {
                participantsList.setVisible(false);
                CourseMaterialList.setVisible(false);
                addCourseMaterial.setVisible(false);
                addStudentButton.setVisible(false);
                deleteMaterialButton.setVisible(false);
                ButtonReadXMLFile.setVisible(false);
                ButtonCourseViewCreateQuiz.setVisible(false);
                ButtonCourseViewCreateEvaluation.setVisible(false);
                ButtonCourseViewAnswerQuiz.setVisible(false);
                ButtonCourseViewAnswerEvaluation.setVisible(false);
                ButtonQuizStatistik.setVisible(false);
                ButtonCourseViewEvaluation.setVisible(false);
                quizLabel.setVisible(false);
                evaluationLabel.setVisible(false);
                eventList.setVisible(false);
                eventLabel.setVisible(false);
                addEventButton.setVisible(false);
                listContentLabel.setVisible(false);
                separatorOne.setVisible(false);
                separatorTwo.setVisible(false);
                taskList.setVisible(false);
                ButtonQuizStatistik.setVisible(false);
                if (user.getIsstudent() == 1) {
                    joinThisCourse.setVisible(true);
                }
            } else {
                joinThisCourse.setVisible(false);
                participantsList.setVisible(true);
                CourseMaterialList.setVisible(true);
                listContentLabel.setVisible(true);
                addCourseMaterial.setVisible(true);

                if (courseService.getCurrentCourse().getTyp().equals("Projektgruppe")) {

                    participantsList.setText("Gruppenchat");
                    listContentLabel.setText("Materialien");
                    addStudentButton.setVisible(true);
                    eventLabel.setVisible(true);
                    addEventButton.setVisible(true);
                    if (materialList.size() != 0) {
                        deleteMaterialButton.setVisible(true);
                    } else {
                        deleteMaterialButton.setVisible(false);
                    }
                    separatorTwo.setVisible(false);
                    quizLabel.setVisible(false);
                    evaluationLabel.setVisible(false);
                    ButtonQuizStatistik.setVisible(false);
                    ButtonCourseViewEvaluation.setVisible(false);
                    ButtonCourseViewAnswerQuiz.setVisible(false);
                    ButtonCourseViewAnswerEvaluation.setVisible(false);
                    ButtonCourseViewCreateQuiz.setVisible(false);
                    ButtonCourseViewCreateEvaluation.setVisible(false);
                    ButtonReadXMLFile.setVisible(false);
                    addCourseMaterial.setText("Material hinzufügen");
                    deleteMaterialButton.setVisible(false);
                    eventLabel.setText("ToDo-Liste");
                    addEventButton.setText("ToDo hinzufügen");
                    addStudentButton.setVisible(true);
                    cardsButton.setVisible(true);
                    participantService.getParticipantsOfCourse(course.getCoursekey());
                    if (participantService.getCurrentParticipantList().size() > 5) {
                        addStudentButton.setVisible(false);
                        joinThisCourse.setVisible(false);
                    }

                    if (mainWindowController.loggedInUser.getIsstudent() == 1) {
                        addStudentButton.setVisible(false);
                    }
                } else {

                    participantsList.setVisible(true);
                    listContentLabel.setVisible(true);
                    separatorOne.setVisible(true);
                    separatorTwo.setVisible(true);
                    eventLabel.setVisible(true);
                    eventList.setVisible(true);
                    quizLabel.setVisible(true);
                    evaluationLabel.setVisible(true);
                    CourseMaterialList.setVisible(true);

                    if (user.getIsstudent() == 1) {
                        addCourseMaterial.setVisible(false);
                        addStudentButton.setVisible(false);
                        deleteMaterialButton.setVisible(false);
                        ButtonCourseViewAnswerQuiz.setVisible(true);
                        ButtonCourseViewAnswerEvaluation.setVisible(true);
                        ButtonCourseViewCreateQuiz.setVisible(false);
                        ButtonCourseViewCreateEvaluation.setVisible(false);
                        ButtonReadXMLFile.setVisible(false);
                        ButtonQuizStatistik.setVisible(false);
                        ButtonCourseViewEvaluation.setVisible(false);

                        int counter = 0;
                        boolean hasDoneEval = false;
                        quizService.getQuizByCourseKey(course.getCoursekey());
                        for (Quiz a : quizService.getQuizList()) {
                            if (a.getType().equals("quiz")) {
                                if (!a.getWhoworkedonthatquiz().isEmpty()) {
                                    stringService = new StringService(a.getWhoworkedonthatquiz());
                                    if (stringService.hasDoneQuiz(user.getUserkey())) {
                                        counter++;
                                    }
                                }
                            } else {
                                stringService = new StringService("");
                                stringService.loadEval(a.getWhoworkedonthatquiz());
                                for (int b : stringService.getUsers()) {
                                    if (b == mainWindowController.loggedInUser.getUserkey()) {
                                        hasDoneEval = true;
                                    }
                                }
                            }
                        }


                        if (counter < quizService.getQuizList().size() / 2) {
                            ButtonCourseViewAnswerEvaluation.setVisible(false);
                            evaluationLabel.setVisible(false);
                        }
                        if (hasDoneEval) {
                            ButtonCourseViewAnswerEvaluation.setVisible(false);
                            evaluationLabel.setVisible(false);
                        }


                    } else if (user.getIsstudent() == 0) {
                        ButtonCourseViewAnswerQuiz.setVisible(false);
                        ButtonCourseViewAnswerEvaluation.setVisible(false);
                        addEventButton.setVisible(true);
                        for (Participant participant : participantService.getCurrentParticipantList()) {
                            if (participant.getUserkey() == user.getUserkey() || course.getUserkey() == user.getUserkey()) {
                                addCourseMaterial.setVisible(true);
                                if (materialList.size() == 0) {
                                    deleteMaterialButton.setVisible(false);
                                } else {
                                    deleteMaterialButton.setVisible(true);
                                }
                                if (course.getUserkey() == participant.getUserkey()) {
                                    addStudentButton.setVisible(true);
                                }
                            }
                        }
                    }
                }
            }
        }


        participantsList.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                try {
                    participantService.getParticipantsOfCourse(course.getCoursekey());
                    if (course.getTyp().equals("Projektgruppe")) {
                        mainWindowController.openGroupChat(mainWindowController.loggedInUser, course, participantService.getCurrentParticipantList());
                    } else {
                        ObservableList<Participant> tmpList = FXCollections.observableArrayList();
                        tmpList.setAll(participantService.getCurrentParticipantList());
                        mainWindowController.openParticipantsList(course, mainWindowController);
                    }

                } catch (Exception e) {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Something went wrong");
                    errorAlert.setContentText("Please try again later");
                    errorAlert.showAndWait();
                    e.printStackTrace();

                }
            }
        });

        joinThisCourse.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Participant newparticipant = new Participant(user.getUserkey(), course.getCoursekey(), 0);
                    participantService.addNewParticipant((newparticipant));
                    initialize();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        cardsButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    cardService.getCardbyCourseKey(course.getCoursekey());
                    if (cardService.getListOfCards() == null || cardService.getListOfCards().size() == 0) {
                        FXMLLoader loader = new FXMLLoader();
                        loader.setLocation(getClass().getResource("/fxml/AddCard.fxml"));
                        AddCardController addCardController = new AddCardController(course);
                        addCardController.setMainWindowController(mainWindowController);
                        loader.setController(addCardController);
                        AnchorPane anchorPane1 = loader.load();
                        mainWindowController.tabMenu.getTabs().get(mainWindowController.tabMenu.getSelectionModel().getSelectedIndex()).setContent(anchorPane1);
                    } else {
                        mainWindowController.openCardTab(course, 0);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        addCourseMaterial.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                FileChooser fileChooser = new FileChooser();
                try {
                    //Set extension filter
                    FileChooser.ExtensionFilter extFilterPDF = new FileChooser.ExtensionFilter("PDF files (*.PDF)", "*.PDF");
                    FileChooser.ExtensionFilter extFilterpdf = new FileChooser.ExtensionFilter("pdf files (*.pdf)", "*.pdf");
                    FileChooser.ExtensionFilter extFilterdocx = new FileChooser.ExtensionFilter("docx files (*.docx)", "*.docx");
                    FileChooser.ExtensionFilter extFilterdoc = new FileChooser.ExtensionFilter("doc files (*.doc)", "*.doc");
                    fileChooser.getExtensionFilters().addAll(extFilterPDF, extFilterpdf, extFilterdocx, extFilterdoc);
                    //Show open file dialog
                    File file = fileChooser.showOpenDialog(null);
                    if (file != null) {
                        blobfile = Files.readAllBytes(file.toPath());
                        LearningMaterial newlearningmaterial = new LearningMaterial(file.getName(), course.getCoursekey(), blobfile);
                        learningMaterialService.addMaterial(newlearningmaterial);
                        initialize();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        addStudentButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/fxml/SearchStudent.fxml"));
                    SearchStudentController searchStudentController = new SearchStudentController(user, course, mainWindowController.tabMenu.getTabs().size() - 1);
                    searchStudentController.setMainWindowController(mainWindowController);
                    loader.setController(searchStudentController);
                    AnchorPane anchorPane1 = loader.load();
                    mainWindowController.tabMenu.getTabs().get(mainWindowController.tabMenu.getTabs().size() - 1).setContent(anchorPane1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        deleteMaterialButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (CourseMaterialList.getSelectionModel().getSelectedItem() != null) {

                        learningMaterialService.deleteMaterial(((LearningMaterial) CourseMaterialList.getSelectionModel().getSelectedItem()).getLearningmaterialkey());
                        initialize();

                    } else {
                        throw new NoMaterialSelectedException();
                    }
                } catch (NoMaterialSelectedException e) {
                    e.getMessage();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        CourseMaterialList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {

                        DirectoryChooser directoryChooser = new DirectoryChooser();
                        File selectedDircotry = directoryChooser.showDialog(null);
                        writeResponseBodyToDisk(learningMaterialService.downloadMaterial(((LearningMaterial) CourseMaterialList.getSelectionModel().getSelectedItem()).getLearningmaterialkey()), selectedDircotry, ((LearningMaterial) CourseMaterialList.getSelectionModel().getSelectedItem()).getName());

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        taskList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {
                        Task tmp = taskList.getSelectionModel().getSelectedItem();
                        taskService.getTaskByTaskKey(tmp.getTaskkey());

                        if (tmp.getTaskstate().equalsIgnoreCase("NA - nicht angefangen")) {
                            tmp.setTaskstate("IB - in Bearbeitung");
                        } else if (tmp.getTaskstate().equalsIgnoreCase("IB - in Bearbeitung")) {
                            tmp.setTaskstate("F - Fertig");
                        } else if (tmp.getTaskstate().equalsIgnoreCase("F - Fertig")) {
                            tmp.setTaskstate("IB - in Bearbeitung");
                        }
                        taskService.addTask(tmp);
                        mainWindowController.updateCourseTab(course);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        eventList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (mouseEvent.getClickCount() == 2) {
                        Event tmp = eventList.getSelectionModel().getSelectedItem();
                        mainWindowController.openEventTab(tmp, index);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        addEventButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    if (courseService.getCurrentCourse().getTyp().equals("Projektgruppe")) {
                        Stage primaryStage = new Stage();
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CreateTask.fxml"));
                        loader.setController(new CreateTaskController(course, primaryStage, mainWindowController));
                        Parent root = loader.load();
                        primaryStage.setScene(new Scene(root));
                        primaryStage.show();

                    } else {
                        mainWindowController.openAddEventTab(course.getCoursekey(), index);
                    }
                } catch (Exception e) {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Something went wrong");
                    errorAlert.setContentText("Please try again later");
                    errorAlert.showAndWait();
                    e.printStackTrace();
                }

            }
        });

        ButtonCourseViewAnswerQuiz.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openQuizPopUp(course, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        ButtonCourseViewCreateQuiz.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openAddQuiz(user, course);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        ButtonCourseViewCreateEvaluation.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openAddEvaluation(user, course);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        ButtonReadXMLFile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openAddQuizXML(user, course);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        ButtonQuizStatistik.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openQuizPopUp(course, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        this.updateMaterialList();
        ButtonCourseViewEvaluation.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    boolean evalExist = false;
                    quizService.getQuizByCourseKey(course.getCoursekey());
                    for (Quiz a : quizService.getQuizList()) {
                        if (a.getType().equals("eval")) {
                            mainWindowController.openEvalStatisics(course);
                            evalExist = true;
                        }
                    }
                    if (!evalExist) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Keine Evaluation vorhanden");
                        alert.setContentText("Es wurde noch keine Evaluation für diesen Kurs bereitgestellt");
                        alert.showAndWait();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        ButtonCourseViewAnswerEvaluation.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    quizService.getQuizByCourseKey(course.getCoursekey());
                    for (Quiz a : quizService.getQuizList()) {
                        if (a.getType().equals("eval")) {
                            mainWindowController.openAnswerEvaluation(a);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }


    //futurestud.io
    private void writeResponseBodyToDisk(Byte[] downloadMaterial, File file, String name) {
        try {
            File fileToSave = new File(file + File.separator + name);
            FileOutputStream tmp = new FileOutputStream(fileToSave);

            byte[] bytes = new byte[downloadMaterial.length];
            for (int i = 0; i < downloadMaterial.length; i++) {
                bytes[i] = downloadMaterial[i];
            }


            tmp.write(bytes);
            tmp.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void fillEventListView() throws IOException {
        try {
            eventList.getItems().clear();
            eventService.getALLEventsForCourse(course.getCoursekey());
            ObservableList<Event> events = FXCollections.observableArrayList();
            events.setAll(eventService.getEventList());

            for (Event event : events) {
                eventList.getItems().add(event);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public boolean isParticipant(List<Participant> participantsl, int userkey) {
        for (Participant participant : participantService.getCurrentParticipantList()) {
            if (participant.getUserkey() == user.getUserkey()) {
                return true;
            }
        }
        return false;
    }

    public void updateMaterialList() throws IOException {
        learningMaterialService.getMaterialbyCourseKey(course.getCoursekey());
        materialList.setAll(learningMaterialService.getListOfMaterial());
        getCourseMaterialList().setItems(materialList);
        eventService.getALLEventsForCourse(course.getCoursekey());
        ObservableList<Event> events = FXCollections.observableArrayList();
        events.setAll(eventService.getEventList());
        eventList.setItems(events);
    }


    public Button getJoinThisCourse() {
        return joinThisCourse;
    }

    public void setJoinThisCourse(Button joinThisCourse) {
        this.joinThisCourse = joinThisCourse;
    }

    public Button getAddCourseMaterial() {
        return addCourseMaterial;
    }

    public void setAddCourseMaterial(Button addCourseMaterial) {
        this.addCourseMaterial = addCourseMaterial;
    }

    public Label getCourseNameLabel() {
        return courseNameLabel;
    }

    public void setCourseNameLabel(Label courseNameLabel) {
        this.courseNameLabel = courseNameLabel;
    }

    public Button getAddStudentButton() {
        return addStudentButton;
    }

    public void setAddStudentButton(Button addStudentButton) {
        this.addStudentButton = addStudentButton;
    }

    public Button getParticipantsList() {
        return participantsList;
    }

    public void setParticipantsList(Button participantsList) {
        this.participantsList = participantsList;
    }

    public ListView getCourseMaterialList() {
        return CourseMaterialList;
    }

    public void setCourseMaterialList(ListView courseMaterialList) {
        CourseMaterialList = courseMaterialList;
    }

    public MainWindowController getMainWindowController() {
        return mainWindowController;
    }
}
