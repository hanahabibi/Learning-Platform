package controller;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import model.Course;
import service.CourseService;

import java.io.IOException;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

public class CourseViewAllController {

    MainWindowController mainWindowController;
    CourseService courseService;
    //Liste aller Veranstaltungen
    ObservableList<Course> ListAllCourses;
    //Liste die immer das letzte Ergebniss einer Suche ist, wird immer zur Darstellung der ListView benutzt
    ObservableList<Course> ListPreviouslyFetched;
    //ListForSearch enthält Liste mit allen Veranstaltungen im aktuellen ausgewählten Semester und wird nur zur Suche verwendet
    ObservableList<Course> ListForSearch;

    @FXML
    TextField TextFieldSearch;
    @FXML
    Button ButtonSearch;
    @FXML
    ListView ListViewCourse;
    @FXML
    Button AddCourseButton;
    @FXML
    ChoiceBox<String> CurrentSemesterChoiceBox;
    Calendar CurrentDate;

    //Konstruktor
    public CourseViewAllController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
        courseService = new CourseService();
        ListAllCourses = FXCollections.observableArrayList();
        ListPreviouslyFetched = FXCollections.observableArrayList();
        ListForSearch = FXCollections.observableArrayList();
        this.CurrentDate = Calendar.getInstance();
        this.CurrentSemesterChoiceBox = new ChoiceBox<String>();

    }


    @FXML
    public void initialize() throws IOException {
        //füllt CurrentSemesterChoicebox von diesem Semester ausgehend mit Auswahlmöglichkeiten für 6 weitere Semester
        CurrentSemesterChoiceBox.getItems().setAll(followingSemester(determineCurrentSemester()));
        //Erstes Semester wird immer das aktuelle Semester sein.
        CurrentSemesterChoiceBox.getSelectionModel().selectFirst();

        try {

            fetchListAllCourses();
            ListViewCourse.getItems().setAll(ListPreviouslyFetched);
            int[] currentSemesterArray = determineCurrentSemester();

            CurrentSemesterChoiceBox.setValue(currentSemesterToString(currentSemesterArray));
            //Fügt die Auswahl von 6 folgenden Semester nach dem aktuellen zur ChoiceBox, zusätzlich eine Option alle Semester hinzufügen
            CurrentSemesterChoiceBox.setItems(followingSemester(currentSemesterArray));
            //Fügt ChangeListener zur Choicebox hinzu
            CurrentSemesterChoiceBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                    //ChangeListener reagiert mit einem Aufruf von filterForSelectedSemester mit der neuen Selektion als Parameter
                    filterForSelectedSemester(t1);
                }
            });
            //setzt Selection der Choicebox per default zum aktuellen Semester
            CurrentSemesterChoiceBox.setValue(currentSemesterToString(currentSemesterArray));

            //Mit Bestätigung des Search Buttons wird eine Suche in der aktuellen Semestauswahl gestartet
            ButtonSearch.setOnAction(new EventHandler<ActionEvent>() {
                                         @Override
                                         public void handle(ActionEvent actionEvent) {
                                             searchFor(actionEvent);
                                         }
                                     }
            );
            //Bei Bestätigung des AddCourse Buttons wird die View des AddCourseControllers geöffnet
            AddCourseButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    try {
                        mainWindowController.openAddCourseTab();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            //Bei Doppelklick auf eien Veranstaltung in der ListView wird diese in einem neuen Tab geöffnet
            ListViewCourse.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    try {
                        if (!ListViewCourse.getItems().isEmpty()) {
                            if (mouseEvent.getClickCount() == 2) {
                                Course tmp = (Course) ListViewCourse.getSelectionModel().getSelectedItem();
                                mainWindowController.openNewCourseTab(tmp);

                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    //Erzeugt an Hand der Jahreszahlen in dem int[] currentSemesterArray einen String der das aktuelle Semester beschreibt
    public String currentSemesterToString(int[] currentSemesterArray) {
        String currentSemester;
        if (currentSemesterArray.length == 2) {
            currentSemester = "WS" + " " + currentSemesterArray[0] + "/" + currentSemesterArray[1];
        } else {
            currentSemester = "SS" + " " + currentSemesterArray[0];
        }
        return currentSemester;
    }

    //Updated die aktuelle Anzeige der Listview zur ListPreviouslyFetched. Und holt die neuste Version aller Veranstaltungen aus der Datenbank
    public void updateListView() {

        ListViewCourse.setItems(ListPreviouslyFetched);
        fetchListAllCourses();
    }

    //determines current semester
    public int[] determineCurrentSemester() {
        Calendar CurrentDateTemp = getCurrentDate();

        Calendar tempEndSS = Calendar.getInstance();
        Calendar tempStartSS = Calendar.getInstance();
        Calendar tempStartWS = Calendar.getInstance();
        Calendar tempEndWS = Calendar.getInstance();

        for (int i = 2020; i < 2030; i++) {
            //Sommersemester
            tempEndSS.set(i, 9, 30, 23, 59);
            tempStartSS.set(i, 4, 1, 0, 0);
            if (CurrentDateTemp.after(tempStartSS) && CurrentDateTemp.before(tempEndSS)) {
                String year = String.valueOf(i);
                year = year.substring(1);
                int yearInt = Integer.parseInt(year);
                int[] currentSemester = {yearInt};
                return currentSemester;
            }

            //wenn man noch im ersten jahr des wintersemesters ist
            tempStartWS.set(i, 10, 1, 0, 0);
            tempEndWS.set(i + 1, 3, 31, 23, 59);
            if (CurrentDateTemp.after(tempStartSS) && CurrentDateTemp.before(tempEndSS)) {
                String yearFirst = String.valueOf(i);
                String yearSecond = String.valueOf(i + 1);
                yearFirst = yearFirst.substring(1);
                yearSecond = yearSecond.substring(1);
                int yearFirstInt = Integer.parseInt(yearFirst);
                int yearSecondInt = Integer.parseInt(yearSecond);
                int[] currentSemester = {yearFirstInt, yearSecondInt};
                return currentSemester;
            }

            //wenn man im zweiten jahr des wintersemester ist
            tempStartWS.set(i - 1, 10, 1, 0, 0);
            tempEndWS.set(i, 3, 31, 23, 59);
            if (CurrentDateTemp.after(tempStartSS) && CurrentDateTemp.before(tempEndSS)) {
                String yearFirst = String.valueOf(i - 1);
                String yearSecond = String.valueOf(i);
                yearFirst = yearFirst.substring(1);
                yearSecond = yearSecond.substring(1);
                int yearFirstInt = Integer.parseInt(yearFirst);
                int yearSecondInt = Integer.parseInt(yearSecond);
                int[] currentSemester = {yearFirstInt, yearSecondInt};
                return currentSemester;
            }
        }
        int[] worst = new int[1];
        worst[0] = 0;
        return worst;
    }

    //setzt eine Liste aller Veranstaltungen die für das übergebende Semester angedacht sind in ListPreviouslyFetched und ListForSearch ein
    public void filterForSelectedSemester(String semester) {
        if (semester == null) {
            semester = currentSemesterToString(determineCurrentSemester());
        }
        //if no semester is selected, display all courses available
        if (semester.equals("Alle Semester")) {
            ListPreviouslyFetched.setAll(ListAllCourses);
            ListForSearch.setAll(ListAllCourses);
        } else {
            //filters out the courses in the right semester
            ObservableList<Course> CourseResult = FXCollections.observableArrayList();
            for (int i = 0; i < getListAllCourses().size(); i++) {
                if (getListAllCourses().get(i).getSemester().equals(semester)) {
                    CourseResult.add(getListAllCourses().get(i));
                }
            }

            ListPreviouslyFetched.setAll(CourseResult);
            ListForSearch.setAll(CourseResult);
        }

        updateListView();
    }

    //searches for the String in the TextFieldSearch
    public void searchFor(ActionEvent actionEvent) {
        CharSequence searchTerm = (CharSequence) TextFieldSearch.getText();
        ObservableList<Course> tempList = FXCollections.observableArrayList();
        for (int i = 0; i < getListForSearch().size(); i++) {
            if (getListForSearch().get(i).getName().toLowerCase().contains(searchTerm.toString().toLowerCase())) {
                tempList.add(getListForSearch().get(i));
            }
        }
        setListPreviouslyFetched(tempList);
        updateListView();
    }

    //Sets ListAllCourses to all Courses in the Database
    public void fetchListAllCourses() {
        try {
            courseService.getAll();
            ListAllCourses.setAll(courseService.getCourseList());
            sortListAllCourses();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Sortiert alle Veranstaltungen in der ListAllCourses Chronologisch
    public void sortListAllCourses() {

        ObservableList<Course> result = FXCollections.observableArrayList();
        int[] currentSemesterArray = determineCurrentSemester();
        List<String> allSemesterChoices = new LinkedList<String>();
        boolean SSOrWS;
        if (currentSemesterArray.length == 2) {
            SSOrWS = true;
        } else SSOrWS = false;

        for (int i = 0; i <= 8; i++) {

            if (SSOrWS) {
                allSemesterChoices.add("WS " + (currentSemesterArray[0] + i) + "/" + (currentSemesterArray[0] + i + 1));
                allSemesterChoices.add("SS " + (currentSemesterArray[0] + i));
            } else {
                allSemesterChoices.add("SS " + (currentSemesterArray[0] + i));
                allSemesterChoices.add("WS " + (currentSemesterArray[0] + i) + "/" + (currentSemesterArray[0] + i + 1));
            }
        }

        for (String j : allSemesterChoices) {
            for (int i = 0; i < getListAllCourses().size(); i++) {
                if (getListAllCourses().get(i).getSemester().equals(j)) {
                    result.add(getListAllCourses().get(i));
                }
            }
        }
        ListAllCourses.setAll(result);
    }

    //Gibt eine Observable List <String> mit den nächsten 6 Semester und dem Eintrag "Alle Semester" ausgehend von dem aktuelllen Semester zurück
    public ObservableList<String> followingSemester(int[] currentSemesterArray) {
        ObservableList<String> allSemesterChoices = FXCollections.observableArrayList();
        boolean SSOrWS;
        if (currentSemesterArray.length == 2) {
            SSOrWS = true;
        } else SSOrWS = false;

        for (int i = 0; i <= 3; i++) {

            if (SSOrWS) {
                allSemesterChoices.add("WS " + (currentSemesterArray[0] + i) + "/" + (currentSemesterArray[0] + i + 1));
                allSemesterChoices.add("SS " + (currentSemesterArray[0] + i));
            } else {
                allSemesterChoices.add("SS " + (currentSemesterArray[0] + i));
                allSemesterChoices.add("WS " + (currentSemesterArray[0] + i) + "/" + (currentSemesterArray[0] + i + 1));
            }
        }
        allSemesterChoices.add("Alle Semester");
        return allSemesterChoices;
    }


    //Getter Setter
    public void setListPreviouslyFetched(ObservableList<Course> listPreviouslyFetched) {
        ListPreviouslyFetched = listPreviouslyFetched;
    }

    public ObservableList<Course> getListAllCourses() {
        return ListAllCourses;
    }

    public Calendar getCurrentDate() {
        return CurrentDate;
    }

    public ObservableList<Course> getListForSearch() {
        return ListForSearch;
    }

}
