package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.Card;
import model.Course;

import service.CardService;
import service.CourseService;

import java.io.IOException;

public class AddCardController {

    public MainWindowController mainWindowController;
    public CourseService courseService;
    public CardService cardService;
    public Course course;

    @FXML
    public TextField nameText;
    @FXML
    public TextArea explanationText;
    @FXML
    public Button saveButton;
    @FXML
    public Button closeButton;


    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public AddCardController(Course course) {
        this.course = course;
        cardService = new CardService();
    }

    public void initialize() throws IOException {

        saveButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    String cname = nameText.getText();
                    String cexplanation = explanationText.getText();

                    if (cname != null && cexplanation != null) {
                        Card newcard = new Card(cname, cexplanation, course.getCoursekey());
                        cardService.addCard(newcard);
                        mainWindowController.updateCourseTab(course);
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        });

        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.updateCourseTab(course);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        });
    }

}
