package controller;

import exception.LecturerNotFoundException;
import exception.StudentNotFoundException;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import model.Lecturer;
import model.Student;
import model.User;
import service.LecturerService;
import service.StudentService;
import service.UserService;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;


public class EditProfileController {

    //views
    @FXML
    private Label firstNameLabel;
    @FXML
    private Label lastNameLabel;
    @FXML
    private Label matNumberLabel;
    @FXML
    private Label matNumber;
    @FXML
    private Label subject_institute_Label;
    @FXML
    private Label instituteLabel;
    @FXML
    private Label researchAreaLabel;
    @FXML
    private Label emailAddressLabel;
    @FXML
    private TextField addressField;
    @FXML
    private TextField postalCodeField;
    @FXML
    private TextField cityField;
    @FXML
    private TextField subject_institute_Field;
    @FXML
    private TextField researchAreaField;
    @FXML
    private Button changePasswordButton;
    @FXML
    private Button changeProfilePicButton;
    @FXML
    private Button closeButton;
    @FXML
    public Label ErrorAddress;
    @FXML
    public Label ErrorPostalCode;
    @FXML
    public Label ErrorCity;
    @FXML
    public Label Error_Subject_Institute;
    @FXML
    public Label ErrorResearchArea;
    @FXML
    public ImageView profilePicImageView;


    User loggedInUser;
    public byte[] newProfilePic;

    UserService userService = new UserService();
    StudentService studentService = new StudentService();
    LecturerService lecturerService = new LecturerService();

    //parentcontroller
    private MainWindowController mainWindowController;


    public EditProfileController(User loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    @FXML
    public void initialize() throws IOException, LecturerNotFoundException {
        User currentUser = mainWindowController.loggedInUser;
        String street = addressField.getText();
        String postalCode = postalCodeField.getText();
        String city = cityField.getText();

        //alle Nutzerangaben werden personalisiert
        firstNameLabel.setText(currentUser.getFirstname());
        lastNameLabel.setText(currentUser.getLastname());
        addressField.setText(currentUser.getAddress());
        postalCodeField.setText(currentUser.getPostalcode());
        cityField.setText(currentUser.getCity());
        emailAddressLabel.setText(currentUser.getEmail());
        if (currentUser.getProfilepicture() != null) {
            ByteArrayInputStream bis = new ByteArrayInputStream(currentUser.getProfilepicture());
            profilePicImageView.setImage(SwingFXUtils.toFXImage(ImageIO.read(bis), null));
        }
        //view wird für Studenten angepasst
        if (currentUser instanceof Student) {
            researchAreaLabel.setVisible(false);
            researchAreaField.setVisible(false);
            String temp = String.valueOf(((Student) currentUser).getMatnumber());
            matNumber.setText(addZeros(((Student) currentUser).getMatnumber()));
            subject_institute_Label.setText("Studienfach");
            subject_institute_Field.setText(((Student) currentUser).getSubject());
        }
        //view wird für Lehrperson angepasst
        else if (currentUser instanceof Lecturer) {
            matNumberLabel.setVisible(false);
            matNumber.setVisible(false);
            researchAreaField.setText(((Lecturer) currentUser).getResearch());
            subject_institute_Label.setText("Lehrstuhl");
            subject_institute_Field.setText(((Lecturer) currentUser).getInstitute());
            lecturerService.getLecturerByUserKey(currentUser.getUserkey());
        } else {
        }


        //wird ausgeführt, wenn der Schließen Button gedrückt wird
        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                boolean streetBool = false;
                boolean postalCodeBool = false;
                boolean cityBool = false;
                boolean subjectBool = false;
                boolean instituteBool = false;
                boolean researchAreaBool = false;
                try {
                    //prüft, ob Eingaben den Vorgaben entsprechen
                    if (street.equals("")) {
                        ErrorAddress.setText("Bitte geben Sie eine Adresse an.");
                    } else {
                        streetBool = true;
                    }

                    if (!postalCode.matches("^\\d{5}(?:[-\\s]\\d{5})?$")) {
                        ErrorPostalCode.setText("*ungültiger Wert");
                    } else {
                        postalCodeBool = true;
                    }

                    if (!city.matches("^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$")) {
                        ErrorCity.setText("*ungültiger Wert");
                    } else {
                        cityBool = true;
                    }

                    //User bzw. Studenten Angaben werden in Datenbank aktualisiert
                    if (currentUser instanceof Student) {

                        //prüft, ob textfeld ausgefüllt ist
                        if (!subject_institute_Field.getText().matches("")) {
                            subjectBool = true;
                        } else {
                            Error_Subject_Institute.setText("Bitte geben Sie ein Studienfach an");
                        }

                        //wenn alle Textfelder richtig ausgefüllt sind
                        if (cityBool && postalCodeBool && streetBool && subjectBool) {

                            //aktualisiert den Nutzer in der Nutzer Tabelle
                            userService.getUser(currentUser.getUserkey());
                            userService.getCurrentUser().setAddress(adjustInputFormat(addressField.getText()));
                            userService.getCurrentUser().setPostalcode(adjustInputFormat(postalCodeField.getText()));
                            userService.getCurrentUser().setCity(adjustInputFormat(cityField.getText()));
                            if (newProfilePic != null) {
                                userService.getCurrentUser().setProfilepicture(newProfilePic);
                            } else {
                            }
                            //aktualisiert den student in der student Tabelle
                            studentService.getStudentByUserKey(currentUser.getUserkey());
                            studentService.getCurrentStudent().setSubject(adjustInputFormat(subject_institute_Field.getText()));
                            userService.setUser(userService.getCurrentUser());
                            studentService.setStudent(studentService.getCurrentStudent());
                            studentService.getCurrentStudent().join(userService.getCurrentUser());
                            mainWindowController.setLoggedInUser(studentService.getCurrentStudent());
                            mainWindowController.openProfileTab();
                        } else {
                        }
                        }



                    //User bzw. Lehrperson Angaben werden in Datenbank aktualisiert
                    else if (currentUser instanceof Lecturer) {

                        //prüft, ob Textfelder ausgefüllt sind
                        if (!subject_institute_Field.getText().matches("")) {
                            instituteBool = true;
                        } else {
                            Error_Subject_Institute.setText("Bitte geben Sie einen Lehrstuhl an.");
                        }
                        if (!researchAreaField.getText().matches("")) {
                            researchAreaBool = true;
                        } else {
                            ErrorResearchArea.setText("Bitte geben Sie ein Forschungsgebiet an.");
                        }

                        //wenn alle Textfelder richtig ausgefüllt sind
                        if (cityBool && postalCodeBool && streetBool && instituteBool && researchAreaBool) {

                            //aktualisiert den Nutzer in der Nutzer Tabelle
                            userService.getUser(currentUser.getUserkey());
                            userService.getCurrentUser().setAddress(adjustInputFormat(addressField.getText()));
                            userService.getCurrentUser().setPostalcode(adjustInputFormat(postalCodeField.getText()));
                            userService.getCurrentUser().setCity(adjustInputFormat(cityField.getText()));
                            if (newProfilePic != null) {
                                userService.getCurrentUser().setProfilepicture(newProfilePic);
                            } else {
                            }
                            //aktualisiert den Lecturer in der Lecturer Tabelle
                            lecturerService.getLecturerByUserKey(currentUser.getUserkey());
                            lecturerService.getCurrentLecturer().setInstitute(adjustInputFormat(subject_institute_Field.getText()));
                            lecturerService.getCurrentLecturer().setResearch(adjustInputFormat(researchAreaField.getText()));
                            userService.setUser(userService.getCurrentUser());
                            lecturerService.setLecturer(lecturerService.getCurrentLecturer());
                            lecturerService.getCurrentLecturer().join(userService.getCurrentUser());
                            mainWindowController.setLoggedInUser(lecturerService.getCurrentLecturer());
                            mainWindowController.openProfileTab();
                            System.out.println(researchAreaField.getText());
                            System.out.println(lecturerService.getCurrentLecturer().getResearch());

                        }
                    } else {
                    }

                } catch (IOException | StudentNotFoundException | LecturerNotFoundException e) {
                    System.out.println(e.getMessage());
                }
            }
        });

        //wird ausgeführt, wenn der Ändern Button gedrückt wird
        changePasswordButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.openPasswordTab();
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        });

        //wird ausgeführt, wenn der Bearbeiten Button gedrückt wird
        changeProfilePicButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();
                try {
                    //filtert Dateiformat
                    FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.JPG)", "*.JPG");
                    FileChooser.ExtensionFilter extFilterjpg = new FileChooser.ExtensionFilter("jpg files (*.jpg)", "*.jpg");
                    FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.PNG)", "*.PNG");
                    FileChooser.ExtensionFilter extFilterpng = new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
                    fileChooser.getExtensionFilters().addAll(extFilterJPG, extFilterjpg, extFilterPNG, extFilterpng);

                    //Show open file dialog
                    File file = fileChooser.showOpenDialog(null);

                    //aktualisiert ImageView auf das ausgewählte Bild
                    if (file != null) {
                        newProfilePic = Files.readAllBytes(file.toPath());
                        ByteArrayInputStream bis = new ByteArrayInputStream(newProfilePic);
                        profilePicImageView.setImage(SwingFXUtils.toFXImage(ImageIO.read(bis), null));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    //bringt Matrikelnummer in das richtige Format
    public String addZeros(int matrikelnummer) {

        if (matrikelnummer < 10) {
            return "000000" + matrikelnummer;
        } else if (matrikelnummer < 100) {
            return "00000" + matrikelnummer;
        } else if (matrikelnummer < 1000) {
            return "0000" + matrikelnummer;
        } else if (matrikelnummer < 10000) {
            return "000" + matrikelnummer;
        } else if (matrikelnummer < 100000) {
            return "00" + matrikelnummer;
        } else if (matrikelnummer < 1000000) {
            return "0" + matrikelnummer;
        } else {
            return String.valueOf(matrikelnummer);
        }
    }

    //korrigiert das Format der Textfeldeingaben
    public static String adjustInputFormat(String input) {

        String corrected = input;

        corrected = firstLetterUpperCase(corrected);
        corrected = addPeriod(corrected);
        corrected = addSpace(corrected);

        return corrected;
    }

    //fügt Leerzeichen zwischen Straße und Hausnummer ein
    public static String addSpace(String input) {

        StringBuffer inputBuffer = new StringBuffer(input);

        //macht gar nichts, wenn String Postleitzahl ist
        if (input.matches("^\\d{5}(?:[-\\s]\\d{5})?$")) {

        } else {
            for (int i = 0; i < 10; i++) {
                String temp = String.valueOf(i);
                if (input.contains(temp)) {
                    int index = inputBuffer.indexOf(temp);
                    String checkChar = String.valueOf(inputBuffer.charAt(index - 1));
                    if (checkChar.matches("[.]") || checkChar.matches("[a-zA-ZäöüÄÖÜß]")) {

                        inputBuffer.insert(index, " ");
                    }
                }
            }
        }
        return String.valueOf(inputBuffer);
    }

    //setzt Punkt nach abgekürzten Straßennamen
    public static String addPeriod(String input) {

        StringBuffer inputBuffer = new StringBuffer(input);
        if (input.contains("str")) {
            int index = inputBuffer.lastIndexOf("str");
            String checkChar = String.valueOf(inputBuffer.charAt(index + 3));
            if (!checkChar.matches("[.]") && !checkChar.matches("[a-zA-ZäöüÄÖÜß]")) {
                inputBuffer.insert(index + 3, '.');
            }
        }
        return String.valueOf(inputBuffer);
    }

    //schreibt den ersten Buchstaben eines Wortes groß
    public static String firstLetterUpperCase(String input) {

        char[] inputChars = input.toCharArray();
        inputChars[0] = Character.toUpperCase(inputChars[0]);
        for (int i = 0; i < inputChars.length; i++) {
            if (inputChars[i] == '-' || inputChars[i] == ' ') {
                if (i + 1 != inputChars.length) {
                    inputChars[i + 1] = Character.toUpperCase(inputChars[i + 1]);
                }
            }
        }
        return String.valueOf(inputChars);
    }
}


