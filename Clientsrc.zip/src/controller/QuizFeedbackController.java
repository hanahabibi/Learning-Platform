package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Course;
import model.Questions;
import model.Quiz;
import model.User;
import javafx.scene.Node;
import service.QuizService;
import service.StringService;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class QuizFeedbackController {

    QuizService quizService;
    Quiz quiz;

    public User user;
    public ArrayList<Questions> questions;
    private MainWindowController mainWindowController;
    float result = 0;
    int bestanden = 0;

    @FXML
    public javafx.scene.control.Label LabelErreichtePunkte, LabelBestanden;
    @FXML
    public ListView<String> ListViewOverview;

    public QuizFeedbackController(ArrayList<Questions> questions, Quiz quiz, User user) {
        this.questions = questions;
        this.quiz = quiz;
        this.user = user;
        quizService = new QuizService();
    }


    public void initialize() throws IOException {
        StringBuilder tmp = new StringBuilder();
        if (quiz.getWhoworkedonthatquiz().equals("")) {
            for (Questions a : questions) {
                tmp.append("(0,0,0,0)-");
            }
            tmp.deleteCharAt(tmp.lastIndexOf("-"));
            tmp.append("/0@0+0");
        } else {
            tmp.append(quiz.getWhoworkedonthatquiz());
        }

        StringService tmpStringService = new StringService(tmp.toString());
        for (int i = 0; i < questions.size(); i++) {

            String userAntwort = questions.get(i).getUserAntwort();
            String korrekteAntwort = questions.get(i).getRichtigeAntwort();
            String correkt = "";

            if (userAntwort.equals(korrekteAntwort)) {
                result = result + 1;
                correkt = " Korrekt!";
                switch (userAntwort) {
                    case "A":
                        tmpStringService.addFragenResult("(1,0,0,0)", i);
                        break;
                    case "B":
                        tmpStringService.addFragenResult("(0,1,0,0)", i);
                        break;
                    case "C":
                        tmpStringService.addFragenResult("(0,0,1,0)", i);
                        break;
                    case "D":
                        tmpStringService.addFragenResult("(0,0,0,1)", i);
                        break;
                }
            } else {
                correkt = " Falsch!";
            }


            ListViewOverview.getItems().add("Frage: " + (i + 1) + correkt + "\n" + questions.get(i).getFrage());
        }


        LabelErreichtePunkte.setText(result + " / " + (float) questions.size());

        if (result >= Math.ceil((float) questions.size() / 2)) {
            LabelBestanden.setText("Bestanden");
            bestanden = bestanden + 1;
        } else {
            LabelBestanden.setText("Nicht bestanden");
        }

        boolean vorhanden = false;
        for (int i = 0; i < tmpStringService.getUserAtempts().length; i++) {

            if (tmpStringService.getUserAtempts()[i][0] == user.getUserkey()) {
                    tmpStringService.getUserAtempts()[i][1] = tmpStringService.getUserAtempts()[i][1] + 1;
                    if (tmpStringService.getUserAtempts()[i][2] == 0) {
                        tmpStringService.getUserAtempts()[i][2] = bestanden;
                    }
                vorhanden = true;
            }
        }


        if (!vorhanden) {
            tmpStringService.extendUserAtempts(user.getUserkey(), bestanden);
        }

        quiz.setWhoworkedonthatquiz(tmpStringService.buildString());
        quizService.addQuiz(quiz);




    }

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }
}
