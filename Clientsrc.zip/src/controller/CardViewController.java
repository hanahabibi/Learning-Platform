package controller;

import javafx.animation.FillTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.*;
import javafx.util.Duration;
import model.Card;
import model.Course;
import service.CardService;
import service.CourseService;

import java.io.IOException;

public class CardViewController {


    public MainWindowController mainWindowController;
    public CourseService courseService;
    public CardService cardService;
    public Course course;
    int index;
    ObservableList<Card> cardlist = FXCollections.observableArrayList();

    @FXML
    public Label cardText;
    @FXML
    public Label explanationLabel;
    @FXML
    public Rectangle cardShape;
    @FXML
    public Button nextCardButton;
    @FXML
    public Button lastCardButton;
    @FXML
    public Button closeButton;

    public void setMainWindowController(MainWindowController mainWindowController) {
        this.mainWindowController = mainWindowController;
    }

    public CardViewController(Course course, int index) {
        this.course = course;
        this.index = index;
        cardService = new CardService();
    }

    public void initialize() throws IOException {

        cardService.getCardbyCourseKey(course.getCoursekey());
        cardlist.setAll(cardService.getListOfCards());
        Card current = cardlist.get(index);
        cardText.setAlignment(Pos.CENTER);
        cardText.setText(current.getCardname());
        explanationLabel.setVisible(false);

        cardShape.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent actionEvent) {
                if (cardText.getText().equals(current.getCardname())) {
                    explanationLabel.setVisible(true);
                    cardText.setText(current.getCardexplanation());
                    FillTransition fillTransition = new FillTransition(Duration.INDEFINITE, cardShape, Color.ANTIQUEWHITE, Color.ALICEBLUE);
                    fillTransition.play();
                } else {
                    explanationLabel.setVisible(false);
                    cardText.setText(current.getCardname());
                    FillTransition fillTransition = new FillTransition(Duration.INDEFINITE, cardShape, Color.ALICEBLUE, Color.ANTIQUEWHITE);
                    fillTransition.play();
                }
            }
        });

        nextCardButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if ((index + 1) < cardlist.size()) {
                        mainWindowController.openCardTab(course, index + 1);
                    } else {
                        FXMLLoader loader = new FXMLLoader();
                        loader.setLocation(getClass().getResource("/fxml/AddCard.fxml"));
                        AddCardController addCardController = new AddCardController(course);
                        addCardController.setMainWindowController(mainWindowController);
                        loader.setController(addCardController);
                        AnchorPane anchorPane1 = loader.load();
                        mainWindowController.tabMenu.getTabs().get(mainWindowController.tabMenu.getSelectionModel().getSelectedIndex()).setContent(anchorPane1);
                        ;
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        });

        lastCardButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    if ((index - 1) != -1)
                        mainWindowController.openCardTab(course, index - 1);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        });


        closeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mainWindowController.updateCourseTab(course);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        });
    }

}
