package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Lecturer;
import model.Student;
import model.User;
import service.UserService;

import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;


public class CreateProfileController extends Child {

    private final User user;
    public Stage stage;
    public Student student; //leerer student
    public Lecturer lecturer;//leerer lecturer
    public UserService userService;
    public MainWindowController mainWindowController;
    public byte[] profilePic;
    public ObservableList<String> emailAddressList = FXCollections.observableArrayList("@stud.projectx.de", "@projectx.de");

    @FXML
    public ImageView profilePicImageVIew;
    @FXML
    public TextField UserInputFirstName;
    @FXML
    public TextField UserInputLastName;
    @FXML
    public TextField UserInputStreet;
    @FXML
    public TextField UserInputPostalCode;
    @FXML
    public TextField UserInputCity;
    @FXML
    public TextField UserInputEmailAdress;
    @FXML
    public Button OnwardsButton;
    @FXML
    public Button BackButton;
    @FXML
    public Button UploadPictureButton;
    @FXML
    public Label ErrorFirstName;
    @FXML
    public Label ErrorLastName;
    @FXML
    public Label ErrorAddress;
    @FXML
    public Label ErrorPostalCode;
    @FXML
    public Label ErrorCity;
    @FXML
    public Label ErrorEmail;
    @FXML
    public Label ErrorEmail1;
    @FXML
    public Label ErrorEmail2;
    @FXML
    public Label ErrorRegister;
    @FXML
    public CheckBox studentCheckBox;
    @FXML
    public CheckBox lecturerCheckBox;

    @FXML
    public void initialize() throws InterruptedException, IOException {


        if (user != null) {
            UserInputFirstName.setText(user.getFirstname());
            UserInputLastName.setText(user.getLastname());
            UserInputCity.setText(user.getCity());
            UserInputPostalCode.setText(user.getPostalcode());
            UserInputStreet.setText(user.getAddress());
        }

        OnwardsButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String firstName = EditProfileController.adjustInputFormat(UserInputFirstName.getText());
                String lastName = EditProfileController.adjustInputFormat(UserInputLastName.getText());
                String street = EditProfileController.adjustInputFormat(UserInputStreet.getText());
                String postalCode = UserInputPostalCode.getText();
                String city = EditProfileController.adjustInputFormat(UserInputCity.getText());
                String emailAddress = UserInputEmailAdress.getText();

                boolean firstNameBool = false;
                boolean lastNameBool = false;
                boolean streetBool = false;
                boolean postalCodeBool = false;
                boolean cityBool = false;
                boolean emailBool = false;

                try {
                    if (!firstName.matches("^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$")) {
                        ErrorFirstName.setText("*nicht gültiger Wert");
                    } else {
                        firstNameBool = true;
                    }

                    if (!lastName.matches("^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$")) {
                        ErrorLastName.setText("*nicht gültiger Wert");
                    } else {
                        lastNameBool = true;
                    }

                    if (street.equals("")) {
                        ErrorAddress.setText("*nicht gültiger Wert");
                    } else {
                        streetBool = true;
                    }

                    if (!postalCode.matches("^\\d{5}(?:[-\\s]\\d{5})?$")) {
                        ErrorPostalCode.setText("*nicht gültiger Wert");
                    } else {
                        postalCodeBool = true;
                    }

                    if (!city.matches("^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$")) {
                        ErrorCity.setText("*nicht gültiger Wert");
                    } else {
                        cityBool = true;
                    }

                   /*if (!emailAddress.matches("(\\w)+[.](\\w)+[\\@](\\w)+.(\\w)+")) {
                        ErrorEmail.setText("*falsches Format:");
                        ErrorEmail1.setText("vorname.nachname erwartet");
                        ErrorEmail2.setText("");
                    } else {*/
                        userService.getUserByEmail(emailAddress);
                        if (userService.getCurrentUser().getEmail() == null) {
                            emailBool = true;
                        } else {
                            ErrorEmail.setText("User exisitiert schon");
                            ErrorEmail1.setText("Versuchen Sie sich einzuloggen,");
                            ErrorEmail2.setText("oder nehmen Sie eine andere Email");
                        }
                    // }

                    if (firstNameBool && lastNameBool && streetBool && postalCodeBool && cityBool && emailBool) {


                        if (profilePic == null) {
                            String filename = "Client/src/resources/ProfilAvatar.png";
                            String directory = System.getProperty("user.dir");
                            Path path = Path.of(directory + File.separator + filename);
                            profilePic = Files.readAllBytes(path);
                            ByteArrayInputStream bis = new ByteArrayInputStream(profilePic);
                            System.out.println(path);
                            profilePicImageVIew.setImage(SwingFXUtils.toFXImage(ImageIO.read(bis), null));
                        }
                        if (studentCheckBox.isSelected()) {
                            student = new Student(emailAddress, firstName, lastName, profilePic, null, street, postalCode, city, null, "", "");
                            student.setIsstudent(1);
                            loadRoleWindowWithUser(student, stage, "/fxml/RoleWindow.fxml");


                        } else if (lecturerCheckBox.isSelected()) {

                            lecturer = new Lecturer(emailAddress, firstName, lastName, profilePic, null, street, postalCode, city, null, null);
                            lecturer.setIsstudent(0);
                            loadRoleWindowWithUser(lecturer, stage, "/fxml/RoleWindow.fxml");

                        }


                    } else {
                        ErrorRegister.setText("Unvollständige Angaben");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        BackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/StartWindow.fxml"));
                    loader.setController(new StartWindowController(stage));
                    Parent root = null;
                    root = loader.load();
                    stage.setScene(new Scene(root));
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        UploadPictureButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();
                try {
                    //Set extension filter
                    FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.JPG)", "*.JPG");
                    FileChooser.ExtensionFilter extFilterjpg = new FileChooser.ExtensionFilter("jpg files (*.jpg)", "*.jpg");
                    FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.PNG)", "*.PNG");
                    FileChooser.ExtensionFilter extFilterpng = new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
                    fileChooser.getExtensionFilters().addAll(extFilterJPG, extFilterjpg, extFilterPNG, extFilterpng);
                    //Show open file dialog
                    File file = fileChooser.showOpenDialog(null);
                    if (file != null) {
                        profilePic = Files.readAllBytes(file.toPath());
                        ByteArrayInputStream bis = new ByteArrayInputStream(profilePic);
                        profilePicImageVIew.setImage(SwingFXUtils.toFXImage(ImageIO.read(bis), null));
                    }

                    for (byte a : profilePic
                    ) {
                        System.out.print(a + ",");

                    }
                    System.out.println();

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public CreateProfileController(Stage stage, User user) {
        this.stage = stage;
        this.user = user;
        File defaultProfilePic = new File("/resources/ProfilAvatar.png");
        try {
            profilePic = Files.readAllBytes(defaultProfilePic.toPath());
        } catch (IOException e) {
            System.out.println("Datei nicht gefunden!");
        }

        userService = new UserService();
    }


    @Override
    public void setParent(MainWindowController parentController) {
        this.mainWindowController = parentController;
    }


    public void loadRoleWindowWithUser(User user, Stage stage, String path) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(path));
        loader.setController(new RoleWindowController(user, stage));
        Parent root = loader.load();
        stage.setScene(new Scene(root));
    }

}
