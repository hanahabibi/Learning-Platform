package controller;

import javafx.scene.Node;

public abstract class Child {
    public abstract void setParent(MainWindowController parentController);
}
