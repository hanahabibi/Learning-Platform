package model;
// @author Kuri

public class Student extends User {

    public int matnumber;
    public String subject;
    public String friends;
    public String fstate;

    public Student(String eMail, String firstName, String lastName, byte[] placeHolderImage, String passWord, String address, String postalcode, String city, String subject, String friends, String fstate) {
        super(eMail, firstName, lastName, placeHolderImage, passWord, address, postalcode, city, 1);
        this.subject = subject;
        this.friends = friends;
        this.fstate = fstate;
    }

    public Student() {
    }


    public int getMatnumber() {
        return matnumber;
    }

    public void setMatnumber(int matnumber) {
        this.matnumber = matnumber;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFriends() {
        return friends;
    }

    public void setFriends(String friends) {
        this.friends = friends;
    }

    public String getFstate() {
        return fstate;
    }

    public void setFstate(String fstate) {
        this.fstate = fstate;
    }

    @Override
    public String toString() {
        return getFirstname() + " " + getLastname();
    }
}
