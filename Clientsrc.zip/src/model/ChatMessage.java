package model;


import java.util.HashMap;

public class ChatMessage {

    private int messageid;
    private String chatid;
    private int senderid;
    private int receiverid;
    private String content;
    private String timestamp;

    public int getMessageid() {
        return messageid;
    }

    public void setMessageid(int messageid) {
        this.messageid = messageid;
    }

    public int getReceiverid() {
        return receiverid;
    }

    public void setReceiverid(int receiverid) {
        this.receiverid = receiverid;
    }

    public ChatMessage(String chatid, int senderid, int receiverid, String content, String timestamp) {
        this.chatid = chatid;
        this.senderid = senderid;
        this.receiverid = receiverid;
        this.content = content;
        this.timestamp = timestamp;
    }

    public ChatMessage() {
    }

    public int getId() {
        return messageid;
    }

    public void setId(int id) {
        this.messageid = id;
    }

    public String getChatid() {
        return chatid;
    }

    public void setChatid(String chatid) {
        this.chatid = chatid;
    }

    public int getSenderid() {
        return senderid;
    }

    public void setSenderid(int senderid) {
        this.senderid = senderid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }


}
