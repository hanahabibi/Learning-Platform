package model;

public class Quiz {
    int quizid;
    int coursekey;
    byte[] quiz;
    String whoworkedonthatquiz;
    String type;

    public int getQuizid() {
        return quizid;
    }

    public void setQuizid(int quizid) {
        this.quizid = quizid;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public byte[] getQuiz() {
        return quiz;
    }

    public void setQuiz(byte[] quiz) {
        this.quiz = quiz;
    }

    public String getWhoworkedonthatquiz() {
        return whoworkedonthatquiz;
    }

    public void setWhoworkedonthatquiz(String whoworkedonthatquiz) {
        this.whoworkedonthatquiz = whoworkedonthatquiz;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
