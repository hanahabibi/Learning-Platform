package model;

public class Chat {

    private String chatkey;
    private String type;
    private int keyuserone;
    private int keyusertwo;
    private int key;


    public Chat(String chatkey, String type, int keyuserone, int keyusertwo) {
        this.chatkey = chatkey;
        this.type = type;
        this.keyuserone = keyuserone;
        this.keyusertwo = keyusertwo;
    }

    public Chat() {

    }


    public String getChatkey() {
        return chatkey;
    }

    public void setChatkey(String chatkey) {
        this.chatkey = chatkey;
    }

    public int getKeyuserone() {
        return keyuserone;
    }

    public void setKeyuserone(int keyuserone) {
        this.keyuserone = keyuserone;
    }

    public int getKeyusertwo() {
        return keyusertwo;
    }

    public void setKeyusertwo(int keyusertwo) {
        this.keyusertwo = keyusertwo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }


}

