package model;

public class User {
    private int userkey;
    private String firstname;
    private String lastname;
    private String password;
    private String email;
    private byte[] profilepicture;
    private String address;
    private String postalcode;
    private String city;
    private int isstudent;


    public User(String email, String firstname, String lastname, byte[] profilepicture, String password, String address, String postalcode, String city, Integer isstudent) {
        this.setEmail(email);
        this.setFirstname(firstname);
        this.setLastname(lastname);
        this.setProfilepicture(profilepicture);
        this.setPassword(password);
        this.setAddress(address);
        this.setPostalcode(postalcode);
        this.setCity(city);
        this.setIsstudent(isstudent);
    }

    public User() {
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userkey) {
        this.userkey = userkey;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte[] getProfilepicture() {
        return profilepicture;
    }

    public void setProfilepicture(byte[] profilepicture) {
        this.profilepicture = profilepicture;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getIsstudent() {
        return isstudent;
    }

    public void setIsstudent(int isstudent) {
        this.isstudent = isstudent;
    }

    @Override
    public String toString() {
        return firstname + " " + lastname + " /" + email;
    }

    public void join(User currentUser) {
        this.setFirstname(currentUser.getFirstname());
        this.setLastname(currentUser.getLastname());
        this.setEmail(currentUser.getEmail());
        this.setPassword(currentUser.getPassword());
        this.setAddress(currentUser.getAddress());
        this.setPostalcode(currentUser.getPostalcode());
        this.setCity(currentUser.getCity());
        this.setProfilepicture(currentUser.getProfilepicture());
        this.setIsstudent(currentUser.getIsstudent());
        this.userkey = currentUser.getUserkey();
    }

}
