package model;

public class Literature {



    public Literature() {

    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getPages() {
        return pages;
    }

    public void setPages(String pages) {
        this.pages = pages;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getJournal() {
        return journal;
    }

    public void setJournal(String journal) {
        this.journal = journal;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getBooktitle() {
        return booktitle;
    }

    public void setBooktitle(String booktitle) {
        this.booktitle = booktitle;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrldate() {
        return urldate;
    }

    public void setUrldate(String urldate) {
        this.urldate = urldate;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    String type;
    String title;
    String author;
    String publisher;
    String year;
    String pages;
    String volume;
    String number;
    String isbn;
    String journal;
    String doi;
    String keywords;
    String booktitle;
    String address;
    String series;
    String url;
    String urldate;
    String file;
    String price;
    String editor;
    String institution;
    String abstrakt;

    public String getAbstrakt() {
        return abstrakt;
    }

    public void setAbstrakt(String abstrakt) {
        this.abstrakt = abstrakt;
    }

    @Override
    public String toString() {
        return type + '|' +
                title + '|' +
                author + '|' +
                publisher + '|' +
                year + '|' +
                pages + '|' +
                volume + '|' +
                number + '|' +
                isbn + '|' +
                journal + '|' +
                doi + '|' +
                keywords + '|' +
                booktitle + '|' +
                address + '|' +
                series + '|' +
                url + '|' +
                urldate + '|' +
                file + '|' +
                price + '|' +
                editor + '|' +
                institution + '|' +
                abstrakt;
    }

    public Literature(String type, String title, String author, String publisher, String year, String pages,
                      String volume, String number, String isbn, String journal, String doi, String keywords,
                      String booktitle, String address, String series, String url, String urldate, String file,
                      String price, String editor, String institution, String abstrakt) {
        this.type = type;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.pages = pages;
        this.volume = volume;
        this.number = number;
        this.isbn = isbn;
        this.journal = journal;
        this.doi = doi;
        this.keywords = keywords;
        this.booktitle = booktitle;
        this.address = address;
        this.series = series;
        this.url = url;
        this.urldate = urldate;
        this.file = file;
        this.price = price;
        this.editor = editor;
        this.institution = institution;
        this.abstrakt = abstrakt;
    }

    public Literature(String type, String title, String author, String publisher, String year,
                      String isbn, String journal, String keywords, String address,
                      String price) {
        this.type = type;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.isbn = isbn;
        this.journal = journal;
        this.keywords = keywords;
        this.address = address;
        this.price = price;

    }
}
