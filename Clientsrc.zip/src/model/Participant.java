package model;

//dummy
public class Participant {
    int participantkey;
    int userkey;
    int coursekey;
    int passed;


    public Participant() {
    }

    public Participant(int userkey, int coursekey, int passed) {
        this.coursekey = coursekey;
        this.userkey = userkey;
        this.passed = passed;
    }

    public int getParticipantkey() {
        return participantkey;
    }

    public void setParticipantkey(int participantkey) {
        this.participantkey = participantkey;
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userkey) {
        this.userkey = userkey;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public int getPassed() {
        return passed;
    }

    public void setPassed(int passed) {
        this.passed = passed;
    }
}
