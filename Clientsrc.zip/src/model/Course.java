package model;

public class Course {
    private int coursekey;
    private String name;
    private String semester;
    private String typ;
    private int userkey;

    public Course() {
    }

    public Course(String name, String semester, String type) {
        this.name = name;
        this.semester = semester;
        this.typ = type;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getTyp() {
        return typ;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userkey) {
        this.userkey = userkey;
    }

    @Override
    public String toString() {
        return typ + " " + name + " " + semester;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj != null) {
            if (((Course) obj).name.equals(this.name)) {
                if (((Course) obj).semester.equals(this.semester)) {
                    if (((Course) obj).typ.equals(this.typ)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
