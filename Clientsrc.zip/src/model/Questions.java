package model;

public class Questions {

    String fragenZahl;
    String frage;
    String antwortA;
    String antwortB;
    String antwortC;
    String antwortD;
    String richtigeAntwort;
    String userAntwort;


    public Questions(String fragenZahl, String frage, String antwortA, String antwortB, String antwortC, String antwortD, String richtigeAntwort, String userAntwort) {
        this.fragenZahl = fragenZahl;
        this.frage = frage;
        this.antwortA = antwortA;
        this.antwortB = antwortB;
        this.antwortC = antwortC;
        this.antwortD = antwortD;
        this.richtigeAntwort = richtigeAntwort;
        this.userAntwort = userAntwort;
    }

    public Questions(String fragenZahl, String frage, String userAntwort) {
        this.fragenZahl = fragenZahl;
        this.frage = frage;
        this.userAntwort = userAntwort;
    }


    public String getFragenZahl() {
        return fragenZahl;
    }

    public void setFragenZahl(String fragenZahl) {
        this.fragenZahl = fragenZahl;
    }

    public String getFrage() {
        return frage;
    }

    public void setFrage(String frage) {
        this.frage = frage;
    }

    public String getAntwortA() {
        return antwortA;
    }

    public void setAntwortA(String antwortA) {
        this.antwortA = antwortA;
    }

    public String getAntwortB() {
        return antwortB;
    }

    public void setAntwortB(String antwortB) {
        this.antwortB = antwortB;
    }

    public String getAntwortC() {
        return antwortC;
    }

    public void setAntwortC(String antwortC) {
        this.antwortC = antwortC;
    }

    public String getAntwortD() {
        return antwortD;
    }

    public void setAntwortD(String antwortD) {
        this.antwortD = antwortD;
    }

    public String getRichtigeAntwort() {
        return richtigeAntwort;
    }

    public void setRichtigeAntwort(String richtigeAntwort) {
        this.richtigeAntwort = richtigeAntwort;
    }

    public String getUserAntwort() {
        return userAntwort;
    }

    public void setUserAntwort(String userAntwort) {
        this.userAntwort = userAntwort;
    }


}
