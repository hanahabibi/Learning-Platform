package model;

public class Lecturer extends User {
    int lecturerKey;
    public String institute;
    public String research;

    public Lecturer(String eMail, String firstName, String lastName, byte[] placeHolderImage, String passWord, String address, String postalcode, String city, String institute, String research) {
        super(eMail, firstName, lastName, placeHolderImage, passWord, address, postalcode, city, 0);
        this.institute = institute;
        this.research = research;
    }

    public int getLecturerKey() {
        return lecturerKey;
    }

    public String getInstitute() {
        return institute;
    }

    public void setInstitute(String institute) {
        this.institute = institute;
    }

    public String getResearch() {
        return research;
    }

    public void setResearch(String research) {
        this.research = research;
    }

    @Override
    public String toString() {
        return this.getFirstname() + " " + this.getLastname();
    }
}
