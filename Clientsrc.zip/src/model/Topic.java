package model;

public class Topic {

    int topickey;
    String title;
    String description;
    int lecturerkey;
    byte[] literature;

    public Topic() {

    }

    public Topic(String title, String description, int lecturerkey, byte[] literature) {
        this.title = title;
        this.description = description;
        this.lecturerkey = lecturerkey;
        this.literature = literature;
    }

    public int getTopickey() {
        return topickey;
    }

    public void setTopickey(int topickey) {
        this.topickey = topickey;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getLecturerkey() {
        return lecturerkey;
    }

    @Override
    public String toString() {
        return title;
    }

    public void setLecturerkey(int lecturerkey) {
        this.lecturerkey = lecturerkey;
    }

    public byte[] getLiterature() {
        return literature;
    }

    public void setLiterature(byte[] literature) {
        this.literature = literature;
    }
}
