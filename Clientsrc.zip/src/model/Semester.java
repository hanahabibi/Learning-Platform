package model;

import java.util.Calendar;

public class Semester {
    public int semesterid;
    public String name;


    public Semester(String name) {
        this.name = name;

    }

    public int getSemesterid() {
        return semesterid;
    }

    public void setSemesterid(int semesterid) {
        this.semesterid = semesterid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
