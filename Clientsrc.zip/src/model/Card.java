package model;

public class Card {

    private int cardkey;
    private String cardname;
    private String cardexplanation;
    private int coursekey;

    public Card() {
    }

    public Card(String name, String explanation, int coursekey) {
        this.cardname = name;
        this.cardexplanation = explanation;
        this.coursekey = coursekey;
    }

    public int getCardkey() {
        return cardkey;
    }

    public void setCardkey(int cardkey) {
        this.cardkey = cardkey;
    }

    public String getCardname() {
        return cardname;
    }

    public void setCardname(String cardname) {
        this.cardname = cardname;
    }

    public String getCardexplanation() {
        return cardexplanation;
    }

    public void setCardexplanation(String cardexplanation) {
        this.cardexplanation = cardexplanation;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    @Override
    public String toString() {
        return cardname + " / " + cardexplanation;
    }
}

