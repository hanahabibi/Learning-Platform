package model;

public class Task {

    int taskkey;
    String task;
    String taskstate;
    int coursekey;
    int resposible;
    String name;


    public int getResposible() {
        return resposible;
    }

    public void setResposible(int resposible) {
        this.resposible = resposible;
    }

    public Task(String task, String taskstate, int coursekey, int resposible, String name) {
        this.task = task;
        this.taskstate = taskstate;
        this.coursekey = coursekey;
        this.taskkey = taskkey;
        this.resposible = resposible;
        this.name = name;

    }

    public Task() {

    }

    public int getTaskkey() {
        return taskkey;
    }

    public void setTaskkey(int taskkey) {
        this.taskkey = taskkey;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getTaskstate() {
        return taskstate;
    }

    public void setTaskstate(String taskstate) {
        this.taskstate = taskstate;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return taskstate + " / " + name + " / " + task;
    }
}
