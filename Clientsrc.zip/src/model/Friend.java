package model;

public class Friend {

    int key;
    int userkey;
    int otheruserkey;
    int bool;

    public Friend(int userkey, int bool) {
        this.bool = bool;
        this.userkey = userkey;

    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public int getUserkey() {
        return userkey;
    }

    public void setUserkey(int userkey) {
        this.userkey = userkey;
    }

    public int getOtheruserkey() {
        return otheruserkey;
    }

    public void setOtheruserkey(int otheruserkey) {
        this.otheruserkey = otheruserkey;
    }

    public int getBool() {
        return bool;
    }

    public void setBool(int bool) {
        this.bool = bool;
    }


}
