package model;

public class LearningMaterial {

    String name;
    int coursekey;
    int learningmaterialkey;
    byte[] material;

    public LearningMaterial(String name, int coursekey, byte[] material) {
        this.name = name;
        this.coursekey = coursekey;
        this.material = material;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCoursekey() {
        return coursekey;
    }

    public void setCoursekey(int coursekey) {
        this.coursekey = coursekey;
    }

    public int getLearningmaterialkey() {
        return learningmaterialkey;
    }

    public void setLearningmaterialkey(int learningmaterialkey) {
        this.learningmaterialkey = learningmaterialkey;
    }

    public byte[] getMaterial() {
        return material;
    }

    public void setMaterial(byte[] material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return getName();
    }
}
